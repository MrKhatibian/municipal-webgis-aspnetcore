/* COPYRIGHT Esri - https://js.arcgis.com/5.1.14/LICENSE.txt */
import{g as r}from"../../chunks/duration.js";import"../../chunks/has.js";import"../../chunks/time.js";function s(){return r()}export{s as getGoToDuration};
