/* COPYRIGHT Esri - https://js.arcgis.com/5.1.14/LICENSE.txt */
function i(i){return"isUrlHostModified"in i&&i.isUrlHostModified}export{i as isUrlHostModified};
