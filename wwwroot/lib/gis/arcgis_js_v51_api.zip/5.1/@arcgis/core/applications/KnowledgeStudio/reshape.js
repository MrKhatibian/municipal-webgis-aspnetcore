/* COPYRIGHT Esri - https://js.arcgis.com/5.1.14/LICENSE.txt */
async function n(n,t,e,o){return e.startNodeMovement(n,t,o)}function t(n,t){return n.on("node-movement-stop",t)}export{t as onNodeMovementStop,n as studioStartNodeMovement};
