/* COPYRIGHT Esri - https://js.arcgis.com/5.1.14/LICENSE.txt */
async function a(a){const{Pixel:e}=await import("../../chunks/arcadeUtils.js");return await a.load(),e.getDeclaredMembers(a)}async function e(a){const{Voxel:e}=await import("../../chunks/arcadeUtils.js");return await a.load(),e.getDeclaredMembers(a)}export{a as getDeclaredPixelMembers,e as getDeclaredVoxelMembers};
