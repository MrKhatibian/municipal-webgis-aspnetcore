/* COPYRIGHT Esri - https://js.arcgis.com/5.1.14/LICENSE.txt */
import{e as n,r,a as t,t as o}from"../../chunks/string.js";import"../../chunks/object.js";import"../../core/lang.js";function s(r,t){return n(r,t)}function u(n,t){return r(n,t)}function c(n){return t(n)}function e(n,r){return o(n,r)}export{s as escapeRegExpString,u as replace,c as stripHTML,e as templateHasKey};
