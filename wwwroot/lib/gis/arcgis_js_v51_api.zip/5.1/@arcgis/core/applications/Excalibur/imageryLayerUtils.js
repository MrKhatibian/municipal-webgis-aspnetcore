/* COPYRIGHT Esri - https://js.arcgis.com/5.1.14/LICENSE.txt */
function r(r){return r.rasterInfo}function n(r,n,e,t){return r.applyRenderer(n,e,t)}export{n as applyRenderer,r as getRasterInfo};
