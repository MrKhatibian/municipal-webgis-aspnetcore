/* COPYRIGHT Esri - https://js.arcgis.com/5.1.14/LICENSE.txt */
import{l as o}from"../../chunks/fontUtils.js";import"../../config.js";import"../../chunks/has.js";import"../../chunks/object.js";import"../../core/lang.js";function s(s){return o(s)}export{s as loadFont};
