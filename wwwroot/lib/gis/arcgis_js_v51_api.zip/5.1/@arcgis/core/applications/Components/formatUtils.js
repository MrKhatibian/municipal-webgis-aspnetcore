/* COPYRIGHT Esri - https://js.arcgis.com/5.1.14/LICENSE.txt */
function r(r){return r.hasDisplayProperties}export{r as hasDisplayProperties};
