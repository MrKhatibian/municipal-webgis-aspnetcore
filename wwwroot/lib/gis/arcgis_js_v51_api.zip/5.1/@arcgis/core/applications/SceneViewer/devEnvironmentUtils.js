/* COPYRIGHT Esri - https://js.arcgis.com/5.1.14/LICENSE.txt */
import{a as n,i as o,d as t}from"../../chunks/devEnvironmentUtils.js";function r(n){return o(n)}function i(n){return n=n||globalThis.location.hostname,[/^zrh-.+?\.esri\.com$/].concat(t).some(o=>null!=n?.match(o))}function s(o,t){return n(o,t)}export{s as adjustStaticAGOUrl,r as isDevEnvironment,i as isTelemetryDevEnvironment};
