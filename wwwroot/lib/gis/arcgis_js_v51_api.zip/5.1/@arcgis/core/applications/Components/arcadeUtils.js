/* COPYRIGHT Esri - https://js.arcgis.com/5.1.14/LICENSE.txt */
import{p as r,f as n}from"../../chunks/parser2.js";import"../../chunks/arcadeEnvironment.js";import"../../chunks/executionError.js";import"../../chunks/string.js";import"../../chunks/object.js";import"../../core/lang.js";function s(s){const o=r(s);return new Set(n(o))}export{s as getCalledFunctionNames};
