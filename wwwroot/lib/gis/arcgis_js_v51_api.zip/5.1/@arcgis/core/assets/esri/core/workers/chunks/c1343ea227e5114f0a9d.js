"use strict";(self.webpackChunkRemoteClient=self.webpackChunkRemoteClient||[]).push([[2921],{81589(e,t,o){o.d(t,{C:()=>a,b:()=>s,c:()=>l});var r=o(92);class a{constructor(e,t){this.min=e,this.max=t,this.range=t-e}normalize(e,t=0,o=!1){return i(this.range,this.min,this.max,e,t,o)}clamp(e,t=0){return(0,r.c)(e-t,this.min,this.max)+t}monotonic(e,t,o){return e<t?t:t+n(this.range,e-t,o)}minimalMonotonic(e,t,o){return i(this.range,e,e+this.range,t,o)}center(e,t,o){return t=this.monotonic(e,t,o),this.normalize((e+t)/2,o)}diff(e,t,o){return this.monotonic(e,t,o)-e}shortestSignedDiff(e,t){e=this.normalize(e);const o=(t=this.normalize(t))-e,r=t<e?this.minimalMonotonic(e,t)-e:t-this.minimalMonotonic(t,e);return Math.abs(o)<Math.abs(r)?o:r}contains(e,t,o){return t=this.minimalMonotonic(e,t),(o=this.minimalMonotonic(e,o))>e&&o<t}}function i(e,t,o,r,a=0,i=!1){return(r-=a)<t?r+=n(e,t-r):r>o&&(r-=n(e,r-o)),i&&r===o&&(r=t),r+a}function n(e,t,o=0){return Math.ceil((t-o)/e)*e+o}const s=new a(0,2*Math.PI),l=(new a(-Math.PI,Math.PI),new a(0,360))},4970(e,t,o){o.d(t,{D:()=>l});var r=o(19485),a=o(90694),i=o(90840),n=o(32846),s=o(39058);class l{constructor(e=e=>e){this._resolveURI=e}async loadJSON(e,t){return this._load("json",e,t)}async loadBinary(e,t){return(0,s.DB)(e)?((0,n.Te)(t),(0,s.lJ)(e)):this._load("array-buffer",e,t)}async loadImage(e,t){return this._load("image",e,t)}async _load(e,t,o){t=this._resolveURI(t);const s=await(0,a.r)((0,r.A)(t,{responseType:e,...o}));if(s.ok)return s.value.data;throw(0,n.QP)(s.error),new i.A("gltf-loader-request-error",`Request for resource failed: ${s.error}`)}}},40864(e,t,o){o.d(t,{a:()=>M,d:()=>y});var r=o(90840),a=o(92263),i=o(92498),n=o(33031),s=o(99095);const l=1e-6,c=[0,0];function u(e){return{maxSegmentLength:e.maxSegmentLength??0,maxDeviation:e.maxDeviation??0,maxSegmentsPerCurve:e.maxSegmentsPerCurve??12e3,minSegmentsPerCurve:Math.max(e.minSegmentsPerCurve??1,1)}}class d{constructor(e,t){this.curveStart=e,this.curveEnd=t,this.tStart=0,this.tEnd=0,this.tEndStack=[],this.arcEndStack=[]}get stackSize(){return this.tEndStack.length}initialize(e,t){this.tStart=0,this.arcStart=e,this.tEndStack.push(1),this.arcEndStack.push(t)}splitAt(e){this.tEndStack.push(this.tEnd),this.arcEndStack.push(this.arcEnd),this.tEndStack.push(e),this.arcEndStack.push(this.interpolate(e))}splitInHalf(){return this.splitAt((this.tStart+this.tEnd)/2)}pop(){this.tEnd=this.tEndStack.pop(),this.arcEnd=this.arcEndStack.pop()}next(){this.tStart=this.tEnd,this.arcStart=this.arcEnd}densify(e,{maxDeviation:t,maxSegmentLength:o,maxSegmentsPerCurve:r,minSegmentsPerCurve:a}){const i=o*o,s=t*t,c=1/r,u=this.interpolate(0),d=this.interpolate(1);(0,n.c)(this.curveStart,u)>l&&e.push(u),this.initialize(u,d);const h=1/a;for(let e=a-1;e>0;e--){const t=e*h;this.pop(),this.splitAt(t)}for(;this.stackSize>0;)this.pop(),this.tStart===this.tEnd||this.tEnd-this.tStart<c||(0===i||!isFinite(i)||(0,n.c)(this.arcStart,this.arcEnd)<i)&&(0===s||!isFinite(s)||this.getDeviation2()<s)?(e.push(this.arcEnd),this.next()):this.splitInHalf();return(0,n.c)(this.curveEnd,d)>l&&e.push([...this.curveEnd]),e}}class h extends d{constructor(e,t){const[o,r,a]=t.b;super(e,o),this._controlPointsStack=[],this._curveControlPoints=[r,a],this._arcControlPoints=[r,a],this._controlPointsStack.push(this._arcControlPoints)}splitAt(e){const{arcStart:t,arcEnd:o,tStart:r,tEnd:a}=this,[i,s]=this._arcControlPoints,l=(e-r)/(a-r),u=(0,n.i)([],t,i,l),d=(0,n.i)(c,i,s,l),h=(0,n.i)([],s,o,l),m=(0,n.i)([],u,d,l),p=(0,n.i)([],d,h,l),f=(0,n.i)([],m,p,l);this.tEndStack.push(this.tEnd),this.arcEndStack.push(this.arcEnd),this._controlPointsStack.push([p,h]),this.tEndStack.push(e),this.arcEndStack.push(f),this._arcControlPoints[0]=u,this._arcControlPoints[1]=m,this._controlPointsStack.push(this._arcControlPoints)}pop(){super.pop(),this._arcControlPoints=this._controlPointsStack.pop()}interpolate(e){const{curveStart:t,curveEnd:o}=this,[r,a]=this._curveControlPoints;return(0,n.b)(t,r,a,o,e)}getDeviation2(){const{arcStart:e,arcEnd:t}=this,[o,r]=this._arcControlPoints;return Math.max((0,n.p)(o,e,t),(0,n.p)(r,e,t))}}class m extends d{constructor(e,t){const[o]=t.a;super(e,o),this._derivedEllipse=(0,n.e)(e,t)}pop(){super.pop(),this._tMid=(this.tStart+this.tEnd)/2,this._arcMid=this.interpolate(this._tMid)}splitInHalf(){this.tEndStack.push(this.tEnd),this.arcEndStack.push(this.arcEnd),this.tEndStack.push(this._tMid),this.arcEndStack.push(this._arcMid)}interpolate(e){return(0,n.f)(this._derivedEllipse,e)}getDeviation2(){return(0,n.p)(this._arcMid,this.arcStart,this.arcEnd)}}function p(e,t,o,{cx:r,cy:a,radius:i,thetaStart:s,thetaEnd:c,isInvalid:u},{maxDeviation:d,maxSegmentLength:h,maxSegmentsPerCurve:m,minSegmentsPerCurve:p}){if(u)return e.push([...o]),e;const f=2*i,g=[r+i*Math.cos(s),a+i*Math.sin(s)],v=[r+i*Math.cos(c),a+i*Math.sin(c)];(0,n.c)(t,g)>l&&e.push(g);const x=Math.abs(c-s),b=h>0&&h<f?2*Math.asin(h/f):x,y=d>0&&d<=i?2*Math.acos(1-d/i):x,w=Math.min(b,y),M=Math.min(m,Math.max(p,Math.ceil(Math.abs(x/w)))),S=1/M;for(let t=1;t<M;t++){const o=t*S,n=s*(1-o)+c*o;e.push([r+i*Math.cos(n),a+i*Math.sin(n)])}return e.push(v),(0,n.c)(o,v)>l&&e.push([...o]),e}function f(e,t,o,r){return new h(t,o).densify(e,r)}function g(e,t,o,r){const a=(0,n.d)(t,o),[i]=o.c;return p(e,t,i,a,r)}function v(e,t,o,r){const a=(0,n.a)(t,o),[i]=o.a;return p(e,t,i,a,r)}function x(e,t,o,r){const[a,i,n,s,l,c,u]=o.a;return 0===c||0===u?(e.push([...a]),e):new m(t,o).densify(e,r)}function b(e,t,o,r){return(0,s.e)(o)?(e.push([...o]),e):(0,s.c)(o)?f(e,t,o,r):(0,s.a)(o)?g(e,t,o,r):(0,s.f)(o)?v(e,t,o,r):x(e,t,o,r)}function y(e,t={}){if(!(0,s.i)(e))return e;const o=u(t),r=(0,s.g)(e),a=[];for(const e of r){const t=[];for(let r=0;r<e.length-1;r++){const a=r+1,i=[...(0,s.d)(e[r])];0===r&&t.push(i),b(t,i,e[a],o)}a.push(t)}return"curvePaths"in e?{...void 0!==e.hasZ?{hasZ:e.hasZ}:{},...void 0!==e.hasM?{hasM:e.hasM}:{},paths:a,spatialReference:e.spatialReference}:{...void 0!==e.hasZ?{hasZ:e.hasZ}:{},...void 0!==e.hasM?{hasM:e.hasM}:{},rings:a,spatialReference:e.spatialReference}}const w=(0,a.m)(e=>({maxDeviation:0,maxSegmentLength:100*e,maxSegmentsPerCurve:12e3,minSegmentsPerCurve:1}));async function M(e,t,a){const n=new Set(t);return await async function(e,t,a){let i=null;for(const n of e)if(n&&(0,s.i)(n)&&null==n.spatialReference.xyTolerance&&(0,s.h)(n,t)){const e=n.spatialReference;if(!e)throw new r.A("geometry:missing-spatial-reference","Geometry contains an unsupported curve type, but it cannot be densified because it has no spatial reference.");const t=S(e);if(a.has(t))n.spatialReference=a.get(t);else{i||(i=await Promise.all([o.e(5699),o.e(9832),o.e(1655),o.e(6197),o.e(8553),o.e(2667)]).then(o.bind(o,63143)));const s=i.fromSpatialReference(e),l=s?.getTolerance();if(null==l)throw new r.A("geometry:missing-tolerance","Geometry contains an unsupported curve type, but it cannot be densified because the tolerance of its spatial reference is unknown. Set the `xyTolerance` property of the spatial reference.");const c=n.spatialReference.clone();c.read({xyTolerance:l}),n.spatialReference=c,a.set(t,c)}}}(e,n,a),e.map(e=>{if(!e||!(0,s.i)(e))return e;const o=e.spatialReference.xyTolerance;if(null==o)return e;const r=w(o);return(0,i.rS)(function(e,t,o){if(!(0,s.i)(e))return e;const r=new Set(t),a=u(o),i=(0,s.g)(e),n=[];let l=!1;for(const e of i){const t=[];for(let o=0;o<e.length-1;o++){const i=o+1,n=[...(0,s.d)(e[o])];0===o&&t.push(n);const c=e[i];(0,s.e)(c)?t.push([...c]):(0,s.c)(c)&&!r.has("cubic-bezier")?f(t,n,c,a):(0,s.a)(c)&&!r.has("circular-arc")?g(t,n,c,a):(0,s.f)(c)&&!r.has("elliptic-arc")?v(t,n,c,a):(0,s.j)(c)&&!r.has("elliptic-arc")?x(t,n,c,a):(t.push((0,s.k)(c)),l=!0)}n.push(t)}return"curvePaths"in e?{...void 0!==e.hasZ?{hasZ:e.hasZ}:{},...void 0!==e.hasM?{hasM:e.hasM}:{},spatialReference:e.spatialReference,...l?{curvePaths:n}:{paths:n}}:{hasZ:e.hasZ,hasM:e.hasM,spatialReference:e.spatialReference,...l?{curveRings:n}:{rings:n}}}(e,t,r))})}function S(e){if(null!=e.wkid)return`${e.wkid}`;if(null!=e.wkt)return e.wkt;const t="toJSON"in e&&"function"==typeof e.toJSON?e.toJSON():e;return JSON.stringify(t)}},95786(e,t,o){function r(e){return e=e||globalThis.location.hostname,c.some(t=>null!=e?.match(t))}function a(e,t){return e?(t=t||globalThis.location.hostname)?null!=t.match(i)||null!=t.match(s)?e.replace("static.arcgis.com","staticdev.arcgis.com"):null!=t.match(n)||null!=t.match(l)?e.replace("static.arcgis.com","staticqa.arcgis.com"):e:e:null}o.d(t,{a:()=>a,i:()=>r});const i=/^devext\.arcgis\.com$/,n=/^qaext\.arcgis\.com$/,s=/^[\w-]*\.mapsdevext\.arcgis\.com$/,l=/^[\w-]*\.mapsqa\.arcgis\.com$/,c=[/^([\w-]*\.)?[\w-]*\.zrh-dev-local\.esri\.com$/,i,n,/^jsapps\.esri\.com$/,s,l]},99246(e,t,o){o.d(t,{a:()=>n,c:()=>c,f:()=>l,n:()=>s});var r=o(61064),a=o(44410),i=o(37923);function n(e,t){s(e.typedBuffer,t.typedBuffer,e.typedBufferStride,t.typedBufferStride)}function s(e,t,o=2,a=o){const i=t.length/2;let n=0,s=0;if(!(0,r.a)(t)||(0,r.z)(t)){for(let r=0;r<i;++r)e[n]=t[s],e[n+1]=t[s+1],n+=o,s+=a;return}const l=(0,r.A)(t);if((0,r.B)(t))for(let r=0;r<i;++r)e[n]=Math.max(t[s]/l,-1),e[n+1]=Math.max(t[s+1]/l,-1),n+=o,s+=a;else for(let r=0;r<i;++r)e[n]=t[s]/l,e[n+1]=t[s+1]/l,n+=o,s+=a}function l(e,t,o,r){const a=e.typedBuffer,i=e.typedBufferStride,n=r?.count??e.count;let s=(r?.dstIndex??0)*i;for(let e=0;e<n;++e)a[s]=t,a[s+1]=o,s+=i}function c(e,t){switch(t){case i.a.TRIANGLES:return function(e){return"number"==typeof e?(0,a.b)(e):(0,r.C)(e)?new Uint16Array(e):e}(e);case i.a.TRIANGLE_STRIP:return function(e){const t="number"==typeof e?e:e.length;if(t<3)return[];const o=t-2,r=(0,a.n)(3*o);if("number"==typeof e){let e=0;for(let t=0;t<o;t+=1)t%2==0?(r[e++]=t,r[e++]=t+1,r[e++]=t+2):(r[e++]=t+1,r[e++]=t,r[e++]=t+2)}else{let t=0;for(let a=0;a<o;a+=1)a%2==0?(r[t++]=e[a],r[t++]=e[a+1],r[t++]=e[a+2]):(r[t++]=e[a+1],r[t++]=e[a],r[t++]=e[a+2])}return r}(e);case i.a.TRIANGLE_FAN:return function(e){const t="number"==typeof e?e:e.length;if(t<3)return new Uint16Array(0);const o=t-2,r=o<=65536?new Uint16Array(3*o):new Uint32Array(3*o);if("number"==typeof e){let e=0;for(let t=0;t<o;++t)r[e++]=0,r[e++]=t+1,r[e++]=t+2;return r}const a=e[0];let i=e[1],n=0;for(let t=0;t<o;++t){const o=e[t+2];r[n++]=a,r[n++]=i,r[n++]=o,i=o}return r}(e)}}},92263(e,t,o){function r(e){let t,o,r=[],a=!1;return function(...i){return a&&t===this&&function(e,t){if(e.length!==t.length)return!1;for(let o=0;o<e.length;++o)if(e[o]!==t[o])return!1;return!0}(i,r)||(o=e.apply(this,i),t=this,r=i,a=!0),o}}o.d(t,{m:()=>r})},7406(e,t,o){o.d(t,{a:()=>u,b:()=>m,c:()=>n,d:()=>i,e:()=>l,g:()=>a,h:()=>h});var r=o(61064);const a=16;function i(e){if(!e)return 0;let t=u;for(const o in e)e.hasOwnProperty(o)&&(t+=s(e[o],!1));return t}function n(e){if(!e)return 0;if("number"==typeof e[0])return l(e);if(Array.isArray(e))return function(e){const t=e.length;if(0===t||"number"==typeof e[0])return c(e,8);let o=d;for(let r=0;r<t;r++)o+=s(e[r]);return o}(e);let t=u;for(const o in e)e.hasOwnProperty(o)&&(t+=s(e[o]));return t}function s(e,t=!0){switch(typeof e){case"object":return t?n(e):u;case"string":return function(e){return 32+e.length}(e);case"number":return 16;case"boolean":return 4;default:return 8}}function l(...e){return e.reduce((e,t)=>e+(t?(0,r.a)(t)?t.byteLength+h:Array.isArray(t)?c(t,16):0:0),0)}function c(e,t){return d+e.length*t}const u=32,d=16,h=145,m=64},88562(e,t,o){o.d(t,{c:()=>s,g:()=>u,o:()=>l,u:()=>c});var r=o(66625),a=o(32276),i=o(97912),n=o(99095);const s={102100:{maxX:20037508.342788905,minX:-20037508.342788905,plus180Line:new r.A({paths:[[[20037508.342788905,-20037508.342788905],[20037508.342788905,20037508.342788905]]],spatialReference:a.A.WebMercator}),minus180Line:new r.A({paths:[[[-20037508.342788905,-20037508.342788905],[-20037508.342788905,20037508.342788905]]],spatialReference:a.A.WebMercator})},4326:{maxX:180,minX:-180,plus180Line:new r.A({paths:[[[180,-180],[180,180]]],spatialReference:a.A.WGS84}),minus180Line:new r.A({paths:[[[-180,-180],[-180,180]]],spatialReference:a.A.WGS84})}};function l(e,t){return Math.ceil((e-t)/(2*t))}function c(e,t){if((0,n.i)(e))for(const o of function(e){return(0,i.b)(e)?e.curveRings:e.curvePaths}(e))for(const e of o){if((0,n.a)(e)){const[o,r]=e.c;o[0]+=t,r[0]+=t;continue}if((0,n.b)(e)){const[o,r]=e.a;o[0]+=t,r[0]+=t;continue}if((0,n.c)(e)){const[o,r,a]=e.b;o[0]+=t,r[0]+=t,a[0]+=t;continue}e[0]+=t}for(const o of u(e))for(const e of o)e[0]+=t;return e}function u(e){return(0,i.b)(e)?e.rings:e.paths}},42699(e,t,o){o.d(t,{o:()=>er});var r=o(49595),a=o(95786),i=o(92),n=o(24890),s=o(94193),l=o(4741),c=o(60163),u=o(34484),d=o(47498),h=o(69144),m=o(61064);function p(e,t=!1){return e<=m.n?t?new Array(e).fill(0):new Array(e):new Float32Array(e)}var f=o(1524),g=o(97812),v=o(84219),x=o(99246),b=o(4970),y=o(58141),w=o(83988),M=o(19485),S=o(90694),T=o(90840),C=o(167),_=o(7406),I=o(32846),P=o(78726),F=o(44410),D=o(50538),R=o(39355),j=o(59411),z=o(55048),O=o(9673),E=o(46183),B=o(12832);class N extends j.G{constructor(e){super(e),this._numLoading=0,this._disposed=!1,this._textures=e.textures,this.updateTexture(e.textureId),this._acquire(e.normalTextureId,e=>this._textureNormal=e),this._acquire(e.emissiveTextureId,e=>this._textureEmissive=e),this._acquire(e.occlusionTextureId,e=>this._textureOcclusion=e),this._acquire(e.metallicRoughnessTextureId,e=>this._textureMetallicRoughness=e)}dispose(){super.dispose(),this._texture=(0,E.f)(this._texture),this._textureNormal=(0,E.f)(this._textureNormal),this._textureEmissive=(0,E.f)(this._textureEmissive),this._textureOcclusion=(0,E.f)(this._textureOcclusion),this._textureMetallicRoughness=(0,E.f)(this._textureMetallicRoughness),this._disposed=!0}ensureResources(e){return 0===this._numLoading?2:1}get textureBindParameters(){return new G(this._texture?.texture??null,this._textureNormal?.texture??null,this._textureEmissive?.texture??null,this._textureOcclusion?.texture??null,this._textureMetallicRoughness?.texture??null)}updateTexture(e){null!=this._texture&&e===this._texture.id||(this._texture=(0,E.f)(this._texture),this._acquire(e,e=>this._texture=e))}_acquire(e,t){if(null==e)return void t(null);const o=this._textures.acquire(e);if((0,I.$X)(o))return++this._numLoading,void o.then(e=>{if(this._disposed)return(0,E.f)(e),void t(null);t(e)}).finally(()=>--this._numLoading);t(o)}}class W extends B.N{constructor(e=null){super(),this.textureEmissive=e}}class G extends W{constructor(e,t,o,r,a,i,n){super(o),this.texture=e,this.textureNormal=t,this.textureOcclusion=r,this.textureMetallicRoughness=a,this.scale=i,this.normalTextureTransformMatrix=n}}class L{constructor(e){this.layout=e}elementCount(e){return e.get("position").indices.length}write(e,t,o,r,a){null!=a&&(0,j.a0)(o,r,this.layout,e,t,a)}}class A{constructor(e=0,t=!1,o=!0){this.tolerance=e,this.isVerticalRay=t,this.normalRequired=o}}const V=(0,h.c)();function k(e,t,o,r,a,i){if(!e.visible)return;const n=(0,u.a)(oe,r,o),{tolerance:s}=t,l=new A(s,!1,t.options.normalRequired);if(e.boundingInfo)(0,f.G)(0===e.type),$(e.boundingInfo,o,n,s,a,l,i);else{const t=e.positionAttribute,r=e.primitivePositionIndices;!function(e,t,o,r,a,i,n,s,l,c){const d=t,h=re,m=Math.abs(d[0]),p=Math.abs(d[1]),f=Math.abs(d[2]),g=m>=p?m>=f?0:2:p>=f?1:2,v=g,x=d[v]<0?2:1,b=(g+x)%3,y=(g+(3-x))%3,w=d[b]/d[v],M=d[y]/d[v],S=1/d[v],T=q,C=Z,_=J,{normalRequired:I}=l;for(let t=o;t<r;++t){const o=3*t,r=n*a[o];(0,u.h)(h[0],i[r+0],i[r+1],i[r+2]);const l=n*a[o+1];(0,u.h)(h[1],i[l+0],i[l+1],i[l+2]);const d=n*a[o+2];(0,u.h)(h[2],i[d+0],i[d+1],i[d+2]),s&&((0,u.f)(h[0],s.applyToVertex(h[0][0],h[0][1],h[0][2],t)),(0,u.f)(h[1],s.applyToVertex(h[1][0],h[1][1],h[1][2],t)),(0,u.f)(h[2],s.applyToVertex(h[2][0],h[2][1],h[2][2],t))),(0,u.a)(T,h[0],e),(0,u.a)(C,h[1],e),(0,u.a)(_,h[2],e);const m=T[b]-w*T[v],p=T[y]-M*T[v],f=C[b]-w*C[v],g=C[y]-M*C[v],x=_[b]-w*_[v],P=_[y]-M*_[v],F=x*g-P*f,D=m*P-p*x,R=f*p-g*m;if((F<0||D<0||R<0)&&(F>0||D>0||R>0))continue;const j=F+D+R;if(0===j)continue;const z=F*(S*T[v])+D*(S*C[v])+R*(S*_[v]);if(z*Math.sign(j)<0)continue;const O=z/j;O>=0&&c(O,O,I?X(h):null,t)}}(o,n,0,r.length/3,r,t.data,t.stride,a,l,i)}}const U=(0,d.c)();function $(e,t,o,r,a,i,n){if(null==e)return;const s=(0,u.h)(U,1/(l=o)[0],1/l[1],1/l[2]);var l;if((0,h.I)(V,e.bbMin),(0,h.J)(V,e.bbMax),null!=a&&a.applyToAabb(V),function(e,t,o,r){return function(e,t,o,r){const a=(e[0]-r-t[0])*o[0],i=(e[3]+r-t[0])*o[0];let n=Math.min(a,i),s=Math.max(a,i);const l=(e[1]-r-t[1])*o[1],c=(e[4]+r-t[1])*o[1];if(s=Math.min(s,Math.max(l,c)),s<0)return!1;if(n=Math.max(n,Math.min(l,c)),n>s)return!1;const u=(e[2]-r-t[2])*o[2],d=(e[5]+r-t[2])*o[2];return s=Math.min(s,Math.max(u,d)),!(s<0)&&(n=Math.max(n,Math.min(u,d)),!(n>s)&&n<1/0)}(e,t,o,r)}(V,t,s,r)){const{primitiveIndices:s,position:l}=e,c=s?s.length:l.indices.length/3;if(c>ee){const s=e.getChildren();if(void 0!==s){for(const e of s)$(e,t,o,r,a,i,n);return}}!function(e,t,o,r,a,i,n,s,l,c,u){const d=e[0],h=e[1],m=e[2],p=t[0],f=t[1],g=t[2],{normalRequired:v}=c;for(let e=0;e<r;++e){const t=s[e],o=3*t,r=n*a[o];let c=i[r],x=i[r+1],b=i[r+2];const y=n*a[o+1];let w=i[y],M=i[y+1],S=i[y+2];const T=n*a[o+2];let C=i[T],_=i[T+1],I=i[T+2];null!=l&&([c,x,b]=l.applyToVertex(c,x,b,e),[w,M,S]=l.applyToVertex(w,M,S,e),[C,_,I]=l.applyToVertex(C,_,I,e));const P=w-c,F=M-x,D=S-b,R=C-c,j=_-x,z=I-b,O=f*z-j*g,E=g*R-z*p,B=p*j-R*f,N=P*O+F*E+D*B,W=N*N;if(W<=te)continue;const G=d-c,L=h-x,A=m-b,V=(G*O+L*E+A*B)*N;if(V<0||V>W)continue;const k=L*D-F*A,U=A*P-D*G,$=G*F-P*L,q=(p*k+f*U+g*$)*N;if(q<0||V+q>W)continue;const Z=(R*k+j*U+z*$)/N;Z>=0&&u(Z,Z,v?Y(P,F,D,R,j,z,H):null,t)}}(t,o,0,c,l.indices,l.data,l.stride,s,a,i,n)}}const H=(0,d.c)();const q=(0,d.c)(),Z=(0,d.c)(),J=(0,d.c)();function Y(e,t,o,r,a,i,n){return(0,u.h)(K,e,t,o),(0,u.h)(Q,r,a,i),(0,u.e)(n,K,Q),(0,u.n)(n,n),n}function X(e){return(0,u.a)(K,e[1],e[0]),(0,u.a)(Q,e[2],e[0]),(0,u.e)(H,K,Q),(0,u.n)(H,H),H}const K=(0,d.c)(),Q=(0,d.c)(),ee=1e3,te=1e-7*1e-7,oe=(0,d.c)(),re=[(0,d.c)(),(0,d.c)(),(0,d.c)()],ae=new j.T,ie=(0,d.c)();function ne(e){e.uniforms.add(new j.w("dpDummy",()=>1)).code.add(O.g`vec3 dpAdd(vec3 hiA, vec3 loA, vec3 hiB, vec3 loB) {
vec3 hiD = hiA + hiB;
vec3 loD = loA + loB;
return  dpDummy * hiD + loD;
}`)}O.U,O.U;class se extends B.N{constructor(){super(...arguments),this.transformWorldFromViewTH=(0,d.c)(),this.transformWorldFromViewTL=(0,d.c)(),this.transformViewFromCameraRelativeRS=(0,n.c)()}}function le(e){(function(e){e.vertex.code.add(O.g`float calculateLinearDepth(vec2 nearFar,float z) {
return (-z - nearFar[0]) / (nearFar[1] - nearFar[0]);
}`)})(e),e.vertex.code.add(O.g`vec4 transformPositionWithDepth(mat4 proj, mat4 view, vec3 pos, vec2 nearFar, out float depth) {
vec4 eye = view * vec4(pos, 1.0);
depth = calculateLinearDepth(nearFar,eye.z);
return proj * eye;
}`),e.vertex.code.add(O.g`vec4 transformPosition(mat4 proj, mat4 view, vec3 pos) {
return proj * (view * vec4(pos, 1.0));
}`)}function ce(e,t){t.hasVertexColors?(e.attributes.add("color","vec4"),e.varyings.add("vColor","vec4"),e.vertex.code.add(O.g`void forwardVertexColor() { vColor = color; }`)):e.vertex.code.add(O.g`void forwardVertexColor() {}`)}B.N;var ue=o(61594),de=o(69099),he=o(99413),me=o(87477),pe=o(32562),fe=(o(20979),o(98127)),ge=o(87054),ve=o(66572),xe=o(82427),be=o(19553);function ye(e){e.uniforms.add(new j.e("zProjectionMap",e=>we(e.camera))),e.code.add(O.g`float linearizeDepth(float depth, vec2 zProjectionConstants) {
float depthNdc = depth * 2.0 - 1.0;
return -(zProjectionConstants[0] / (depthNdc + zProjectionConstants[1] + 1e-7));
}
float linearizeDepth(float depth) {
return linearizeDepth(depth, zProjectionMap);
}`),e.code.add(O.g`float delinearizeDepth(float linearDepth) {
float c1 = zProjectionMap[0];
float c2 = zProjectionMap[1];
float depthNdc = (-c1/linearDepth) - c2 - 1e-7;
float depthNonlinear01 = (depthNdc + 1.0 ) / 2.0;
return depthNonlinear01;
}`),e.code.add(O.g`float depthFromTexture(sampler2D depthTexture, vec2 uv) {
ivec2 iuv = ivec2(uv * vec2(textureSize(depthTexture, 0)));
return texelFetch(depthTexture, iuv, 0).r;
}`),e.code.add(O.g`float linearDepthFromTexture(sampler2D depthTexture, vec2 uv) {
return linearizeDepth(depthFromTexture(depthTexture, uv));
}`)}function we(e){const t=e.projectionMatrix;return(0,xe.s)(Me,t[14],t[10])}const Me=(0,c.c)();function Se(e){e.fragment.uniforms.add(new z.F("projInfo",e=>function(e){const t=e.projectionMatrix;return 0===t[11]?(0,be.s)(Te,2/(e.fullWidth*t[0]),2/(e.fullHeight*t[5]),(1+t[12])/t[0],(1+t[13])/t[5]):(0,be.s)(Te,-2/(e.fullWidth*t[0]),-2/(e.fullHeight*t[5]),(1-t[8])/t[0],(1-t[9])/t[5])}(e.camera))),e.fragment.uniforms.add(new j.e("zScale",e=>0===e.camera.projectionMatrix[11]?(0,xe.s)(Ce,0,1):(0,xe.s)(Ce,1,0))),e.fragment.code.add(O.g`vec3 reconstructPosition(vec2 fragCoord, float depth) {
return vec3((fragCoord * projInfo.xy + projInfo.zw) * (zScale.x * depth + zScale.y), depth);
}`)}const Te=(0,me.c)(),Ce=(0,c.c)();class _e extends O.U{constructor(e,t,o){super(e,"mat4",1,(r,a,i)=>r.setUniformMatrix4fv(e,t(a,i),o))}}var Ie=o(73044);function Pe(e,t){const o=e.vertex;t.hasVerticalOffset?(function(e){e.uniforms.add(new j.F("verticalOffset",(e,t)=>{const{minWorldLength:o,maxWorldLength:r,screenLength:a}=e.verticalOffset,i=Math.tan(.5*t.camera.fovY)/(.5*t.camera.fullViewport[3]),n=t.camera.pixelRatio||1;return(0,be.s)(Fe,a*n,i,o,r)}))}(o),t.hasScreenSizePerspective&&(e.include(z.S),(0,z.a)(o),(0,j.c)(e.vertex,t)),o.code.add(O.g`
      vec3 calculateVerticalOffset(vec3 worldPos, vec3 localOrigin) {
        float viewDistance = length((view * vec4(worldPos, 1.0)).xyz);
        ${t.spherical?O.g`vec3 worldNormal = normalize(worldPos + localOrigin);`:O.g`vec3 worldNormal = vec3(0.0, 0.0, 1.0);`}
        ${t.hasScreenSizePerspective?O.g`
            float cosAngle = dot(worldNormal, normalize(worldPos - cameraPosition));
            float verticalOffsetScreenHeight = screenSizePerspectiveScaleFloat(verticalOffset.x, abs(cosAngle), viewDistance, screenSizePerspectiveAlignment);`:O.g`
            float verticalOffsetScreenHeight = verticalOffset.x;`}
        // Screen sized offset in world space, used for example for line callouts
        float worldOffset = clamp(verticalOffsetScreenHeight * verticalOffset.y * viewDistance, verticalOffset.z, verticalOffset.w);
        return worldNormal * worldOffset;
      }

      vec3 addVerticalOffset(vec3 worldPos, vec3 localOrigin) {
        return worldPos + calculateVerticalOffset(worldPos, localOrigin);
      }
    `)):o.code.add(O.g`vec3 addVerticalOffset(vec3 worldPos, vec3 localOrigin) { return worldPos; }`)}o(25734);const Fe=(0,me.c)();class De extends O.U{constructor(e,t){super(e,"bool",0,(o,r)=>o.setUniform1b(e,t(r)))}}var Re=o(53743),je=o(30250),ze=o(97150),Oe=o(53440),Ee=o(10023),Be=o(27879),Ne=o(9682),We=o(37923),Ge=o(21084);class Le extends O.U{constructor(e,t,o,r){super(e,"mat4",1,(o,a,i)=>o.setUniformMatrices4fv(e,t(a,i),r),o)}}var Ae=o(10918);function Ve(e,t){switch(t.output){case 5:case 6:case 7:case 8:e.fragment.code.add(O.g`float _calculateFragDepth(const in float depth) {
const float slope_scale = 2.0;
const float bias = 20.0 * .000015259;
float m = max(abs(dFdx(depth)), abs(dFdy(depth)));
return depth + slope_scale * m + bias;
}
void outputDepth(float _linearDepth){
float fragDepth = _calculateFragDepth(_linearDepth);
gl_FragDepth = fragDepth;
}`);break;case 9:e.fragment.code.add(O.g`void outputDepth(float _linearDepth){
gl_FragDepth = _linearDepth;
}`)}}function ke(e,t){switch(e.fragment.code.add(O.g`vec3 screenDerivativeNormal(vec3 positionView) {
return normalize(cross(dFdx(positionView), dFdy(positionView)));
}`),t.normalType){case 1:e.attributes.add("normalCompressed","vec2"),e.vertex.code.add(O.g`vec3 decompressNormal(vec2 normal) {
float z = 1.0 - abs(normal.x) - abs(normal.y);
return vec3(normal + sign(normal) * min(z, 0.0), z);
}
vec3 normalModel() {
return decompressNormal(normalCompressed);
}`);break;case 0:e.attributes.add("normal","vec3"),e.vertex.code.add(O.g`vec3 normalModel() {
return normal;
}`);break;default:t.normalType;case 2:case 3:}}function Ue(e,t){const{vertex:o,varyings:r}=e;switch(t.normalType){case 0:case 1:e.include(ke,t),r.add("vNormalWorld","vec3"),r.add("vNormalView","vec3"),o.uniforms.add(new j.af("transformNormalViewFromGlobal",e=>e.transformNormalViewFromGlobal)),o.code.add(O.g`void forwardNormal() {
vNormalWorld = normalModel();
vNormalView = transformNormalViewFromGlobal * vNormalWorld;
}`);break;case 2:e.vertex.code.add(O.g`void forwardNormal() {}`);break;default:t.normalType;case 3:}}class $e extends se{constructor(){super(...arguments),this.transformNormalViewFromGlobal=(0,n.c)()}}class He{constructor(e){this.localTransform=e.localTransform,this.globalTransform=e.globalTransform,this.modelOrigin=e.modelOrigin,this.model=e.instanceModel,this.modelNormal=e.instanceModelNormal,this.modelScaleFactors=e.modelScaleFactors,this.boundingSphere=e.boundingSphere,this.featureAttribute=e.getField("instanceFeatureAttribute",f.i),this.color=e.getField("instanceColor",f.c),this.olidColor=e.getField("instanceOlidColor",f.c),this.state=e.getField("state",f.z),this.lodLevel=e.getField("lodLevel",f.z)}}let qe=class extends fe.A{constructor(e,t){super(e),this.events=new ge.a,this._capacity=0,this._size=0,this._next=0,this._highlightOptionsMap=new Map,this._highlightOptionsMapPrev=new Map,this._layout=function(e){return Je(Ze.clone(),e).u8("state").u8("lodLevel")}(t),this._capacity=et,this._buffer=this._layout.createBuffer(this._capacity),this._view=new He(this._buffer)}get capacity(){return this._capacity}get size(){return this._size}get view(){return this._view}addInstance(){this._size+1>this._capacity&&this._grow();const e=this._findSlot();return this._view.state.set(e,1),this._size++,this.events.emit("instances-changed"),e}removeInstance(e){const t=this._view.state;(0,f.G)(e>=0&&e<this._capacity&&!!(1&t.get(e)),"invalid instance handle"),this._getStateFlag(e,18)?this._setStateFlags(e,32):this.freeInstance(e),this.events.emit("instances-changed")}freeInstance(e){const t=this._view.state;(0,f.G)(e>=0&&e<this._capacity&&!!(1&t.get(e)),"invalid instance handle"),t.set(e,0),this._size--}setLocalTransform(e,t,o=!0){this._view.localTransform.setMat(e,t),o&&this.updateModelTransform(e)}getLocalTransform(e,t){this._view.localTransform.getMat(e,t)}setGlobalTransform(e,t,o=!0){this._view.globalTransform.setMat(e,t),o&&this.updateModelTransform(e)}getGlobalTransform(e,t){this._view.globalTransform.getMat(e,t)}updateModelTransform(e){const t=this._view,o=Ye,r=Xe;t.localTransform.getMat(e,Ke),t.globalTransform.getMat(e,Qe);const a=(0,s.m)(Qe,Qe,Ke);(0,u.h)(o,a[12],a[13],a[14]),t.modelOrigin.setVec(e,o),(0,n.d)(r,a),t.model.setMat(e,r);const i=(0,ve.f)(Ye,a);i.sort(),t.modelScaleFactors.set(e,0,i[1]),t.modelScaleFactors.set(e,1,i[2]),(0,n.i)(r,r),(0,n.t)(r,r),t.modelNormal.setMat(e,r),this._setStateFlags(e,64),this.events.emit("instance-transform-changed",{index:e})}getModelTransform(e,t){const o=this._view;o.model.getMat(e,Xe),o.modelOrigin.getVec(e,Ye),t[0]=Xe[0],t[1]=Xe[1],t[2]=Xe[2],t[3]=0,t[4]=Xe[3],t[5]=Xe[4],t[6]=Xe[5],t[7]=0,t[8]=Xe[6],t[9]=Xe[7],t[10]=Xe[8],t[11]=0,t[12]=Ye[0],t[13]=Ye[1],t[14]=Ye[2],t[15]=1}applyShaderTransformation(e,t){null!=this.shaderTransformation&&this.shaderTransformation.applyTransform(this,e,t)}getCombinedModelTransform(e,t){return this.getModelTransform(e,t),null!=this.shaderTransformation&&this.shaderTransformation.applyTransform(this,e,t),t}getCombinedLocalTransform(e,t){this._view.localTransform.getMat(e,t),null!=this.shaderTransformation&&this.shaderTransformation.applyTransform(this,e,t)}getCombinedMaxScaleFactor(e){let t=this._view.modelScaleFactors.get(e,1);return null!=this.shaderTransformation&&(this.shaderTransformation.scaleFactor(Ye,this,e),t*=Math.max(Ye[0],Ye[1],Ye[2])),t}getCombinedMedianScaleFactor(e){let t=this._view.modelScaleFactors.get(e,0);var o,r,a;return null!=this.shaderTransformation&&(this.shaderTransformation.scaleFactor(Ye,this,e),t*=(o=Ye[0],r=Ye[1],a=Ye[2],Math.max(Math.min(o,r),Math.min(Math.max(o,r),a)))),t}getModel(e,t){this._view.model.getMat(e,t)}setFeatureAttribute(e,t){this._view.featureAttribute?.setVec(e,t)}getFeatureAttribute(e,t){this._view.featureAttribute?.getVec(e,t)}setColor(e,t){this._view.color?.setVec(e,t)}setObjectAndLayerIdColor(e,t){this._view.olidColor?.setVec(e,t)}setVisible(e,t){t!==this.getVisible(e)&&(this._setStateFlag(e,4,t),this.events.emit("instance-visibility-changed",{index:e}))}getVisible(e){return this._getStateFlag(e,4)}setHighlight(e,t){const{_highlightOptionsMap:o}=this,r=o.get(e);t?t!==r&&(o.set(e,t),this._setStateFlag(e,8,!0),this.events.emit("instance-highlight-changed")):r&&(o.delete(e),this._setStateFlag(e,8,!1),this.events.emit("instance-highlight-changed"))}get highlightOptionsMap(){return this._highlightOptionsMap}getHighlightStateFlag(e){return this._getStateFlag(e,8)}geHighlightOptionsPrev(e){const t=this._highlightOptionsMapPrev.get(e)??null;return this._highlightOptionsMapPrev.delete(e),t}getHighlightName(e){const t=this.highlightOptionsMap.get(e)??null;return t?this._highlightOptionsMapPrev.set(e,t):this._highlightOptionsMapPrev.delete(e),t}getState(e){return this._view.state.get(e)}getLodLevel(e){return this._view.lodLevel.get(e)}countFlags(e){let t=0;for(let o=0;o<this._capacity;++o)this.getState(o)&e&&++t;return t}_setStateFlags(e,t){const o=this._view.state;t=o.get(e)|t,o.set(e,t)}_clearStateFlags(e,t){const o=this._view.state;t=o.get(e)&~t,o.set(e,t)}_setStateFlag(e,t,o){o?this._setStateFlags(e,t):this._clearStateFlags(e,t)}_getStateFlag(e,t){return!!(this._view.state.get(e)&t)}_grow(){this._capacity=Math.max(et,Math.floor(this._capacity*m.V)),this._buffer=this._layout.createBuffer(this._capacity).copyFrom(this._buffer),this._view=new He(this._buffer)}_findSlot(){const e=this._view.state;let t=this._next;for(;1&e.get(t);)t=t+1===this._capacity?0:t+1;return this._next=t+1===this._capacity?0:t+1,t}};(0,de._)([(0,he.MZ)({constructOnly:!0})],qe.prototype,"shaderTransformation",void 0),(0,de._)([(0,he.MZ)()],qe.prototype,"_size",void 0),(0,de._)([(0,he.MZ)({readOnly:!0})],qe.prototype,"size",null),qe=(0,de._)([(0,he.$K)("esri.views.3d.webgl-engine.lib.lodRendering.InstanceData")],qe);const Ze=(0,pe.n)().mat4f64("localTransform").mat4f64("globalTransform").vec4f64("boundingSphere").vec3f64("modelOrigin").mat3f("instanceModel").mat3f("instanceModelNormal").vec2f("modelScaleFactors");function Je(e,t){return t.instancedFeatureAttribute&&e.vec4f("instanceFeatureAttribute"),t.instancedColor&&e.vec4u8("instanceColor"),(0,j.o)()&&e.vec4u8("instanceOlidColor"),e}const Ye=(0,d.c)(),Xe=(0,n.c)(),Ke=(0,l.c)(),Qe=(0,l.c)(),et=64,tt=(0,pe.n)().vec3f("instanceModelOriginHi").vec3f("instanceModelOriginLo").mat3f("instanceModel").mat3f("instanceModelNormal"),ot=(0,d.g)(1,1,.5),rt=(0,d.g)(0,.6,.2),at=(0,d.g)(0,1,.2);function it(e){e.vertex.code.add(O.g`vec4 offsetBackfacingClipPosition(vec4 posClip, vec3 posWorld, vec3 normalWorld, vec3 camPosWorld) {
vec3 camToVert = posWorld - camPosWorld;
bool isBackface = dot(camToVert, normalWorld) > 0.0;
if (isBackface) {
posClip.z += 0.0000003 * posClip.w;
}
return posClip;
}`)}function nt(e,t){t.instancedColor?(e.attributes.add("instanceColor","vec4"),e.vertex.include(j.L),e.vertex.include(j.at),e.vertex.include(j.au),e.vertex.code.add(O.g`
      MaskedColor applyInstanceColor(MaskedColor color) {
        return multiplyMaskedColors( color, createMaskedFromUInt8NaNColor(${"instanceColor"}));
      }
    `)):e.vertex.code.add(O.g`MaskedColor applyInstanceColor(MaskedColor color) {
return color;
}`)}const st=(0,n.c)();function lt(e,t){const{hasModelTransformation:o,instancedDoublePrecision:r,instanced:a,output:i,hasVertexTangents:s}=t;o&&(e.vertex.uniforms.add(new _e("model",e=>e.modelTransformation??l.I)),e.vertex.uniforms.add(new j.af("normalLocalOriginFromModel",e=>((0,n.n)(st,e.modelTransformation??l.I),st)))),a&&r&&(e.attributes.add("instanceModelOriginHi","vec3"),e.attributes.add("instanceModelOriginLo","vec3"),e.attributes.add("instanceModel","mat3"),e.attributes.add("instanceModelNormal","mat3"));const c=e.vertex;r&&(c.include(ne),c.uniforms.add(new j.ad("viewOriginHi",e=>(0,j.av)((0,u.h)(ct,e.camera.viewInverseTransposeMatrix[3],e.camera.viewInverseTransposeMatrix[7],e.camera.viewInverseTransposeMatrix[11]),ct)),new j.ad("viewOriginLo",e=>(0,j.aw)((0,u.h)(ct,e.camera.viewInverseTransposeMatrix[3],e.camera.viewInverseTransposeMatrix[7],e.camera.viewInverseTransposeMatrix[11]),ct)))),c.code.add(O.g`
    vec3 getVertexInLocalOriginSpace() {
      return ${o?r?"(model * vec4(instanceModel * localPosition().xyz, 1.0)).xyz":"(model * localPosition()).xyz":r?"instanceModel * localPosition().xyz":"localPosition().xyz"};
    }

    vec3 subtractOrigin(vec3 _pos) {
      ${r?O.g`
          // Issue: (should be resolved now with invariant position) https://devtopia.esri.com/WebGIS/arcgis-js-api/issues/56280
          vec3 originDelta = dpAdd(viewOriginHi, viewOriginLo, -instanceModelOriginHi, -instanceModelOriginLo);
          return _pos - originDelta;`:"return vpos;"}
    }
    `),c.code.add(O.g`
    vec3 dpNormal(vec4 _normal) {
      return normalize(${o?r?"normalLocalOriginFromModel * (instanceModelNormal * _normal.xyz)":"normalLocalOriginFromModel * _normal.xyz":r?"instanceModelNormal * _normal.xyz":"_normal.xyz"});
    }
    `),4===i&&((0,j.u)(c),c.code.add(O.g`
    vec3 dpNormalView(vec4 _normal) {
      return normalize((viewNormal * ${o?r?"vec4(normalLocalOriginFromModel * (instanceModelNormal * _normal.xyz), 1.0)":"vec4(normalLocalOriginFromModel * _normal.xyz, 1.0)":r?"vec4(instanceModelNormal * _normal.xyz, 1.0)":"_normal"}).xyz);
    }
    `)),s&&c.code.add(O.g`
    vec4 dpTransformVertexTangent(vec4 _tangent) {
      ${o?r?"return vec4(normalLocalOriginFromModel * (instanceModelNormal * _tangent.xyz), _tangent.w);":"return vec4(normalLocalOriginFromModel * _tangent.xyz, _tangent.w);":r?"return vec4(instanceModelNormal * _tangent.xyz, _tangent.w);":"return _tangent;"}
    }`)}const ct=(0,d.c)();function ut(e,t){e.varyings.add("colorMixMode","int"),e.varyings.add("opacityMixMode","int"),e.vertex.uniforms.add(new Ie.I("symbolColorMixMode",e=>j.Q[e.colorMixMode])),t.hasSymbolColors?(e.vertex.include(j.L),e.vertex.include(j.at),e.vertex.include(j.au),e.attributes.add("symbolColor","vec4"),e.vertex.code.add(O.g`
    MaskedColor applySymbolColor(MaskedColor color) {
      return multiplyMaskedColors(color, createMaskedFromUInt8NaNColor(${"symbolColor"}));
    }
  `)):e.vertex.code.add(O.g`MaskedColor applySymbolColor(MaskedColor color) {
return color;
}`),e.vertex.code.add(O.g`
    void forwardColorMixMode(bvec4 mask) {
      colorMixMode = mask.r ? ${O.g.int(j.Q.ignore)} : symbolColorMixMode;
      opacityMixMode = mask.a ? ${O.g.int(j.Q.ignore)} : symbolColorMixMode;
    }
  `)}function dt(e,t){!function(e,t,o){const r=e.fragment;switch(r.code.add("void discardOrAdjustAlpha(inout vec4 color) {"),t.alphaDiscardMode){case 1:r.code.add("color.a = 1.0;");break;case 0:r.include(j.P),r.code.add("if (color.a < alphaCutoff) discard;");break;case 3:r.uniforms.add(o).code.add("if (color.a < textureAlphaCutoff) discard;");break;case 2:r.uniforms.add(o).code.add("\n        if (color.a < textureAlphaCutoff) discard;\n        color.a = 1.0;\n      ");break;case 4:break;default:t.alphaDiscardMode}r.code.add("}")}(e,t,new O.F("textureAlphaCutoff",e=>e.textureAlphaCutoff))}function ht(e,t){const{vertex:o,fragment:r,varyings:a}=e,{hasColorTexture:i,alphaDiscardMode:n}=t,s=i&&1!==n,{output:l,normalType:c,hasColorTextureTransform:u}=t;switch(l){case 3:(0,j.f)(o,t),e.include(le),r.include(j.S,t),e.include(O.h,t),s&&r.uniforms.add(new O.T("tex",e=>e.texture)),o.main.add(O.g`vpos = getVertexInLocalOriginSpace();
vpos = subtractOrigin(vpos);
vpos = addVerticalOffset(vpos, localOrigin);
gl_Position = transformPosition(proj, view, vpos);
forwardTextureCoordinates();`),e.include(dt,t),r.main.add(O.g`
        discardBySlice(vpos);
        ${(0,O.I)(s,O.g`vec4 texColor = texture(tex, ${u?"colorUV":"vuv0"});
                discardOrAdjustAlpha(texColor);`)}`);break;case 5:case 6:case 7:case 8:case 11:(0,j.f)(o,t),e.include(le),e.include(O.h,t),e.include(j.V,t),e.include(Ve,t),r.include(j.S,t),e.include(j.g,t),function(e){e.vertex.uniforms.add(new j.e("nearFar",e=>e.camera.nearFar))}(e),a.add("depth","float",{invariant:!0}),s&&r.uniforms.add(new O.T("tex",e=>e.texture)),o.main.add(O.g`vpos = getVertexInLocalOriginSpace();
vpos = subtractOrigin(vpos);
vpos = addVerticalOffset(vpos, localOrigin);
gl_Position = transformPositionWithDepth(proj, view, vpos, nearFar, depth);
forwardTextureCoordinates();
forwardObjectAndLayerIdColor();`),e.include(dt,t),r.main.add(O.g`
        discardBySlice(vpos);
        ${(0,O.I)(s,O.g`vec4 texColor = texture(tex, ${u?"colorUV":"vuv0"});
               discardOrAdjustAlpha(texColor);`)}
        ${11===l?O.g`outputObjectAndLayerIdColor();`:O.g`outputDepth(depth);`}`);break;case 4:{(0,j.f)(o,t),e.include(le),e.include(ke,t),e.include(Ue,t),e.include(O.h,t),e.include(j.V,t),s&&r.uniforms.add(new O.T("tex",e=>e.texture)),2===c&&a.add("vPositionView","vec3",{invariant:!0});const i=0===c||1===c;o.main.add(O.g`
        vpos = getVertexInLocalOriginSpace();
        ${i?O.g`vNormalWorld = dpNormalView(vvLocalNormal(normalModel()));`:O.g`vPositionView = (view * vec4(vpos, 1.0)).xyz;`}
        vpos = subtractOrigin(vpos);
        vpos = addVerticalOffset(vpos, localOrigin);
        gl_Position = transformPosition(proj, view, vpos);
        forwardTextureCoordinates();`),r.include(j.S,t),e.include(dt,t),r.main.add(O.g`
        discardBySlice(vpos);
        ${(0,O.I)(s,O.g`vec4 texColor = texture(tex, ${u?"colorUV":"vuv0"});
                discardOrAdjustAlpha(texColor);`)}

        ${2===c?O.g`vec3 normal = screenDerivativeNormal(vPositionView);`:O.g`vec3 normal = normalize(vNormalWorld);
                    if (gl_FrontFacing == false){
                      normal = -normal;
                    }`}
        fragColor = vec4(0.5 + 0.5 * normal, 1.0);`);break}case 10:(0,j.f)(o,t),e.include(le),e.include(O.h,t),e.include(j.V,t),s&&r.uniforms.add(new O.T("tex",e=>e.texture)),o.main.add(O.g`vpos = getVertexInLocalOriginSpace();
vpos = subtractOrigin(vpos);
vpos = addVerticalOffset(vpos, localOrigin);
gl_Position = transformPosition(proj, view, vpos);
forwardTextureCoordinates();`),r.include(j.S,t),e.include(dt,t),e.include(j.y,t),r.main.add(O.g`
        discardBySlice(vpos);
        ${(0,O.I)(s,O.g`vec4 texColor = texture(tex, ${u?"colorUV":"vuv0"});
                discardOrAdjustAlpha(texColor);`)}
        calculateOcclusionAndOutputHighlight();`)}}function mt(e,t){return function(e,t){const o=e.fragment,{hasVertexTangents:r,doubleSidedMode:a,hasNormalTexture:i,textureCoordinateType:s,bindType:l,hasNormalTextureTransform:u}=t;r?(e.attributes.add("tangent","vec4"),e.varyings.add("vTangent","vec4"),2===a?o.code.add(O.g`mat3 computeTangentSpace(vec3 normal) {
float tangentHeadedness = gl_FrontFacing ? vTangent.w : -vTangent.w;
vec3 tangent = normalize(gl_FrontFacing ? vTangent.xyz : -vTangent.xyz);
vec3 bitangent = cross(normal, tangent) * tangentHeadedness;
return mat3(tangent, bitangent, normal);
}`):o.code.add(O.g`mat3 computeTangentSpace(vec3 normal) {
float tangentHeadedness = vTangent.w;
vec3 tangent = normalize(vTangent.xyz);
vec3 bitangent = cross(normal, tangent) * tangentHeadedness;
return mat3(tangent, bitangent, normal);
}`)):o.code.add(O.g`mat3 computeTangentSpace(vec3 normal, vec3 pos, vec2 st) {
vec3 Q1 = dFdx(pos);
vec3 Q2 = dFdy(pos);
vec2 stx = dFdx(st);
vec2 sty = dFdy(st);
float det = stx.t * sty.s - sty.t * stx.s;
vec3 T = stx.t * Q2 - sty.t * Q1;
T = T - normal * dot(normal, T);
T *= inversesqrt(max(dot(T,T), 1.e-10));
vec3 B = sign(det) * cross(normal, T);
return mat3(T, B, normal);
}`),i&&0!==s&&(e.include(O.V,t),o.uniforms.add(1===l?new O.T("normalTexture",e=>e.textureNormal):new O.t("normalTexture",e=>e.textureNormal)),u&&(o.uniforms.add(1===l?new z.c("scale",e=>e.scale??c.O):new Re.F("scale",e=>e.scale??c.O)),o.uniforms.add(new j.af("normalTextureTransformMatrix",e=>e.normalTextureTransformMatrix??n.I))),o.code.add(O.g`vec3 computeTextureNormal(mat3 tangentSpace, vec2 uv) {
vec3 rawNormal = textureLookup(normalTexture, uv).rgb * 2.0 - 1.0;`),u&&o.code.add(O.g`mat3 normalRotation = mat3(normalTextureTransformMatrix[0][0]/scale[0], normalTextureTransformMatrix[0][1]/scale[1], 0.0,
normalTextureTransformMatrix[1][0]/scale[0], normalTextureTransformMatrix[1][1]/scale[1], 0.0,
0.0, 0.0, 0.0 );
rawNormal.xy = (normalRotation * vec3(rawNormal.x, rawNormal.y, 1.0)).xy;`),o.code.add(O.g`return tangentSpace * rawNormal;
}`))}(e,t)}function pt(e){return Math.max(10,20*e.computeScreenPixelSizeAtDist(Math.abs(4*e.relativeElevation)))}const ft=(0,c.c)(),gt=Object.freeze(Object.defineProperty({__proto__:null,build:function(){const e=new Be.S,t=e.fragment;return e.include(Ie.S),e.include(Se),t.include(ye),t.include(O.G),t.uniforms.add(new j.w("radius",e=>pt(e.camera))).code.add(O.g`vec3 sphere[16] = vec3[16](
vec3(0.186937, 0.0, 0.0),
vec3(0.700542, 0.0, 0.0),
vec3(-0.864858, -0.481795, -0.111713),
vec3(-0.624773, 0.102853, -0.730153),
vec3(-0.387172, 0.260319, 0.007229),
vec3(-0.222367, -0.642631, -0.707697),
vec3(-0.01336, -0.014956, 0.169662),
vec3(0.122575, 0.1544, -0.456944),
vec3(-0.177141, 0.85997, -0.42346),
vec3(-0.131631, 0.814545, 0.524355),
vec3(-0.779469, 0.007991, 0.624833),
vec3(0.308092, 0.209288,0.35969),
vec3(0.359331, -0.184533, -0.377458),
vec3(0.192633, -0.482999, -0.065284),
vec3(0.233538, 0.293706, -0.055139),
vec3(0.417709, -0.386701, 0.442449)
);
float fallOffFunction(float vv, float vn, float bias) {
float f = max(radius * radius - vv, 0.0);
return f * f * f * max(vn - bias, 0.0);
}`),t.code.add(O.g`float aoValueFromPositionsAndNormal(vec3 C, vec3 n_C, vec3 Q) {
vec3 v = Q - C;
float vv = dot(v, v);
float vn = dot(normalize(v), n_C);
return fallOffFunction(vv, vn, 0.1);
}`),e.outputs.add("fragOcclusion","float"),t.uniforms.add(new O.T("normalMap",e=>e.normalTexture),new O.T("depthMap",e=>e.depthTexture),new O.F("projScale",e=>e.projScale),new O.T("rnm",e=>e.noiseTexture),new z.c("rnmScale",(e,t)=>(0,xe.s)(ft,t.camera.fullWidth/e.noiseTexture.descriptor.width,t.camera.fullHeight/e.noiseTexture.descriptor.height)),new O.F("intensity",e=>e.intensity),new j.e("screenSize",e=>(0,xe.s)(ft,e.camera.fullWidth,e.camera.fullHeight))).main.add(O.g`
    float depth = depthFromTexture(depthMap, uv);

    // Early out if depth is out of range, such as in the sky
    if (depth >= 1.0 || depth <= 0.0) {
      fragOcclusion = 1.0;
      return;
    }

    // get the normal of current fragment
    ivec2 iuv = ivec2(uv * vec2(textureSize(normalMap, 0)));
    vec4 norm4 = texelFetch(normalMap, iuv, 0);
    if(norm4.a != 1.0) {
      fragOcclusion = 1.0;
      return;
    }
    vec3 norm = normalize(norm4.xyz * 2.0 - 1.0);

    float currentPixelDepth = linearizeDepth(depth);
    vec3 currentPixelPos = reconstructPosition(gl_FragCoord.xy, currentPixelDepth);

    float sum = 0.0;
    vec3 tapPixelPos;

    vec3 fres = normalize(2.0 * texture(rnm, uv * rnmScale).xyz - 1.0);

    // note: the factor 2.0 should not be necessary, but makes ssao much nicer.
    // bug or deviation from CE somewhere else?
    float ps = projScale / (2.0 * currentPixelPos.z * zScale.x + zScale.y);

    for(int i = 0; i < ${O.g.int(16)}; ++i) {
      vec2 unitOffset = reflect(sphere[i], fres).xy;
      vec2 offset = vec2(-unitOffset * radius * ps);

      // don't use current or very nearby samples
      if( abs(offset.x) < 2.0 || abs(offset.y) < 2.0){
        continue;
      }

      vec2 tc = vec2(gl_FragCoord.xy + offset);
      if (tc.x < 0.0 || tc.y < 0.0 || tc.x > screenSize.x || tc.y > screenSize.y) continue;
      vec2 tcTap = tc / screenSize;
      float occluderFragmentDepth = linearDepthFromTexture(depthMap, tcTap);

      tapPixelPos = reconstructPosition(tc, occluderFragmentDepth);

      sum += aoValueFromPositionsAndNormal(currentPixelPos, norm, tapPixelPos);
    }

    // output the result
    float A = max(1.0 - sum * intensity / float(${O.g.int(16)}), 0.0);

    // Anti-tone map to reduce contrast and drag dark region farther: (x^0.2 + 1.2 * x^4) / 2.2
    A = (pow(A, 0.2) + 1.2 * pow(A, 4.0)) * INV_GAMMA;

    fragOcclusion = A;
  `),e},getRadius:pt},Symbol.toStringTag,{value:"Module"})),vt=Object.freeze(Object.defineProperty({__proto__:null,build:function(){const e=new Be.S,t=e.fragment;return e.include(Ie.S),t.include(ye),t.uniforms.add(new O.T("depthMap",e=>e.depthTexture),new O.t("tex",e=>e.colorTexture),new Re.F("blurSize",e=>e.blurSize),new O.F("projScale",(e,t)=>{const o=t.camera.distance;return o>5e4?Math.max(0,e.projScale-(o-5e4)):e.projScale})),t.code.add(O.g`
    void blurFunction(vec2 uv, float r, float center_d, float sharpness, inout float wTotal, inout float bTotal) {
      float c = texture(tex, uv).r;
      float d = linearDepthFromTexture(depthMap, uv);

      float ddiff = d - center_d;

      float w = exp(-r * r * ${O.g.float(.08)} - ddiff * ddiff * sharpness);
      wTotal += w;
      bTotal += w * c;
    }
  `),e.outputs.add("fragBlur","float"),t.main.add(O.g`
    float b = 0.0;
    float w_total = 0.0;

    float center_d = linearDepthFromTexture(depthMap, uv);

    float sharpness = -0.05 * projScale / center_d;
    for (int r = -${O.g.int(4)}; r <= ${O.g.int(4)}; ++r) {
      float rf = float(r);
      vec2 uvOffset = uv + rf * blurSize;
      blurFunction(uvOffset, rf, center_d, sharpness, w_total, b);
    }
    fragBlur = b / w_total;`),e}},Symbol.toStringTag,{value:"Module"}));let xt=class extends j.j{constructor(){super(...arguments),this.shader=new j.R(vt,()=>Promise.resolve().then(()=>vt))}initializePipeline(){return(0,Ne.m)({colorWrite:Ne.d})}};xt=(0,de._)([(0,he.$K)("esri.views.3d.webgl-engine.effects.ssao.SSAOBlurTechnique")],xt);class bt extends B.N{constructor(){super(...arguments),this.projScale=1}}class yt extends bt{constructor(){super(...arguments),this.intensity=1}}class wt extends B.N{}class Mt extends wt{constructor(){super(...arguments),this.blurSize=(0,c.c)()}}let St=class extends j.j{constructor(){super(...arguments),this.shader=new j.R(gt,()=>Promise.resolve().then(()=>gt))}initializePipeline(){return(0,Ne.m)({colorWrite:Ne.d})}};St=(0,de._)([(0,he.$K)("esri.views.3d.webgl-engine.effects.ssao.SSAOTechnique")],St);let Tt=class extends Ee.A{constructor(e){super(e),this.consumes={required:["normals"]},this.produces=Oe.OG.AMBIENT_ILLUMINATION,this._enableTime=(0,ze.M)(0),this._passParameters=new yt,this._drawParameters=new Mt}initialize(){const e=Uint8Array.from(atob("eXKEvZaUc66cjIKElE1jlJ6MjJ6Ufkl+jn2fcXp5jBx7c6KEflSGiXuXeW6OWs+tfqZ2Yot2Y7Zzfo2BhniEj3xoiXuXj4eGZpqEaHKDWjSMe7palFlzc3BziYOGlFVzg6Zzg7CUY5JrjFF7eYJ4jIKEcyyEonSXe7qUfqZ7j3xofqZ2c4R5lFZ5Y0WUbppoe1l2cIh2ezyUho+BcHN2cG6DbpqJhqp2e1GcezhrdldzjFGUcyxjc3aRjDyEc1h7Sl17c6aMjH92pb6Mjpd4dnqBjMOEhqZleIOBYzB7gYx+fnqGjJuEkWlwnCx7fGl+c4hjfGyRe5qMlNOMfnqGhIWHc6OMi4GDc6aMfqZuc6aMzqJzlKZ+lJ6Me3qRfoFue0WUhoR5UraEa6qMkXiPjMOMlJOGe7JrUqKMjK6MeYRzdod+Sl17boiPc6qEeYBlcIh2c1WEe7GDiWCDa0WMjEmMdod+Y0WcdntzhmN8WjyMjKJjiXtzgYxYaGd+a89zlEV7e2GJfnd+lF1rcK5zc4p5cHuBhL6EcXp5eYB7fnh8iX6HjIKEeaxuiYOGc66RfG2Ja5hzjlGMjEmMe9OEgXuPfHyGhPeEdl6JY02McGuMfnqGhFiMa3WJfnx2l4hwcG1uhmN8c0WMc39og1GBbrCEjE2EZY+JcIh2cIuGhIWHe0mEhIVrc09+gY5+eYBlnCyMhGCDl3drfmmMgX15aGd+gYx+fnuRfnhzY1SMsluJfnd+hm98WtNrcIuGh4SEj0qPdkqOjFF7jNNjdnqBgaqUjMt7boeBhnZ4jDR7c5pze4GGjEFrhLqMjHyMc0mUhKZze4WEa117kWlwbpqJjHZ2eX2Bc09zeId+e0V7WlF7jHJ2l72BfId8l3eBgXyBe897jGl7c66cgW+Xc76EjKNbgaSEjGx4fId8jFFjgZB8cG6DhlFziZhrcIh2fH6HgUqBgXiPY8dahGFzjEmMhEFre2dxhoBzc5SGfleGe6alc7aUeYBlhKqUdlp+cH5za4OEczxza0Gcc4J2jHZ5iXuXjH2Jh5yRjH2JcFx+hImBjH+MpddCl3dreZeJjIt8ZW18bm1zjoSEeIOBlF9oh3N7hlqBY4+UeYFwhLJjeYFwaGd+gUqBYxiEYot2fqZ2ondzhL6EYyiEY02Ea0VjgZB8doaGjHxoc66cjEGEiXuXiXWMiZhreHx8frGMe75rY02Ec5pzfnhzlEp4a3VzjM+EhFFza3mUY7Zza1V5e2iMfGyRcziEhDyEkXZ2Y4OBnCx7g5t2eyBjgV6EhEFrcIh2dod+c4Z+nJ5zjm15jEmUeYxijJp7nL6clIpjhoR5WrZraGd+fnuRa6pzlIiMg6ZzfHx5foh+eX1ufnB5eX1ufnB5aJt7UqKMjIh+e3aBfm5lbYSBhGFze6J4c39oc0mUc4Z+e0V7fKFVe0WEdoaGY02Ec4Z+Y02EZYWBfH6HgU1+gY5+hIWUgW+XjJ57ebWRhFVScHuBfJ6PhBx7WqJzlM+Ujpd4gHZziX6HjHmEgZN+lJt5boiPe2GJgX+GjIGJgHZzeaxufnB5hF2JtdN7jJ57hp57hK6ElFVzg6ZzbmiEbndzhIWHe3uJfoFue3qRhJd2j3xoc65zlE1jc3p8lE1jhniEgXJ7e657vZaUc3qBh52BhIF4aHKDa9drgY5+c52GWqZzbpqJe8tjnM+UhIeMfo2BfGl+hG1zSmmMjKJjZVaGgX15c1lze0mEp4OHa3mUhIWHhDyclJ6MeYOJkXiPc0VzhFiMlKaEboSJa5Jze41re3qRhn+HZYWBe0mEc4p5fnORbox5lEp4hGFjhGGEjJuEc1WEhLZjeHeGa7KlfHx2hLaMeX1ugY5+hIWHhKGPjMN7c1WEho1zhoBzZYx7fnhzlJt5exyUhFFziXtzfmmMa6qMYyiEiXxweV12kZSMeWqXSl17fnhzxmmMrVGEe1mcc4p5eHeGjK6MgY5+doaGa6pzlGV7g1qBh4KHkXiPeW6OaKqafqZ2eXZ5e1V7jGd7boSJc3BzhJd2e0mcYot2h1RoY8dahK6EQmWEWjx7e1l2lL6UgXyBdnR4eU9zc0VreX1umqaBhld7fo2Bc6KEc5Z+hDyEcIeBWtNrfHyGe5qMhMuMe5qMhEGEbVVupcNzg3aHhIF4boeBe0mEdlptc39ofFl5Y8uUlJOGiYt2UmGEcyxjjGx4jFF7a657ZYWBnElzhp57iXtrgZN+tfOEhIOBjE2HgU1+e8tjjKNbiWCDhE15gUqBgYN7fnqGc66ce9d7iYSBj0qPcG6DnGGcT3eGa6qMZY+JlIiMl4hwc3aRdnqBlGV7eHJ2hLZjfnuRhDyEeX6MSk17g6Z+c6aUjHmEhIF4gXyBc76EZW18fGl+fkl+jCxrhoVwhDyUhIqGlL2DlI6EhJd2tdN7eYORhEGMa2Faa6pzc3Bzc4R5lIRznM+UY9eMhDycc5Z+c4p5c4iGY117pb6MgXuPrbJafnx2eYOJeXZ5e657hDyEcziElKZjfoB5eHeGj4WRhGGEe6KGeX1utTStc76EhFGJnCyMa5hzfH6HnNeceYB7hmN8gYuMhIVrczSMgYF8h3N7c5pza5hzjJqEYIRdgYuMlL2DeYRzhGGEeX1uhLaEc4iGeZ1zdl6JhrVteX6Me2iMfm5lWqJzSpqEa6pzdnmchHx2c6OMhNdrhoR5g3aHczxzeW52gV6Ejm15frGMc0Vzc4Z+l3drfniJe+9rWq5rlF1rhGGEhoVwe9OEfoh+e7pac09+c3qBY0lrhDycdnp2lJ6MiYOGhGCDc3aRlL2DlJt5doaGdnp2gYF8gWeOjF2Uc4R5c5Z+jEmMe7KEc4mEeYJ4dmyBe0mcgXiPbqJ7eYB7fmGGiYSJjICGlF1reZ2PnElzbpqJfH6Hc39oe4WEc5eJhK6EhqyJc3qBgZB8c09+hEmEaHKDhFGJc5SGiXWMUpaEa89zc6OMnCyMiXtrho+Be5qMc7KEjJ57dmN+hKGPjICGbmiEe7prdod+hGCDdnmchBx7eX6MkXZ2hGGEa657hm98jFFjY5JreYOJgY2EjHZ2a295Y3FajJ6Mc1J+YzB7e4WBjF2Uc4R5eV12gYxzg1qBeId+c9OUc5pzjFFjgY5+hFiMlIaPhoR5lIpjjIKBlNdSe7KEeX2BfrGMhIqGc65zjE2UhK6EklZ+QmWEeziMWqZza3VzdnR4foh+gYF8n3iJiZhrnKp7gYF8eId+lJ6Me1lrcIuGjKJjhmN8c66MjFF7a6prjJ6UnJ5zezyUfruRWlF7nI5zfHyGe657h4SEe8tjhBx7jFFjc09+c39ojICMeZeJeXt+YzRzjHZ2c0WEcIeBeXZ5onSXkVR+gYJ+eYFwdldzgYF7eX2BjJ6UiXuXlE1jh4SEe1mchLJjc4Z+hqZ7eXZ5bm1zlL6Ue5p7iWeGhKqUY5pzjKJjcIeBe8t7gXyBYIRdlEp4a3mGnK6EfmmMZpqEfFl5gYxzjKZuhGFjhoKGhHx2fnx2eXuMe3aBiWeGvbKMe6KGa5hzYzB7gZOBlGV7hmN8hqZlYot2Y117a6pzc6KEfId8foB5rctrfneJfJ6PcHN2hFiMc5pzjH92c0VzgY2EcElzdmCBlFVzg1GBc65zY4OBboeBcHiBeYJ4ewxzfHx5lIRzlEmEnLKEbk1zfJ6PhmN8eYBljBiEnMOEiXxwezyUcIeBe76EdsKEeX2BdnR4jGWUrXWMjGd7fkl+j4WRlEGMa5Jzho+BhDyEfnqMeXt+g3aHlE1jczClhNN7ZW18eHx8hGFjZW18iXWMjKJjhH57gYuMcIuGWjyMe4ZtjJuExmmMj4WRdntzi4GDhFFzYIRdnGGcjJp7Y0F7e4WEkbCGiX57fnSHa657a6prhBCMe3Z+SmmMjH92eHJ2hK6EY1FzexhrvbKMnI5za4OEfnd+eXuMhImBe897hLaMjN+EfG+BeIOBhF1+eZeJi4GDkXZ2eXKEgZ6Ejpd4c2GHa1V5e5KUfqZuhCx7jKp7lLZrg11+hHx2hFWUoot2nI5zgbh5mo9zvZaUe3qRbqKMfqZ2kbCGhFiM"),e=>e.charCodeAt(0)),t=new Ge.T(32);t.wrapMode=33071,t.pixelFormat=6407,t.wrapMode=10497,t.hasMipmap=!0,this._passParameters.noiseTexture=new Ge.a(this.renderingContext,t,e),this.addHandles((0,je.wB)(()=>this.view.stage.renderer.hasAmbientIllumination,()=>this._enableTime=(0,ze.M)(0)))}destroy(){this._passParameters.noiseTexture=(0,E.c)(this._passParameters.noiseTexture)}render(e){const t=e.find(({name:e})=>"normals"===e),o=t?.getTexture(),r=t?.getTexture(We.b);if(!o||!r)return;const a=this.techniques.getCompiled(St),n=this.techniques.getCompiled(xt);if(!a||!n)return this._enableTime=(0,ze.M)(performance.now()),void this.requestRender(1);0===this._enableTime&&(this._enableTime=(0,ze.M)(performance.now()));const s=this.renderingContext,l=this.view.qualitySettings.fadeDuration,c=this.bindParameters,u=c.camera,d=u.relativeElevation,h=(0,i.c)((5e5-d)/2e5,0,1),m=l>0?Math.min(l,performance.now()-this._enableTime)/l:1,p=m*h;this._passParameters.normalTexture=o,this._passParameters.depthTexture=r,this._passParameters.projScale=1/u.computeScreenPixelSizeAtDist(1),this._passParameters.intensity=4*Ct/pt(u)**6*p;const f=u.fullViewport[2],g=u.fullViewport[3],v=this.fboCache.acquire(f,g,"ssao input",2);s.bindFramebuffer(v.fbo),s.setViewport(0,0,f,g),s.bindTechnique(a,c,this._passParameters,this._drawParameters),s.screen.draw();const x=Math.round(f/2),b=Math.round(g/2),y=this.fboCache.acquire(x,b,"ssao blur",0);s.bindFramebuffer(y.fbo),this._drawParameters.colorTexture=v.getTexture(),(0,xe.s)(this._drawParameters.blurSize,0,2/g),s.bindTechnique(n,c,this._passParameters,this._drawParameters),s.setViewport(0,0,x,b),s.screen.draw(),v.release();const w=this.fboCache.acquire(x,b,Oe.OG.AMBIENT_ILLUMINATION,0);return s.bindFramebuffer(w.fbo),s.setViewport(0,0,f,g),s.setClearColor(1,1,1,0),s.clear(16384),this._drawParameters.colorTexture=y.getTexture(),(0,xe.s)(this._drawParameters.blurSize,2/f,0),s.bindTechnique(n,c,this._passParameters,this._drawParameters),s.setViewport(0,0,x,b),s.screen.draw(),s.setViewport4fv(u.fullViewport),y.release(),m<1&&this.requestRender(2),w}};(0,de._)([(0,he.MZ)()],Tt.prototype,"consumes",void 0),(0,de._)([(0,he.MZ)()],Tt.prototype,"produces",void 0),Tt=(0,de._)([(0,he.$K)("esri.views.3d.webgl-engine.effects.ssao.SSAO")],Tt);const Ct=.5;function _t(e,t){t.receiveAmbientOcclusion?(e.uniforms.add(new j.a3("ssaoTex",e=>e.ssao?.getTexture())),e.constants.add("blurSizePixelsInverse","float",.5),e.code.add(O.g`float evaluateAmbientOcclusionInverse() {
vec2 ssaoTextureSizeInverse = 1.0 / vec2(textureSize(ssaoTex, 0));
return texture(ssaoTex, gl_FragCoord.xy * blurSizePixelsInverse * ssaoTextureSizeInverse).r;
}
float evaluateAmbientOcclusion() {
return 1.0 - evaluateAmbientOcclusionInverse();
}`)):e.code.add(O.g`float evaluateAmbientOcclusionInverse() { return 1.0; }
float evaluateAmbientOcclusion() { return 0.0; }`)}class It extends O.U{constructor(e,t,o,r){super(e,"float",0,(t,a)=>t.setUniform1fv(e,o(a),r),t)}}function Pt(e,t){e.uniforms.add(new It("shR",9,({lighting:e})=>e.sh.r),new It("shG",9,({lighting:e})=>e.sh.g),new It("shB",9,({lighting:e})=>e.sh.b)),e.code.add(O.g`vec3 calculateAmbientIrradiance(vec3 normal) {
vec3 ambientLight = 0.282095 * vec3(shR[0], shG[0], shB[0]);
vec4 sh1 = vec4(
0.488603 * normal.x,
0.488603 * normal.z,
0.488603 * normal.y,
1.092548 * normal.x * normal.y
);
vec4 sh2 = vec4(
1.092548 * normal.y * normal.z,
0.315392 * (3.0 * normal.z * normal.z - 1.0),
1.092548 * normal.x * normal.z,
0.546274 * (normal.x * normal.x - normal.y * normal.y)
);
vec4 lightingAmbientSH_R1 = vec4(shR[1], shR[2], shR[3], shR[4]);
vec4 lightingAmbientSH_G1 = vec4(shG[1], shG[2], shG[3], shG[4]);
vec4 lightingAmbientSH_B1 = vec4(shB[1], shB[2], shB[3], shB[4]);
ambientLight += vec3(
dot(lightingAmbientSH_R1, sh1),
dot(lightingAmbientSH_G1, sh1),
dot(lightingAmbientSH_B1, sh1)
);
vec4 lightingAmbientSH_R2 = vec4(shR[5], shR[6], shR[7], shR[8]);
vec4 lightingAmbientSH_G2 = vec4(shG[5], shG[6], shG[7], shG[8]);
vec4 lightingAmbientSH_B2 = vec4(shB[5], shB[6], shB[7], shB[8]);
ambientLight += vec3(
dot(lightingAmbientSH_R2, sh2),
dot(lightingAmbientSH_G2, sh2),
dot(lightingAmbientSH_B2, sh2)
);
return ambientLight;
}`),1!==t.pbrMode&&2!==t.pbrMode||e.code.add(O.g`const vec3 skyTransmittance = vec3(0.9, 0.9, 1.0);
vec3 calculateAmbientRadiance()
{
vec3 ambientLight = 1.2 * (0.282095 * vec3(shR[0], shG[0], shB[0])) - 0.2;
return ambientLight *= skyTransmittance;
}`)}function Ft(e){e.uniforms.add(new j.ad("mainLightDirection",e=>e.lighting.mainLight.direction))}function Dt(e){e.uniforms.add(new j.ad("mainLightIntensity",e=>e.lighting.mainLight.intensity))}function Rt(e){Ft(e),Dt(e),e.code.add(O.g`vec3 applyShading(vec3 shadingNormal, float shadow) {
float dotVal = clamp(dot(shadingNormal, mainLightDirection), 0.0, 1.0);
return mainLightIntensity * ((1.0 - shadow) * dotVal);
}`)}function jt(e){e.code.add(O.g`vec3 evaluateDiffuseIlluminationHemisphere(vec3 ambientGround, vec3 ambientSky, float NdotNG) {
return ((1.0 - NdotNG) * ambientGround + (1.0 + NdotNG) * ambientSky) * 0.5;
}`),e.code.add(O.g`float integratedRadiance(float cosTheta2, float roughness) {
return (cosTheta2 - 1.0) / (cosTheta2 * (1.0 - roughness * roughness) - 1.0);
}`),e.code.add(O.g`vec3 evaluateSpecularIlluminationHemisphere(vec3 ambientGround, vec3 ambientSky, float RdotNG, float roughness) {
float cosTheta2 = 1.0 - RdotNG * RdotNG;
float intRadTheta = integratedRadiance(cosTheta2, roughness);
float ground = RdotNG < 0.0 ? 1.0 - intRadTheta : 1.0 + intRadTheta;
float sky = 2.0 - ground;
return (ground * ambientGround + sky * ambientSky) * 0.5;
}`)}function zt(e,t){e.include(O.G),e.include(z.P),1!==t.pbrMode&&2!==t.pbrMode&&5!==t.pbrMode&&6!==t.pbrMode||(e.code.add(O.g`float normalDistribution(float NdotH, float roughness)
{
float a = NdotH * roughness;
float b = roughness / (1.0 - NdotH * NdotH + a * a);
return b * b * INV_PI;
}`),e.code.add(O.g`const vec4 c0 = vec4(-1.0, -0.0275, -0.572,  0.022);
const vec4 c1 = vec4( 1.0,  0.0425,  1.040, -0.040);
const vec2 c2 = vec2(-1.04, 1.04);
vec2 prefilteredDFGAnalytical(float roughness, float NdotV) {
vec4 r = roughness * c0 + c1;
float a004 = min(r.x * r.x, exp2(-9.28 * NdotV)) * r.x + r.y;
return c2 * a004 + r.zw;
}`),e.code.add(O.g`struct PBRShadingInfo
{
float NdotV;
float NdotL;
float LdotH;
float NdotUP;
float RdotUP;
float NdotAmbDir;
float NdotH_Horizon;
float NdotH;
vec3 skyRadianceToSurface;
vec3 groundRadianceToSurface;
vec3 skyIrradianceToSurface;
vec3 groundIrradianceToSurface;
vec3 reflectedView;
float averageAmbientRadiance;
vec3 albedoLinear;
vec3 f0;
vec3 f90;
vec3 diffuseColor;
float metalness;
float roughness;
};`),e.code.add(O.g`void calculateCommonInputs(out PBRShadingInfo inputs, vec3 normal, vec3 viewDirection, vec3 upDirection, vec3 albedo) {
vec3 h = normalize(mainLightDirection - viewDirection);
inputs.NdotV = clamp(abs(dot(normal, -viewDirection)), 0.001, 1.0);
inputs.NdotUP = clamp(dot(normal, upDirection), -1.0, 1.0);
inputs.reflectedView = normalize(reflect(-viewDirection, normal));
inputs.RdotUP = clamp(dot(inputs.reflectedView, upDirection), -1.0, 1.0);
inputs.albedoLinear = linearizeGamma(albedo);
inputs.NdotH = clamp(dot(normal, h), 0.0, 1.0);
inputs.NdotL = clamp(dot(normal, mainLightDirection), 0.001, 1.0);
}`)),1!==t.pbrMode&&2!==t.pbrMode||(e.include(jt),e.code.add(O.g`vec3 evaluateEnvironmentIllumination(PBRShadingInfo inputs) {
vec3 indirectDiffuse = evaluateDiffuseIlluminationHemisphere(inputs.groundIrradianceToSurface, inputs.skyIrradianceToSurface, inputs.NdotUP);
vec3 indirectSpecular = evaluateSpecularIlluminationHemisphere(inputs.groundRadianceToSurface, inputs.skyRadianceToSurface, inputs.RdotUP, inputs.roughness);
vec3 diffuseComponent = inputs.diffuseColor * indirectDiffuse * INV_PI;
vec2 dfg = prefilteredDFGAnalytical(inputs.roughness, inputs.NdotV);
vec3 specularColor = inputs.f0 * dfg.x + inputs.f90 * dfg.y;
vec3 specularComponent = specularColor * indirectSpecular;
return (diffuseComponent + specularComponent);
}`),e.code.add(O.g`void calculatePBRInputs(out PBRShadingInfo inputs, vec3 normal, vec3 viewDirection, vec3 upDirection, vec3 albedo, vec3 mrr) {
calculateCommonInputs(inputs, normal, viewDirection, upDirection, albedo);
inputs.metalness = mrr[0];
inputs.roughness = clamp(mrr[1] * mrr[1], 0.001, 0.99);
inputs.f0 = (0.16 * mrr[2] * mrr[2]) * (1.0 - inputs.metalness) + inputs.albedoLinear * inputs.metalness;
inputs.f90 = vec3(clamp(dot(inputs.f0, vec3(50.0 * 0.33)), 0.0, 1.0));
inputs.diffuseColor = inputs.albedoLinear * (vec3(1.0) - inputs.f0) * (1.0 - inputs.metalness);
}`)),5!==t.pbrMode&&6!==t.pbrMode||e.code.add(O.g`const vec3 fresnelReflectionSimplified = vec3(0.04);
void calculateSimplifiedInputs(out PBRShadingInfo inputs, vec3 normal, vec3 viewDirection, vec3 upDirection, vec3 albedo) {
calculateCommonInputs(inputs, normal, viewDirection, upDirection, albedo);
float lightness = 0.3 * inputs.albedoLinear[0] + 0.5 * inputs.albedoLinear[1] + 0.2 * inputs.albedoLinear[2];
inputs.f0 = (0.85 * lightness + 0.15) * fresnelReflectionSimplified;
inputs.f90 =  vec3(clamp(dot(inputs.f0, vec3(50.0 * 0.33)), 0.0, 1.0));
}`)}function Ot(e){e.include(ye),e.uniforms.add(new j.e("zProjectionMapLastFrame",e=>we(e.reprojection.lastFrameCamera))),e.code.add(O.g`float linearDepthFromTextureLastFrame(sampler2D depthTexture, vec2 uv) {
return linearizeDepth(depthFromTexture(depthTexture, uv), zProjectionMapLastFrame);
}`)}function Et(e,t){const o=e.fragment;o.include(ye),o.uniforms.add(new j.e("nearFar",e=>e.camera.nearFar),new j.a3("depthMap",e=>e.depth?.attachment),new j.v("proj",e=>e.camera.projectionMatrix),new j.w("invResolutionHeight",e=>1/e.camera.height),new j.v("reprojectionMatrix",e=>e.reprojection.matrix)).code.add(O.g`
  vec2 reprojectionCoordinate(vec3 projectionCoordinate) {
    vec4 clipDepthCoordinate = proj * vec4(0.0, 0.0, -projectionCoordinate.z, 1.0);
    vec4 reprojectedCoordinate = reprojectionMatrix * vec4(
      clipDepthCoordinate.w * (projectionCoordinate.xy * 2.0 - 1.0),
      clipDepthCoordinate.z,
      clipDepthCoordinate.w
    );
    reprojectedCoordinate.xy /= reprojectedCoordinate.w;
    return reprojectedCoordinate.xy * 0.5 + 0.5;
  }

  vec4 applyProjectionMat(mat4 projectionMat, vec3 viewPosition) {
    vec4 projectedCoordinate =  projectionMat * vec4(viewPosition, 1.0);
    projectedCoordinate.xy /= projectedCoordinate.w;
    projectedCoordinate.xy = projectedCoordinate.xy*0.5 + 0.5;
    return projectedCoordinate;
  }

  float rayMarchScreenReachFromWorldReach(vec3 startPosition, vec3 rayDirection, float rayMarchWorldReach) {
    float rayDistanceWorld = max(0.0, rayMarchWorldReach);

    // Stop rays towards camera at near plane
    if (rayDirection.z > 0.0) {
      float distanceToNearPlane = (-nearFar[0] - startPosition.z) / rayDirection.z;
      rayDistanceWorld = min(rayDistanceWorld, max(0.0, distanceToNearPlane));
    }

    vec2 projectedCoordStart = applyProjectionMat(proj, startPosition).xy;
    vec2 projectedCoordEnd = applyProjectionMat(proj, startPosition + rayDirection * rayDistanceWorld).xy;
    vec2 projectedCoordOffset = projectedCoordEnd - projectedCoordStart;

    return ${t.useProjectedRayLength?"length(projectedCoordOffset)":"abs(projectedCoordOffset.y)"};
  }

  vec3 screenSpaceIntersectionWithLimits(
    vec3 rayDirection,
    vec3 startPosition,
    vec3 viewDirection,
    vec3 normal,
    float rayStepOffset,
    float rayMarchMaxReach,
    float rayMarchMaxSteps
  ) {
    vec3 viewPosition = startPosition;

    // Project the start position to the screen
    vec4 projectedCoordStart = applyProjectionMat(proj, viewPosition);
    vec3 homogeneousStart = viewPosition / projectedCoordStart.w;
    float inverseWStart = 1.0 / projectedCoordStart.w;

    // Advance the position in the ray direction
    viewPosition += rayDirection;

    vec4 projectedCoordVanishingPoint = applyProjectionMat(proj, rayDirection);

    // Project the advanced position to the screen
    vec4 projectedCoordEnd = applyProjectionMat(proj, viewPosition);
    vec3  homogeneousEnd = viewPosition / projectedCoordEnd.w;
    float inverseWEnd = 1.0 / projectedCoordEnd.w;

    // Calculate the ray direction in screen space
    vec2 projectedCoordDirection = (projectedCoordEnd.xy - projectedCoordStart.xy);
    vec2 vanishingPointScreenOffset = (projectedCoordVanishingPoint.xy - projectedCoordStart.xy);

    float rayMarchDistance = ${t.useProjectedRayLength?"length(vanishingPointScreenOffset.xy)":"abs(vanishingPointScreenOffset.y)"};
    float clampedRayMarchDistance = min(rayMarchDistance, rayMarchMaxReach);

    float projectedCoordDirectionLength = length(projectedCoordDirection);

    // normalize the projection direction depending on maximum steps
    // this determines how blocky the ray march looks
    vec2 projectedStep = clampedRayMarchDistance * projectedCoordDirection / (rayMarchMaxSteps * projectedCoordDirectionLength);

    // Normalize the homogeneous camera space coordinates
    vec3 homogeneousStep = clampedRayMarchDistance * (homogeneousEnd - homogeneousStart) / (rayMarchMaxSteps * projectedCoordDirectionLength);
    float inverseWStep = clampedRayMarchDistance * (inverseWEnd - inverseWStart) / (rayMarchMaxSteps * projectedCoordDirectionLength);

    // initialize the variables for ray marching
    vec2 projectedPosition = projectedCoordStart.xy;
    vec3 homogeneousPosition = homogeneousStart;
    float inverseW = inverseWStart;
    float rayStartZ = -startPosition.z; // estimated ray start depth value
    float rayEndZ = -startPosition.z;   // estimated ray end depth value
    float previousEstimatedZ = -startPosition.z;
    float rayDepthDelta = 0.0;
    float estimatedDepthDifference;
    float sampledDepth;

    if (dot(normal, rayDirection) < 0.0 || dot(-viewDirection, normal) < 0.0) {
      return vec3(projectedPosition, 0.0);
    }

    float previousEstimatedDepthDifference = 0.0;

    projectedPosition = clamp(
      projectedPosition + rayStepOffset * projectedStep,
      vec2(0.0),
      vec2(0.999)
    );
    homogeneousPosition.z += rayStepOffset * homogeneousStep.z;
    inverseW += rayStepOffset * inverseWStep;

    int rayMarchMaxStepsInt = int(rayMarchMaxSteps);
    for(int stepIndex = 0; stepIndex < rayMarchMaxStepsInt - 1; ++stepIndex) {
      sampledDepth = -linearDepthFromTexture(depthMap, projectedPosition); // get linear depth from the depth buffer

      // Estimate depth of the marching ray
      rayStartZ = previousEstimatedZ;
      estimatedDepthDifference = -rayStartZ - sampledDepth;
      rayEndZ = (homogeneousStep.z * 0.5 + homogeneousPosition.z) / (inverseWStep * 0.5 + inverseW);
      rayDepthDelta = rayEndZ - rayStartZ;
      previousEstimatedZ = rayEndZ;

      if(-rayEndZ > nearFar[1] || -rayEndZ < nearFar[0] || projectedPosition.y < 0.0  || projectedPosition.y > 1.0 ) {
        return vec3(projectedPosition, 0.);
      }

      // If we detect a hit - return the intersection point, two conditions:
      //  - estimatedDepthDifference > 0.0 - sampled point depth is in front of estimated depth
      //  - if difference between estimatedDepthDifference and rayDepthDelta is not too large
      //  - if difference between estimatedDepthDifference and 0.025/abs(inverseW) is not too large
      //  - if the sampled depth is not behind far plane or in front of near plane

      if(estimatedDepthDifference < 0.025 / abs(inverseW) + abs(rayDepthDelta) &&
        estimatedDepthDifference > 0.0 &&
        sampledDepth > nearFar[0] &&
        sampledDepth < nearFar[1] &&
        abs(projectedPosition.y - projectedCoordStart.y) > invResolutionHeight) {
        float hitInterpolationWeight = estimatedDepthDifference / (estimatedDepthDifference - previousEstimatedDepthDifference);
        vec2 refinedProjectedPosition = mix(projectedPosition - projectedStep, projectedPosition, 1.0 - hitInterpolationWeight);
        if (abs(refinedProjectedPosition.y - projectedCoordStart.y) > invResolutionHeight) {
          return vec3(refinedProjectedPosition, sampledDepth);
        }
        else {
          return vec3(projectedPosition, sampledDepth);
        }
      }

      ${(0,O.I)(!t.clampRayToScreen,"if (projectedPosition.x <= 0.0  || projectedPosition.x >= 1.0) {\n        return vec3(projectedPosition, 0.0);\n      }")}

      // Continue with ray marching
      projectedPosition = projectedPosition + projectedStep;
      homogeneousPosition.z += homogeneousStep.z;
      inverseW += inverseWStep;
      previousEstimatedDepthDifference = estimatedDepthDifference;

      ${(0,O.I)(t.clampRayToScreen,"projectedPosition = clamp(projectedPosition, vec2(0.0), vec2(0.999));")}
    }
    return vec3(projectedPosition, 0.0);
  }

  vec3 screenSpaceIntersection(vec3 rayDirection, vec3 startPosition, vec3 viewDirection, vec3 normal, float rayStepOffset) {
    return screenSpaceIntersectionWithLimits(
      rayDirection,
      startPosition,
      viewDirection,
      normal,
      rayStepOffset,
      ${O.g.float(t.rayMarchMaxReach)},
      ${O.g.float(t.rayMarchMaxSteps)}
    );
  }
  `)}function Bt(e){e.code.add(O.g`
    vec3 quantizeGlobalIlluminationColor(vec3 color) {
      vec3 clampedColor = clamp(color, vec3(0.0), vec3(1.0));
      return floor(clampedColor * ${O.g.float(255)} + 0.5) * ${O.g.float(1/255)};
    }
  `)}class Nt extends B.N{constructor(){super(...arguments),this.projScale=1,this.scaleGlobalIllumination=1,this.accumulatedFrames=0,this.temporalSampleFrame=0,this.rayMarchMinReach=.15,this.rayMarchMaxReach=.5,this.rayMarchWorldReach=25,this.rayMarchMinReachEmissionWeight=1,this.rayMarchMaxReachEmissionWeight=1,this.rayMarchMaxSteps=16,this.colorBleedWeight=.15}}const Wt=Object.freeze(Object.defineProperty({__proto__:null,GlobalIlluminationPassParameters:Nt,build:function(e){const t=new Be.S,o=t.fragment;return t.include(Ie.S),t.include(Se),Ft(o),o.include(Ot),o.include(O.G),o.include(Bt),t.include(Et,e),o.uniforms.add(new O.T("normalMap",e=>e.normalTexture),new O.T("depthMap",e=>e.depthTexture),new j.a3("lastFrameColorTexture",e=>e.reprojection.lastFrameColor?.getTexture()),new j.a3("lastFrameDepthTexture",e=>e.reprojection.lastFrameDepth?.attachment),new j.a3("lastFrameGlobalIlluminationTexture",e=>e.globalIllumination?.getTexture()),new j.a3("lastFrameGlobalIlluminationWeightTexture",e=>e.globalIllumination?.getTexture(We.k)),new j.v("reprojectionViewMatrix",e=>e.reprojection.viewMatrix),new j.v("view",e=>e.camera.viewMatrix),new O.F("accumulatedFrames",e=>e.accumulatedFrames),new O.F("temporalSampleFrame",e=>e.temporalSampleFrame),new O.F("scaleGlobalIllumination",e=>e.scaleGlobalIllumination)),o.uniforms.add(new O.F("rayMarchMinReach",e=>e.rayMarchMinReach),new O.F("rayMarchMaxReach",e=>e.rayMarchMaxReach),new O.F("rayMarchWorldReach",e=>e.rayMarchWorldReach),new O.F("rayMarchMinReachEmissionWeight",e=>e.rayMarchMinReachEmissionWeight),new O.F("rayMarchMaxReachEmissionWeight",e=>e.rayMarchMaxReachEmissionWeight),new O.F("rayMarchMaxSteps",e=>e.rayMarchMaxSteps),new O.F("colorBleedWeight",e=>e.colorBleedWeight)),e.hasEmission&&o.uniforms.add(new j.a3("lastFrameEmissionTexture",e=>e.reprojection.lastFrameEmission?.attachment)),o.code.add(O.g`
    float computeIdleColorBlendWeight(float accumulatedFrames) {
      float idleColorBlendProgress = clamp(
        accumulatedFrames / ${O.g.float(40)},
        0.0,
        1.0
      );
      return mix(
        ${O.g.float(.012)},
        ${O.g.float(.008)},
        idleColorBlendProgress
      );
    }

    float computeIdleOcclusionBlendWeight(float accumulatedFrames) {
      float idleOcclusionBlendProgress = clamp(
        accumulatedFrames / ${O.g.float(60)},
        0.0,
        1.0
      );
      return mix(
        ${O.g.float(.095)},
        ${O.g.float(.008)},
        pow(idleOcclusionBlendProgress, ${O.g.float(2)})
      );
    }

    bool isEdgeDepth(float centerDepth, vec2 sampleUv) {
      vec2 texelSize = 1.0 / vec2(textureSize(depthMap, 0));
      float depthLeft = linearizeDepth(depthFromTexture(depthMap, sampleUv + vec2(-texelSize.x, 0.0)));
      float depthRight = linearizeDepth(depthFromTexture(depthMap, sampleUv + vec2(texelSize.x, 0.0)));
      float depthUp = linearizeDepth(depthFromTexture(depthMap, sampleUv + vec2(0.0, texelSize.y)));
      float depthDown = linearizeDepth(depthFromTexture(depthMap, sampleUv + vec2(0.0, -texelSize.y)));

      float maxDifference = max(max(abs(centerDepth - depthLeft), abs(centerDepth - depthRight)), max(abs(centerDepth - depthUp), abs(centerDepth - depthDown)));

      return abs(maxDifference / centerDepth) > 0.01;
    }

    vec3 sampleCosineHemisphere(vec2 u) {
      float phi = 6.28318530718 * u.x;
      float radius = sqrt(u.y);
      float x = radius * cos(phi);
      float y = radius * sin(phi);
      float z = sqrt(max(0.0, 1.0 - u.y));

      return vec3(x, y, z);
    }

    mat3 basisFromNormal(vec3 n) {
      vec3 up = abs(n.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
      vec3 tangent = normalize(cross(up, n));
      vec3 bitangent = cross(n, tangent);

      return mat3(tangent, bitangent, n);
    }

    float blueNoiseDitherValue(vec2 pixel, float frame, vec2 axis, float phase) {
      float scroll = 5.588238 * mod(frame, 512.0);
      vec2 p = pixel + vec2(scroll);
      vec2 rotated = vec2(
        axis.x * p.x + axis.y * p.y,
        -axis.y * p.x + axis.x * p.y
      );

      return fract(52.9829189 * fract(0.06711056 * rotated.x + 0.00583715 * rotated.y + phase));
    }

    vec4 blueNoiseDither(vec2 pixel, float frame) {
      vec4 value = vec4(
        blueNoiseDitherValue(pixel, frame, vec2(0.9659258, 0.25881904), 0.0),
        blueNoiseDitherValue(pixel, frame, vec2(0.70710677, 0.70710677), 0.17),
        blueNoiseDitherValue(pixel, frame, vec2(0.25881904, 0.9659258), 0.37),
        blueNoiseDitherValue(pixel, frame, vec2(1.0, 0.0), 0.61)
      );

      return value * 2.0 - 1.0;
    }
  `),t.outputs.add("fragGlobalIllumination","vec4",0),t.outputs.add("fragWeight","float",1),o.main.add(O.g`
    float depth = depthFromTexture(depthMap, uv);

    // Early out if depth is out of range, such as in the sky
    if (depth >= 1.0 || depth <= 0.0) {
      fragGlobalIllumination = vec4(0.0, 0.0, 0.0, 1.0);
      fragWeight = 0.0;
      return;
    }

    // Get the normal of current fragment
    ivec2 iuv = ivec2(uv * vec2(textureSize(normalMap, 0)));
    vec4 normal4 = texelFetch(normalMap, iuv, 0);
    if (normal4.a != 1.0) {
      fragGlobalIllumination = vec4(0.0, 0.0, 0.0, 1.0);
      fragWeight = 0.0;
      return;
    }
    vec3 normal = normalize(normal4.xyz * 2.0 - 1.0);

    // Reconstruct view space position of current fragment
    float currentPixelDepth = linearizeDepth(depth);
    vec3 currentPixelPos = reconstructPosition(uv * vec2(textureSize(normalMap, 0)), currentPixelDepth);
    vec4 viewPos = vec4(currentPixelPos, 1.0);

    // Reproject current view position to last frame
    vec4 reprojectedViewPos = reprojectionViewMatrix * viewPos;
    vec4 reprojectedCoordinate = applyProjectionMat(proj, reprojectedViewPos.xyz);

    // Read last frame reprojected depth and GI history
    float lastFrameDepthViewPos = -linearDepthFromTextureLastFrame(lastFrameDepthTexture, reprojectedCoordinate.xy);
    vec4 lastFrameGlobalIllumination = texture(lastFrameGlobalIlluminationTexture, reprojectedCoordinate.xy);
    float historyOcclusionBlendWeight = texture(lastFrameGlobalIlluminationWeightTexture, reprojectedCoordinate.xy).r;

    int steps;
    float occlusionBlendWeight = 1.0;
    float colorBlendWeight = 1.0;
    float idleColorBlendWeight = computeIdleColorBlendWeight(accumulatedFrames);
    float idleOcclusionBlendWeight = computeIdleOcclusionBlendWeight(accumulatedFrames);
    float reprojectionDepthMismatch = abs((lastFrameDepthViewPos + reprojectedViewPos.z) / max(lastFrameDepthViewPos, reprojectedViewPos.z));
    bool hasReprojectionMismatch = reprojectionDepthMismatch > ${O.g.float(.01)};
    bool isScaledGlobalIllumination = scaleGlobalIllumination < 1.0;
    bool isLowQualityEdgePixel = isScaledGlobalIllumination && isEdgeDepth(currentPixelDepth, uv);
    bool resetColorHistory = false;

    // Heuristic to determine blending weights and number of steps for occlusion and color
    if (hasReprojectionMismatch) {
      if (isLowQualityEdgePixel) {
        steps = 1;
        occlusionBlendWeight = ${O.g.float(.008)};
        resetColorHistory = true;
      } else {
        steps = 6;
        occlusionBlendWeight = 1.0;
        resetColorHistory = true;
      }
    } else {
      steps = 1;
      if (historyOcclusionBlendWeight > ${O.g.float(.5)}) {
        occlusionBlendWeight = ${O.g.float(.1)};
        colorBlendWeight = ${O.g.float(.008)};
      } else if (historyOcclusionBlendWeight > ${O.g.float(.02)}) {
        occlusionBlendWeight = historyOcclusionBlendWeight - 0.05;
        colorBlendWeight = ${O.g.float(.008)};
      } else {
        occlusionBlendWeight = isScaledGlobalIllumination ? ${O.g.float(.008)} : idleOcclusionBlendWeight;
        colorBlendWeight = isScaledGlobalIllumination ? ${O.g.float(.002)} : idleColorBlendWeight;
      }
    }

    vec4 randomDirectionSample;
    mat3 normalBasis = basisFromNormal(normal);
    int temporalSampleStride = min(64 / steps, 6);
    float temporalFrameOffset = mod(temporalSampleFrame, float(64 / steps));

    // For each ray determine if it hits geometry and accumulate occlusion or color
    float stepSize = 1.0 / float(steps);
    for (int i = 0; i < steps; ++i) {
      float sampleIndex = float(i * temporalSampleStride + int(temporalFrameOffset));
      randomDirectionSample = blueNoiseDither(floor(gl_FragCoord.xy), sampleIndex);
      vec2 hemisphereSample = randomDirectionSample.rg * 0.5 + 0.5;
      float offsetSample = randomDirectionSample.a * 0.5 + 0.5;
      vec3 rayDirection = normalBasis * sampleCosineHemisphere(hemisphereSample);
      float rayMarchScreenReach = rayMarchScreenReachFromWorldReach(viewPos.xyz, rayDirection, rayMarchWorldReach);
      rayMarchScreenReach = clamp(rayMarchScreenReach, rayMarchMinReach, rayMarchMaxReach);
      vec3 hit = screenSpaceIntersectionWithLimits(
        rayDirection,
        viewPos.xyz,
        normalize(viewPos.xyz),
        normal,
        offsetSample,
        rayMarchScreenReach,
        rayMarchMaxSteps
      );

      if (hit.z > 0.0) {
        ${(0,O.I)(e.hasColor,O.g`
          // Emission and color bleed - Reproject the current receiver and sampled hit to estimate bounced color
          vec3 receiverColor = texture(lastFrameColorTexture, reprojectedCoordinate.xy).rgb;

          vec2 hitReprojectedCoordinate = reprojectionCoordinate(hit);
          vec3 sourceColor = texture(lastFrameColorTexture, hitReprojectedCoordinate).rgb;
          vec3 sourceColorLinear = linearizeGamma(sourceColor);
          vec3 sourceEmission = ${(0,O.I)(e.hasEmission,"texture(lastFrameEmissionTexture, hitReprojectedCoordinate).xyz","vec3(0.0)")};

          float emissionWeight = mix(
            rayMarchMinReachEmissionWeight,
            rayMarchMaxReachEmissionWeight,
            (rayMarchScreenReach - rayMarchMinReach) / max(rayMarchMaxReach - rayMarchMinReach, 0.00001)
          );
          fragGlobalIllumination.rgb += ((sourceColorLinear * colorBleedWeight) + sourceEmission * emissionWeight) * stepSize;
          `)}
      } else {
        // Occlusion - heuristic modulating sky intensity based on angle to main light
        vec4 viewMainLightDirection = view * vec4(mainLightDirection, 0.0);
        float skyModulation = pow(max(dot(rayDirection, viewMainLightDirection.xyz), 0.0), 3.0) * 5.5;
        float skyFacingWeight = clamp(3.5 * dot(viewMainLightDirection.xyz, normal), 0.0, 1.0);
        skyModulation = mix(1.0, skyModulation * 0.2 + 0.8, skyFacingWeight);
        fragGlobalIllumination.a += skyModulation * stepSize;
      }
    }

    // Rendering trick add noise to reduce accumulation artifacts
    float accumulationDither = occlusionBlendWeight < 1.0
      ? randomDirectionSample.b * ${O.g.float(.0039)}
      : 0.0;

    ${(0,O.I)(e.hasColor,O.g`
      // Accumulate color
      vec3 lastFrameColor = lastFrameGlobalIllumination.rgb;
      float colorDitherScale = isScaledGlobalIllumination ? ${O.g.float(.25)} : 1.0;
      fragGlobalIllumination.rgb = resetColorHistory
        ? vec3(0.0)
        : mix(lastFrameColor + accumulationDither * colorDitherScale, fragGlobalIllumination.rgb, colorBlendWeight);
      `,O.g`
      fragGlobalIllumination.rgb = vec3(0.0);
      `)}
    fragGlobalIllumination.rgb = quantizeGlobalIlluminationColor(fragGlobalIllumination.rgb);

    // Accumulate occlusion
    fragGlobalIllumination.a = mix(lastFrameGlobalIllumination.a + accumulationDither, fragGlobalIllumination.a, occlusionBlendWeight);

    fragWeight = occlusionBlendWeight;
  `),t},defaultColorBleedWeight:.15,defaultRayMarchMaxReach:.5,defaultRayMarchMaxReachEmissionWeight:1,defaultRayMarchMaxSteps:16,defaultRayMarchMinReach:.15,defaultRayMarchMinReachEmissionWeight:1,defaultRayMarchWorldReach:25},Symbol.toStringTag,{value:"Module"}));function Gt(e){e.fragment.code.add(O.g`
    float globalIlluminationNormalSimilarityWeight(vec3 sampleNormal, vec3 centerNormal) {
      return clamp(1.0 - ${O.g.float(15.3)} * length(sampleNormal - centerNormal), 0.0, 1.0);
    }

    float globalIlluminationDepthNormalCorrection(vec3 encodedNormal) {
      vec3 decodedNormal = normalize(encodedNormal * 2.0 - 1.0);
      return pow(max((1.0 - abs(decodedNormal.x)) * (1.0 - abs(decodedNormal.y)), 0.01), ${O.g.float(5)});
    }

    float globalIlluminationDepthSharpness(float projScale, float depth) {
      return ${O.g.float(-.05)} * projScale / depth;
    }

    float globalIlluminationDepthSharpness(float projScale, float depth, vec3 encodedNormal) {
      return globalIlluminationDepthSharpness(projScale, depth) * globalIlluminationDepthNormalCorrection(encodedNormal);
    }
  `)}class Lt extends B.N{constructor(){super(...arguments),this.blurSize=(0,c.c)()}}const At=new O.O;At.useFloatBlend=!1;const Vt=Object.freeze(Object.defineProperty({__proto__:null,GlobalIlluminationBlurDrawParameters:Lt,build:function(){const e=new Be.S,t=e.fragment;return e.include(Ie.S),e.include(Se),e.include(Gt),t.include(ye),t.include(j.ax,At),t.include(Bt),t.uniforms.add(new De("hasEmission",e=>e.hasEmission),new O.T("depthMap",e=>e.depthTexture),new O.T("normalMap",e=>e.normalTexture),new O.t("globalIlluminationTexture",e=>e.texture),new O.t("globalIlluminationWeightTexture",e=>e.weightTexture),new Re.F("blurSize",e=>e.blurSize),new O.F("scaleGlobalIllumination",e=>e.scaleGlobalIllumination),new O.F("projScale",(e,t)=>{const o=t.camera.distance;return o>5e4?Math.max(0,e.projScale-(o-5e4)):e.projScale})),t.code.add(O.g`
    void accumulateBlurSample(
      vec2 sampleUv,
      float sampleOffset,
      float centerDepth,
      vec3 centerNormal,
      float depthSharpness,
      bool skipOcclusionBlur,
      inout float emissionWeightSum,
      inout vec3 emissionSum,
      inout float occlusionWeightSum,
      inout float occlusionSum,
      float centerOcclusionBlendWeight
    ) {
      vec4 sampleGlobalIllumination = texture(globalIlluminationTexture, sampleUv);
      vec3 sampleNormal = texture(normalMap, sampleUv).rgb;
      float sampleDepth = linearDepthFromTexture(depthMap, sampleUv);

      float depthDelta = sampleDepth - centerDepth;
      bool isScaledGlobalIllumination = scaleGlobalIllumination < 1.0;
      float normalSimilarityWeight = globalIlluminationNormalSimilarityWeight(sampleNormal, centerNormal);
      float depthNormalCorrection = globalIlluminationDepthNormalCorrection(sampleNormal);
      vec3 emission = sampleGlobalIllumination.rgb;
      float emissionSpatialWeightMultiplier = isScaledGlobalIllumination ? ${O.g.float(400)} : 1.0;

      float emissionWeight = exp(
        -sampleOffset * sampleOffset * ${O.g.float(1/24.5)} * ${O.g.float(.1)} * emissionSpatialWeightMultiplier
        - depthDelta * depthDelta * depthSharpness * depthNormalCorrection
      );
      emissionWeight *= normalSimilarityWeight;
      emissionWeightSum += emissionWeight;
      emissionSum += emissionWeight * emission;

      if (skipOcclusionBlur) {
        return;
      }

      float occlusionSpatialKernelScale = centerOcclusionBlendWeight > ${O.g.float(.03)}
        ? ${O.g.float(.08)}
        : ${O.g.float(1.5)};
      float occlusionWeight = exp(-sampleOffset * sampleOffset * occlusionSpatialKernelScale - depthDelta * depthDelta * depthSharpness);
      occlusionWeight *= normalSimilarityWeight;
      occlusionWeightSum += occlusionWeight;
      occlusionSum += occlusionWeight * sampleGlobalIllumination.a;
    }
  `),t.main.add(O.g`
    vec3 emissionSum = vec3(0.0);
    float emissionWeightSum = 0.0;

    vec4 centerGlobalIllumination = texture(globalIlluminationTexture, uv);
    float centerOcclusionBlendWeight = texture(globalIlluminationWeightTexture, uv).r;
    bool isScaledGlobalIllumination = scaleGlobalIllumination < 1.0;
    bool shouldReuseCenterOcclusion = isScaledGlobalIllumination && centerOcclusionBlendWeight <= ${O.g.float(.03)};
    bool shouldSkipLowQualityBlur = !hasEmission && shouldReuseCenterOcclusion;
    if (shouldSkipLowQualityBlur) {
      fragColor = vec4(
        quantizeGlobalIlluminationColor(centerGlobalIllumination.rgb),
        centerGlobalIllumination.a
      );
      return;
    }

    float centerDepth = linearDepthFromTexture(depthMap, uv);
    vec3 centerNormal = texture(normalMap, uv).rgb;
    float occlusionSum = 0.0;
    float occlusionWeightSum = 0.0;

    float depthSharpness = globalIlluminationDepthSharpness(projScale, centerDepth);
    for (int sampleOffset = -${O.g.int(4)}; sampleOffset <= ${O.g.int(4)}; ++sampleOffset) {
      float sampleOffsetFloat = float(sampleOffset);
      vec2 sampleUv = uv + sampleOffsetFloat * blurSize;
      accumulateBlurSample(
        sampleUv,
        sampleOffsetFloat,
        centerDepth,
        centerNormal,
        depthSharpness,
        shouldReuseCenterOcclusion,
        emissionWeightSum,
        emissionSum,
        occlusionWeightSum,
        occlusionSum,
        centerOcclusionBlendWeight
      );
    }

    float occlusion = shouldReuseCenterOcclusion ? centerGlobalIllumination.a : occlusionSum / occlusionWeightSum;
    vec3 blurredEmission = (emissionSum / emissionWeightSum).rgb;

    // heuristic dithering of the colors to remove banding, color shifts and wrong color accumulation
    float dither = ditherNoise(vec4(blurredEmission, occlusion)) - 1./32768.0;
    blurredEmission += isScaledGlobalIllumination ? 0.85 * dither : dither;

    fragColor = vec4(quantizeGlobalIlluminationColor(blurredEmission), occlusion);
  `),e}},Symbol.toStringTag,{value:"Module"}));let kt=class extends j.j{constructor(){super(...arguments),this.shader=new j.R(Vt,()=>Promise.resolve().then(()=>Vt))}initializePipeline(){return(0,Ne.m)({colorWrite:Ne.d})}};kt=(0,de._)([(0,he.$K)("esri.views.3d.webgl-engine.effects.globalIllumination.GlobalIlluminationBlurTechnique")],kt);let Ut=class extends j.j{constructor(){super(...arguments),this.shader=new j.R(Wt,()=>Promise.resolve().then(()=>Wt))}initializePipeline(){return(0,Ne.m)({colorWrite:Ne.d})}};Ut=(0,de._)([(0,he.$K)("esri.views.3d.webgl-engine.effects.globalIllumination.GlobalIlluminationTechnique")],Ut);class $t extends O.S{constructor(){super(...arguments),this.hasColor=!0,this.hasEmission=!1,this.rayMarchMaxReach=.5,this.rayMarchMaxSteps=16,this.useProjectedRayLength=!0,this.clampRayToScreen=!1}}(0,de._)([(0,O.p)()],$t.prototype,"hasColor",void 0),(0,de._)([(0,O.p)()],$t.prototype,"hasEmission",void 0);class Ht extends B.N{}const qt=Object.freeze(Object.defineProperty({__proto__:null,GlobalIlluminationUpscaleDrawParameters:Ht,build:function(){const e=new Be.S,t=e.fragment;return e.include(Ie.S),e.include(Se),e.include(Gt),t.include(ye),t.include(Bt),t.uniforms.add(new O.T("depthMap",e=>e.depthTexture),new O.T("normalMap",e=>e.normalTexture),new O.t("tex",e=>e.colorTexture),new O.t("globalIlluminationWeightTexture",e=>e.weightTexture),new O.F("projScale",(e,t)=>{const o=t.camera.distance;return o>5e4?Math.max(0,e.projScale-(o-5e4)):e.projScale})),t.code.add(O.g`
    float computeDepthWeight(float sampleDepth, float centerDepth, float depthSharpness) {
      float depthDelta = abs(sampleDepth - centerDepth);
      return exp(-0.08 - depthDelta * depthDelta * depthSharpness);
    }

    vec3 normalFromTexture(sampler2D normalTexture, vec2 uv) {
      ivec2 normalTextureSize = textureSize(normalTexture, 0);
      ivec2 normalTexel = clamp(ivec2(uv * vec2(normalTextureSize)), ivec2(0), normalTextureSize - ivec2(1));
      return texelFetch(normalTexture, normalTexel, 0).xyz;
    }

    void sampleJointBilateralUpscale(vec2 sampleUv, out vec4 upscaledColor, out float upscaledWeight) {
      float centerDepth = linearDepthFromTexture(depthMap, sampleUv);
      vec3 centerNormal = normalFromTexture(normalMap, sampleUv);
      float depthSharpness = ${O.g.float(100)} * globalIlluminationDepthSharpness(projScale, centerDepth, centerNormal);

      vec2 lowResTextureSize = vec2(textureSize(tex, 0));
      vec2 texelPosition = sampleUv * lowResTextureSize - 0.5;
      vec2 texelBase = floor(texelPosition);
      vec2 bilinearWeightsFraction = fract(texelPosition);

      vec2 uv00 = (texelBase + vec2(0.5, 0.5)) / lowResTextureSize;
      vec2 uv10 = (texelBase + vec2(1.5, 0.5)) / lowResTextureSize;
      vec2 uv01 = (texelBase + vec2(0.5, 1.5)) / lowResTextureSize;
      vec2 uv11 = (texelBase + vec2(1.5, 1.5)) / lowResTextureSize;

      vec4 color00 = texture(tex, uv00);
      vec4 color10 = texture(tex, uv10);
      vec4 color01 = texture(tex, uv01);
      vec4 color11 = texture(tex, uv11);
      float weight00 = texture(globalIlluminationWeightTexture, uv00).r;
      float weight10 = texture(globalIlluminationWeightTexture, uv10).r;
      float weight01 = texture(globalIlluminationWeightTexture, uv01).r;
      float weight11 = texture(globalIlluminationWeightTexture, uv11).r;

      float depth00 = linearDepthFromTexture(depthMap, uv00);
      float depth10 = linearDepthFromTexture(depthMap, uv10);
      float depth01 = linearDepthFromTexture(depthMap, uv01);
      float depth11 = linearDepthFromTexture(depthMap, uv11);

      vec3 normal00 = normalFromTexture(normalMap, uv00);
      vec3 normal10 = normalFromTexture(normalMap, uv10);
      vec3 normal01 = normalFromTexture(normalMap, uv01);
      vec3 normal11 = normalFromTexture(normalMap, uv11);

      float bilinearWeight00 = (1.0 - bilinearWeightsFraction.x) * (1.0 - bilinearWeightsFraction.y);
      float bilinearWeight10 = bilinearWeightsFraction.x * (1.0 - bilinearWeightsFraction.y);
      float bilinearWeight01 = (1.0 - bilinearWeightsFraction.x) * bilinearWeightsFraction.y;
      float bilinearWeight11 = bilinearWeightsFraction.x * bilinearWeightsFraction.y;

      float jointBilateralWeight00 = bilinearWeight00 * computeDepthWeight(depth00, centerDepth, depthSharpness) * globalIlluminationNormalSimilarityWeight(normal00, centerNormal);
      float jointBilateralWeight10 = bilinearWeight10 * computeDepthWeight(depth10, centerDepth, depthSharpness) * globalIlluminationNormalSimilarityWeight(normal10, centerNormal);
      float jointBilateralWeight01 = bilinearWeight01 * computeDepthWeight(depth01, centerDepth, depthSharpness) * globalIlluminationNormalSimilarityWeight(normal01, centerNormal);
      float jointBilateralWeight11 = bilinearWeight11 * computeDepthWeight(depth11, centerDepth, depthSharpness) * globalIlluminationNormalSimilarityWeight(normal11, centerNormal);
      float jointBilateralWeightSum = jointBilateralWeight00 + jointBilateralWeight10 + jointBilateralWeight01 + jointBilateralWeight11;

      if (jointBilateralWeightSum < 0.0001) {
        // Fall back to the nearest low-resolution texel when all bilateral weights collapse.
        vec2 nearestUv = (floor(texelPosition + 0.5) + vec2(0.5)) / lowResTextureSize;
        upscaledColor = texture(tex, nearestUv);
        upscaledWeight = texture(globalIlluminationWeightTexture, nearestUv).r;
        return;
      }

      upscaledColor = (
        color00 * jointBilateralWeight00 +
        color10 * jointBilateralWeight10 +
        color01 * jointBilateralWeight01 +
        color11 * jointBilateralWeight11
      ) / jointBilateralWeightSum;

      upscaledWeight = (
        weight00 * jointBilateralWeight00 +
        weight10 * jointBilateralWeight10 +
        weight01 * jointBilateralWeight01 +
        weight11 * jointBilateralWeight11
      ) / jointBilateralWeightSum;
    }
  `),e.outputs.add("fragColor","vec4",0),e.outputs.add("fragWeight","float",1),t.main.add(O.g`sampleJointBilateralUpscale(uv, fragColor, fragWeight);
fragColor.rgb = quantizeGlobalIlluminationColor(fragColor.rgb);`),e}},Symbol.toStringTag,{value:"Module"}));let Zt=class extends j.j{constructor(){super(...arguments),this.shader=new j.R(qt,()=>Promise.resolve().then(()=>qt))}initializePipeline(){return(0,Ne.m)({colorWrite:Ne.d})}};Zt=(0,de._)([(0,he.$K)("esri.views.3d.webgl-engine.effects.globalIllumination.GlobalIlluminationUpscaleTechnique")],Zt);let Jt=class extends Ee.A{constructor(e){super(e),this.consumes={required:["normals"]},this.produces=Oe.OG.AMBIENT_ILLUMINATION,this._passParameters=new Nt,this._drawParameters=new Lt,this._drawParametersUpscale=new Ht,this._maxFrames=256,this._lowQualityResolutionScale=.25,this._configuration=new $t,this._globalIllumination=null,this._isGlobalIlluminationUpdate=!1,this._resetBuffer=!1}initialize(){this.addHandles((0,je.wB)(()=>this.view.stage.renderer.hasGlobalIllumination,()=>{this._resetAccumulatedFrames(),this._requestRender()},je.pc))}destroy(){this._globalIllumination=(0,E.f)(this._globalIllumination)}resetAccumulatedFrames(){this._isGlobalIlluminationUpdate||this._resetAccumulatedFrames()}render(e){if(this._passParameters.accumulatedFrames>=this._maxFrames)return this._globalIllumination?.retain(),this._globalIllumination;const t=e.find(({name:e})=>"normals"===e),o=t?.getTexture(),r=t?.getTexture(We.b),a=this._mode;if(!o||!r)return this._emptyOutput;if(0===a)return this._resetBuffer=!1,this._emptyOutput;if(!this._canRender)return this._resetBuffer=!1,this._requestRender(),this._emptyOutput;const i=this.bindParameters;this._configuration.hasEmission=!!i.reprojection.lastFrameEmission;const n=this.techniques.getCompiled(Ut,this._configuration),s=this.techniques.getCompiled(kt),l=1===a,c=l?this._lowQualityResolutionScale:1,u=l?this.techniques.getCompiled(Zt):null;if(!n||!s||l&&!u)return this._requestRender(),this._emptyOutput;const d=this.renderingContext,{camera:h}=i;this._passParameters.normalTexture=o,this._passParameters.depthTexture=r,this._passParameters.projScale=1/h.computeScreenPixelSizeAtDist(1),this._passParameters.scaleGlobalIllumination=c;const{fullWidth:m,fullHeight:p}=h,f=Math.max(1,Math.floor(m*c)),g=Math.max(1,Math.floor(p*c)),v=this.fboCache.acquire(f,g,"global illumination input").acquireColor(We.k,0);d.bindFramebuffer(v.fbo),d.setViewport(0,0,f,g),d.bindTechnique(n,i,this._passParameters,this._drawParameters),d.screen.draw();const x=v.obtainAttachment(We.k),b=Math.max(1,Math.round(f/1)),y=Math.max(1,Math.round(g/1)),w=this.fboCache.acquire(b,y,"global illumination blur horizontal");d.bindFramebuffer(w.fbo),this._drawParameters.texture=v.getTexture(),this._drawParameters.weightTexture=x.attachment,(0,xe.s)(this._drawParameters.blurSize,0,1/g),d.bindTechnique(s,i,this._passParameters,this._drawParameters),d.setViewport(0,0,b,y),d.screen.draw(),v.release();const M=l?"global illumination blur vertical":Oe.OG.AMBIENT_ILLUMINATION,S=this.fboCache.acquire(b,y,M);d.bindFramebuffer(S.fbo),d.setViewport(0,0,b,y),d.setClearColor(1,1,1,0),d.clear(16384),this._drawParameters.texture=w.getTexture(),this._drawParameters.weightTexture=x.attachment,(0,xe.s)(this._drawParameters.blurSize,1/b,0),d.bindTechnique(s,i,this._passParameters,this._drawParameters),d.setViewport(0,0,b,y),d.screen.draw(),w.release(),S.attachColor(x,We.k),x.release();let T=S;return u&&(T=this.fboCache.acquire(m,p,Oe.OG.AMBIENT_ILLUMINATION).acquireColor(We.k,0),d.bindFramebuffer(T.fbo),d.setViewport(0,0,m,p),d.setClearColor(1,1,1,0),d.clear(16384),this._drawParametersUpscale.colorTexture=S.getTexture(),this._drawParametersUpscale.weightTexture=S.getTexture(We.k),d.bindTechnique(u,i,this._passParameters,this._drawParametersUpscale),d.screen.draw(),S.release()),d.setViewport4fv(h.fullViewport),this._passParameters.temporalSampleFrame=(this._passParameters.temporalSampleFrame+1)%64,++this._passParameters.accumulatedFrames,this._cacheGlobalIllumination(T),this._passParameters.accumulatedFrames<this._maxFrames&&this._requestRender(),T}_requestRender(){this._isGlobalIlluminationUpdate=!0,this.requestRender(1),this._isGlobalIlluminationUpdate=!1}_cacheGlobalIllumination(e){this._globalIllumination!==e&&(this._globalIllumination=(0,E.f)(this._globalIllumination),this._globalIllumination=e,this._globalIllumination.retain())}get _emptyOutput(){const e=this.renderingContext,{fullWidth:t,fullHeight:o}=this.bindParameters.camera,r=this.fboCache.acquire(t,o,Oe.OG.AMBIENT_ILLUMINATION).acquireColor(We.k,0);return e.bindFramebuffer(r.fbo),e.setViewport(0,0,t,o),e.clearBuffer(0,[0,0,0,1]),e.clearBuffer(1,[0,0,0,0]),r}get _canRender(){const{reprojection:e,hasEmission:t,globalIllumination:o}=this.bindParameters;return!(!e.lastFrameColor||t&&!e.lastFrameEmission||!e.lastFrameDepth||!o||this._resetBuffer)}get _mode(){const{hasGlobalIlluminationHighQuality:e,hasGlobalIllumination:t}=this.view.stage.renderer;return e?2:t?1:0}_resetAccumulatedFrames(){this._passParameters.accumulatedFrames=0,this._globalIllumination=(0,E.f)(this._globalIllumination)}get test(){const e=this;return{passParameters:this._passParameters,configuration:this._configuration,get maxFrames(){return e._maxFrames},set maxFrames(t){e._maxFrames=t},get lowQualityResolutionScale(){return e._lowQualityResolutionScale},set lowQualityResolutionScale(t){e._lowQualityResolutionScale=t},get mode(){return e._mode},restartAccumulation:()=>{this._resetAccumulatedFrames(),this._passParameters.temporalSampleFrame=0,this._resetBuffer=!0,this._requestRender()}}}};function Yt(e,t){t.receiveGlobalIllumination?(e.uniforms.add(new De("hasGlobalIlluminationTexture",e=>null!=e.globalIllumination),new j.a3("globalIlluminationTexture",e=>e.globalIllumination?.getTexture())),e.constants.add("blurSizePixelsInverse","float",1),e.code.add(O.g`vec3 readGlobalIlluminationOcclusionInverse() {
if (!hasGlobalIlluminationTexture) {
return vec3(1.0);
}
ivec2 texel = ivec2(gl_FragCoord.xy * blurSizePixelsInverse);
return vec3(texelFetch(globalIlluminationTexture, texel, 0).a);
}
vec3 readGlobalIlluminationOcclusion() {
return 1.0 - readGlobalIlluminationOcclusionInverse();
}
vec4 readGlobalIlluminationEmissionInverse() {
if (!hasGlobalIlluminationTexture) {
return vec4(1.0);
}
ivec2 texel = ivec2(gl_FragCoord.xy * blurSizePixelsInverse);
return 1.0 - vec4(texelFetch(globalIlluminationTexture, texel, 0).rgb, 0.0);
}
vec4 readGlobalIlluminationEmission() {
return max((1.0 - readGlobalIlluminationEmissionInverse() - 0.01) / 0.99, 0.0);
}`)):e.code.add(O.g`vec3 readGlobalIlluminationOcclusionInverse() { return vec3(1.0); }
vec3 readGlobalIlluminationOcclusion() { return vec3(0.0); }
vec4 readGlobalIlluminationEmissionInverse() { return vec4(1.0); }
vec4 readGlobalIlluminationEmission() { return vec4(0.0); }`)}function Xt(e){e.code.add(O.g`float mapChannel(float x, vec2 p) {
if((x < p.x) && (p.x == 0.0) || !(x < p.x) && (p.x == 1.0)) {
return 0.0;
}
float result = (x < p.x) ? mix(0.0, p.y, x/p.x) : mix(p.y, 1.0, (x - p.x) / (1.0 - p.x) );
return max(result, 0.0);
}`),e.code.add(O.g`vec3 blackLevelSoftCompression(vec3 color, float averageAmbientRadiance) {
vec2 p = vec2(0.02, 0.0075) * averageAmbientRadiance;
return vec3(mapChannel(color.x, p), mapChannel(color.y, p), mapChannel(color.z, p));
}`)}function Kt(e){e.code.add(O.g`vec3 tonemapACES(vec3 x) {
return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}`),e.code.add(O.g`vec3 tonemapKhronosNeutral(vec3 color) {
const float startCompression = 0.76;
const float desaturation = 0.15;
float peak = max(color.r, max(color.g, color.b));
if (peak < startCompression) {
return color;
}
float d = 1.0 - startCompression;
float newPeak = 1.0 - d * d / (peak + d - startCompression);
color *= newPeak / peak;
float g = 1.0 - 1.0 / (desaturation * (peak - newPeak) + 1.0 );
return mix(color, vec3(newPeak), g);
}`)}function Qt(e){e.constants.add("ambientBoostFactor","float",Re.a)}function eo(e){e.uniforms.add(new j.w("lightingGlobalFactor",e=>e.lighting.globalFactor))}function to(e,t){const{pbrMode:o,spherical:r,hasColorTexture:a,receiveGlobalIllumination:i}=t;e.include(O.G),e.include(Yt,t),e.include(_t,t),0!==o&&e.include(zt,t),e.include(Pt,t),e.include(z.P),e.include(Kt,t);const n=!(2===o&&!a);n&&e.include(Xt),Qt(e),eo(e),Ft(e),e.code.add(O.g`
    float additionalDirectedAmbientLight(float lightAlignment) {
      return smoothstep(0.0, 1.0, clamp(lightAlignment * 2.5, 0.0, 1.0));
    }

    float additionalDirectedAmbientLight(vec3 vPosWorld) {
      float lightAlignment = dot(${r?O.g`normalize(vPosWorld)`:O.g`vec3(0.0, 0.0, 1.0)`}, mainLightDirection);
      return smoothstep(0.0, 1.0, clamp(lightAlignment * 2.5, 0.0, 1.0));
    }
  `),Dt(e),e.code.add(O.g`vec3 evaluateAdditionalLighting(float ambientOcclusion, vec3 vPosWorld) {
float additionalAmbientScale = additionalDirectedAmbientLight(vPosWorld);
return (1.0 - ambientOcclusion) * additionalAmbientScale * ambientBoostFactor * lightingGlobalFactor * mainLightIntensity;
}`);const s=i?"globalIlluminationOcclusion":"ssao",l=i?.75:1,c=i?1.5:1;switch(o){case 0:case 4:case 3:e.include(Rt),e.code.add(O.g`vec3 evaluateSceneLighting(vec3 normalWorld, vec3 albedo, float shadow, float ssao, vec3 additionalLight) {
vec3 mainLighting = applyShading(normalWorld, shadow);
vec3 ambientLighting = calculateAmbientIrradiance(normalWorld) * (1.0 - ssao);
vec3 albedoLinear = linearizeGamma(albedo);
vec3 totalLight = mainLighting + ambientLighting + additionalLight;
totalLight = min(totalLight, vec3(PI));
vec3 outColor = vec3((albedoLinear / PI) * totalLight);
return delinearizeGamma(outColor);
}`);break;case 1:case 2:{const o=i?.35:.2;e.code.add(O.g`
        const float fillLightIntensity = 0.25;
        const float horizonLightDiffusion = 0.4;
        const float additionalAmbientIrradianceFactor = 0.02;
        const float groundReflectance = ${O.g.float(o)};

        vec3 evaluateSceneLightingPBR(vec3 normal, vec3 albedo, float shadow, float ssao, vec3 additionalLight,
                                      vec3 viewDirection, vec3 upDirection, vec3 mrr, float additionalAmbientIrradiance) {
          PBRShadingInfo inputs;
          calculatePBRInputs(inputs, normal, viewDirection, upDirection, albedo, mrr);

          ${(0,O.I)(i,O.g`vec3 globalIlluminationOcclusion = min(1.2 * readGlobalIlluminationOcclusion(), 1.0);`)}
      `),t.useFillLights?e.uniforms.add(new De("hasFillLights",e=>e.enableFillLights)):e.constants.add("hasFillLights","bool",!1),e.code.add(O.g`
        vec3 ambientDir = vec3(5.0 * upDirection[1] - upDirection[0] * upDirection[2], - 5.0 * upDirection[0] - upDirection[2] * upDirection[1], upDirection[1] * upDirection[1] + upDirection[0] * upDirection[0]);
        ambientDir = ambientDir != vec3(0.0) ? normalize(ambientDir) : normalize(vec3(5.0, -1.0, 0.0));

        inputs.NdotAmbDir = hasFillLights ? abs(dot(normal, ambientDir)) : 1.0;

        // Calculate the irradiance components: sun, fill lights and the sky.
        vec3 mainLightIrradianceComponent = ${O.g.float(l)} * inputs.NdotL * (1.0 - shadow) * mainLightIntensity;
        vec3 fillLightsIrradianceComponent = inputs.NdotAmbDir * mainLightIntensity * fillLightIntensity;
        // calculate ambient irradiance for localView and additionalLight for globalView
        vec3 ambientLightIrradianceComponent = ${O.g.float(c)} * calculateAmbientIrradiance(normal) * (1.0 - ${s}) + additionalLight;

        // Assemble the overall irradiance of the sky that illuminates the surface
        inputs.skyIrradianceToSurface = ambientLightIrradianceComponent + mainLightIrradianceComponent + fillLightsIrradianceComponent ;
        // Assemble the overall irradiance of the ground that illuminates the surface. for this we use the simple model that changes only the sky irradiance by the groundReflectance
        inputs.groundIrradianceToSurface = groundReflectance * ambientLightIrradianceComponent + mainLightIrradianceComponent + fillLightsIrradianceComponent ;
      `),e.uniforms.add(new j.w("lightingSpecularStrength",e=>e.lighting.mainLight.specularStrength),new j.w("lightingEnvironmentStrength",e=>e.lighting.mainLight.environmentStrength)).code.add(O.g`
        vec3 horizonRingDir = inputs.RdotUP * upDirection - inputs.reflectedView;
        vec3 horizonRingH = normalize(horizonRingDir - viewDirection);
        inputs.NdotH_Horizon = dot(normal, horizonRingH);

        vec3 mainLightRadianceComponent = lightingSpecularStrength * normalDistribution(inputs.NdotH, inputs.roughness) * mainLightIntensity * (1.0 - shadow);
        vec3 horizonLightRadianceComponent = lightingEnvironmentStrength * normalDistribution(inputs.NdotH_Horizon, min(inputs.roughness + horizonLightDiffusion, 1.0)) * mainLightIntensity * fillLightIntensity;

        // calculateAmbientRadiance for localView and additionalLight for global view
        vec3 ambientLightRadianceComponent = lightingEnvironmentStrength * calculateAmbientRadiance() * (1.0 - ${s}) + additionalLight;
        float normalDirectionModifier = mix(1., min(mix(0.1, 2.0, (inputs.NdotUP + 1.) * 0.5), 1.0), clamp(inputs.roughness * 5.0, 0.0 , 1.0));

        // Assemble the overall radiance of the sky that illuminates the surface
        inputs.skyRadianceToSurface = (ambientLightRadianceComponent + horizonLightRadianceComponent) * normalDirectionModifier + mainLightRadianceComponent;

        // Assemble the overall radiance of the ground that illuminates the surface. for this we use the simple model that changes only the sky radiance by the groundReflectance
        inputs.groundRadianceToSurface = 0.5 * groundReflectance * (ambientLightRadianceComponent + horizonLightRadianceComponent) * normalDirectionModifier + mainLightRadianceComponent;

        // Calculate average ambient radiance - This is used in the gamut mapping process to determine the black level for compression
        inputs.averageAmbientRadiance = ambientLightIrradianceComponent[1] * (1.0 + groundReflectance);
      `),e.code.add(O.g`
        vec3 reflectedColorComponent = evaluateEnvironmentIllumination(inputs);
        vec3 additionalMaterialReflectanceComponent = inputs.albedoLinear * additionalAmbientIrradiance;
        vec3 outColorLinear = reflectedColorComponent + additionalMaterialReflectanceComponent;

        ${(0,O.I)(i,O.g`
        vec3 globalIlluminationEmission = 2.25 * (0.75 * inputs.albedoLinear + 0.25) * readGlobalIlluminationEmission().rgb;
        outColorLinear += globalIlluminationEmission;`)}

      ${n?O.g`vec3 adjustedOutColorLinear = blackLevelSoftCompression(outColorLinear, inputs.averageAmbientRadiance);`:O.g`vec3 adjustedOutColorLinear = max(vec3(0.0), outColorLinear - 0.005 * inputs.averageAmbientRadiance);`}

        return delinearizeGamma(adjustedOutColorLinear);
      }
    `);break}case 5:case 6:{const t=i?.35:.5,o=i?.75:1,r=i?1.5:1;Ft(e),Dt(e),e.code.add(O.g`
      const float roughnessTerrain = 0.5;
      const float specularityTerrain = ${O.g.float(t)};

      vec3 evaluatePBRSimplifiedLighting(vec3 normal, vec3 albedo, float shadow, float ssao, vec3 additionalLight, vec3 viewDirection, vec3 upDirection) {
        PBRShadingInfo inputs;
        calculateSimplifiedInputs(inputs, normal, viewDirection, upDirection, albedo);

        ${(0,O.I)(i,O.g`vec3 globalIlluminationOcclusion = min(1.2 * readGlobalIlluminationOcclusion(), 1.0);`)}

        vec3 mainLightIrradianceComponent = ${O.g.float(o)} * (1.0 - shadow) * inputs.NdotL * mainLightIntensity;
        vec3 ambientLightIrradianceComponent = ${O.g.float(r)} * calculateAmbientIrradiance(normal) * (1.0 - ${s}) + additionalLight;
        vec3 ambientSky = ambientLightIrradianceComponent + mainLightIrradianceComponent;

        vec3 indirectDiffuse = ((1.0 - inputs.NdotUP) * mainLightIrradianceComponent + (1.0 + inputs.NdotUP ) * ambientSky) * 0.5;
        vec3 outDiffColor = inputs.albedoLinear * (1.0 - inputs.f0) * indirectDiffuse / PI;

        vec3 mainLightRadianceComponent = normalDistribution(inputs.NdotH, roughnessTerrain) * mainLightIntensity;
        vec2 dfg = prefilteredDFGAnalytical(roughnessTerrain, inputs.NdotV);
        vec3 specularColor = inputs.f0 * dfg.x + inputs.f90 * dfg.y;
        vec3 specularComponent = specularityTerrain * specularColor * mainLightRadianceComponent;

        vec3 outColorLinear = outDiffColor + specularComponent;

        ${(0,O.I)(i,O.g`
        vec3 globalIlluminationEmission = 2.25 * (0.75 * inputs.albedoLinear + 0.25) * readGlobalIlluminationEmission().rgb;
        outColorLinear += globalIlluminationEmission;`)}

        return delinearizeGamma(outColorLinear);
      }
      `);break}}}function oo(e,t){const o=e.fragment;switch(o.code.add(O.g`struct ShadingNormalParameters {
vec3 normalView;
vec3 viewDirection;
} shadingParams;`),t.doubleSidedMode){case 0:o.code.add(O.g`vec3 shadingNormal(ShadingNormalParameters params) {
return normalize(params.normalView);
}`);break;case 1:o.code.add(O.g`vec3 shadingNormal(ShadingNormalParameters params) {
return dot(params.normalView, params.viewDirection) > 0.0 ? normalize(-params.normalView) : normalize(params.normalView);
}`);break;case 2:o.code.add(O.g`vec3 shadingNormal(ShadingNormalParameters params) {
return gl_FrontFacing ? normalize(params.normalView) : normalize(-params.normalView);
}`);break;default:t.doubleSidedMode;case 3:}}function ro(e,t){const o=t.pbrMode,r=e.fragment;if(2!==o&&0!==o&&1!==o)return void r.code.add(O.g`void applyPBRFactors() {}`);if(0===o)return void r.code.add(O.g`void applyPBRFactors() {}
float getBakedOcclusion() { return 1.0; }`);if(2===o)return void r.code.add(O.g`vec3 mrr = vec3(0.0, 0.6, 0.2);
float occlusion = 1.0;
void applyPBRFactors() {}
float getBakedOcclusion() { return 1.0; }`);const{hasMetallicRoughnessTexture:a,hasMetallicRoughnessTextureTransform:i,hasOcclusionTexture:n,hasOcclusionTextureTransform:s,bindType:l}=t;(a||n)&&e.include(O.V,t),r.code.add(O.g`vec3 mrr;
float occlusion;`),a&&r.uniforms.add(1===l?new O.T("texMetallicRoughness",e=>e.textureMetallicRoughness):new O.t("texMetallicRoughness",e=>e.textureMetallicRoughness)),n&&r.uniforms.add(1===l?new O.T("texOcclusion",e=>e.textureOcclusion):new O.t("texOcclusion",e=>e.textureOcclusion)),r.uniforms.add(1===l?new O.j("mrrFactors",e=>e.mrrFactors):new O.q("mrrFactors",e=>e.mrrFactors)),r.code.add(O.g`
    ${(0,O.I)(a,O.g`void applyMetallicRoughness(vec2 uv) {
            vec3 metallicRoughness = textureLookup(texMetallicRoughness, uv).rgb;
            mrr[0] *= metallicRoughness.b;
            mrr[1] *= metallicRoughness.g;
          }`)}

    ${(0,O.I)(n,"void applyOcclusion(vec2 uv) { occlusion *= textureLookup(texOcclusion, uv).r; }")}

    float getBakedOcclusion() {
      return ${n?"occlusion":"1.0"};
    }

    void applyPBRFactors() {
      mrr = mrrFactors;
      occlusion = 1.0;

      ${(0,O.I)(a,`applyMetallicRoughness(${i?"metallicRoughnessUV":"vuv0"});`)}
      ${(0,O.I)(n,`applyOcclusion(${s?"occlusionUV":"vuv0"});`)}
    }
  `)}function ao(e,t){const o=(0,O.c)(t.output)&&t.receiveShadows;o&&function(e,t){(function(e){e.varyings.add("linearDepth","float",{invariant:!0})})(e),e.vertex.code.add(O.g`
    void forwardLinearDepth(float _linearDepth) { ${(0,O.I)(t,"linearDepth = _linearDepth;")} }
  `)}(e,!0),e.vertex.code.add(O.g`
    void forwardLinearDepthToReadShadowMap() { ${(0,O.I)(o,"forwardLinearDepth(gl_Position.w);")} }
  `)}(0,de._)([(0,he.MZ)()],Jt.prototype,"consumes",void 0),(0,de._)([(0,he.MZ)()],Jt.prototype,"produces",void 0),Jt=(0,de._)([(0,he.$K)("esri.views.3d.webgl-engine.effects.globalIllumination.GlobalIllumination")],Jt);class io extends O.U{constructor(e,t,o,r){super(e,"mat4",2,(o,a,i,n)=>o.setUniformMatrices4fv(e,t(a,i,n),r),o)}}function no(e){e.uniforms.add(new Le("shadowMapMatrix",(e,t)=>t.shadowMap.getShadowMapMatrices(e.origin),4)),e.include(lo)}function so(e){e.uniforms.add(new io("shadowMapMatrix",(e,t)=>t.shadowMap.getShadowMapMatrices(e.origin),4)),e.include(lo)}function lo(e){e.uniforms.add(new z.F("cascadeDistances",e=>e.shadowMap.cascadeDistances),new j.ay("numCascades",e=>e.shadowMap.numCascades)),e.code.add(co)}B.N;const co=O.g`const vec3 invalidShadowmapUVZ = vec3(0.0, 0.0, -1.0);
vec3 lightSpacePosition(vec3 _vpos, mat4 mat) {
vec4 lv = mat * vec4(_vpos, 1.0);
lv.xy /= lv.w;
return 0.5 * lv.xyz + vec3(0.5);
}
vec2 cascadeCoordinates(int i, ivec2 textureSize, vec3 lvpos) {
float xScale = float(textureSize.y) / float(textureSize.x);
return vec2((float(i) + lvpos.x) * xScale, lvpos.y);
}
vec3 calculateUVZShadow(in vec3 _worldPos, in float _linearDepth, in ivec2 shadowMapSize) {
int i = _linearDepth < cascadeDistances[1] ? 0 : _linearDepth < cascadeDistances[2] ? 1 : _linearDepth < cascadeDistances[3] ? 2 : 3;
if (i >= numCascades) {
return invalidShadowmapUVZ;
}
mat4 shadowMatrix = i == 0 ? shadowMapMatrix[0] : i == 1 ? shadowMapMatrix[1] : i == 2 ? shadowMapMatrix[2] : shadowMapMatrix[3];
vec3 lvpos = lightSpacePosition(_worldPos, shadowMatrix);
if (lvpos.z >= 1.0 || lvpos.x < 0.0 || lvpos.x > 1.0 || lvpos.y < 0.0 || lvpos.y > 1.0) {
return invalidShadowmapUVZ;
}
vec2 uvShadow = cascadeCoordinates(i, shadowMapSize, lvpos);
return vec3(uvShadow, lvpos.z);
}`;function uo(e){e.code.add(O.g`float readShadowMapUVZ(vec3 uvzShadow, sampler2DShadow _shadowMap) {
return texture(_shadowMap, uvzShadow);
}`)}class ho extends O.U{constructor(e,t){super(e,"sampler2DShadow",0,(o,r)=>o.bindTexture(e,t(r)))}}function mo(e,t){t.receiveShadows&&e.fragment.include(no),fo(e,t)}function po(e,t){t.receiveShadows&&e.fragment.include(so),fo(e,t)}function fo(e,t){e.fragment.uniforms.add(new j.w("lightingGlobalFactor",e=>e.lighting.globalFactor));const{hasShadowHighlights:o,receiveShadows:r,spherical:a}=t;e.include(ao,t),r&&function(e,t){(function(e,t){e.include(uo),e.uniforms.add(new ho("shadowMap",({shadowMap:e})=>e.getOutput(5)??e.getOutput(7))),t&&e.uniforms.add(new j.a3("shadowHighlight",({shadowHighlight:e})=>e?.getTexture())),e.code.add(O.g`
    float readShadowMaps(const in vec3 uvzShadow) {
      if (uvzShadow.z < 0.0) {
        return 0.0;
      }

      float shadow1 = readShadowMapUVZ(uvzShadow, shadowMap);
      ${(0,O.I)(t,"float shadow2 = texelFetch(shadowHighlight, ivec2(gl_FragCoord.xy), 0).r;\n         return shadow1 > shadow2 ? shadow1 : shadow2;","return shadow1;")}
    }
  `)})(e,t),function(e){e.code.add(O.g`float readShadowMap(const in vec3 _worldPos, float _linearDepth) {
vec3 uvzShadow = calculateUVZShadow(_worldPos, _linearDepth, textureSize(shadowMap, 0));
return readShadowMaps(uvzShadow);
}`)}(e)}(e.fragment,o),e.fragment.code.add(O.g`
    float readShadow(float additionalAmbientScale, vec3 vpos) {
      return ${r?"max(lightingGlobalFactor * (1.0 - additionalAmbientScale), readShadowMap(vpos, linearDepth))":(0,O.I)(a,"lightingGlobalFactor * (1.0 - additionalAmbientScale)","0.0")};
    }
  `)}function go(e,t){t.hasColorTextureTransform?(e.varyings.add("colorUV","vec2"),e.vertex.uniforms.add(new j.af("colorTextureTransformMatrix",e=>e.colorTextureTransformMatrix??n.I)).code.add(O.g`void forwardColorUV(){
colorUV = (colorTextureTransformMatrix * vec3(vuv0, 1.0)).xy;
}`)):e.vertex.code.add(O.g`void forwardColorUV(){}`)}function vo(e,t){t.hasNormalTextureTransform&&0!==t.textureCoordinateType?(e.varyings.add("normalUV","vec2"),e.vertex.uniforms.add(new j.af("normalTextureTransformMatrix",e=>e.normalTextureTransformMatrix??n.I)).code.add(O.g`void forwardNormalUV(){
normalUV = (normalTextureTransformMatrix * vec3(vuv0, 1.0)).xy;
}`)):e.vertex.code.add(O.g`void forwardNormalUV(){}`)}function xo(e,t){t.hasEmissionTextureTransform&&0!==t.textureCoordinateType?(e.varyings.add("emissiveUV","vec2"),e.vertex.uniforms.add(new j.af("emissiveTextureTransformMatrix",e=>e.emissiveTextureTransformMatrix??n.I)).code.add(O.g`void forwardEmissiveUV(){
emissiveUV = (emissiveTextureTransformMatrix * vec3(vuv0, 1.0)).xy;
}`)):e.vertex.code.add(O.g`void forwardEmissiveUV(){}`)}function bo(e,t){t.hasOcclusionTextureTransform&&0!==t.textureCoordinateType?(e.varyings.add("occlusionUV","vec2"),e.vertex.uniforms.add(new j.af("occlusionTextureTransformMatrix",e=>e.occlusionTextureTransformMatrix??n.I)).code.add(O.g`void forwardOcclusionUV(){
occlusionUV = (occlusionTextureTransformMatrix * vec3(vuv0, 1.0)).xy;
}`)):e.vertex.code.add(O.g`void forwardOcclusionUV(){}`)}function yo(e,t){t.hasMetallicRoughnessTextureTransform&&0!==t.textureCoordinateType?(e.varyings.add("metallicRoughnessUV","vec2"),e.vertex.uniforms.add(new j.af("metallicRoughnessTextureTransformMatrix",e=>e.metallicRoughnessTextureTransformMatrix??n.I)).code.add(O.g`void forwardMetallicRoughnessUV(){
metallicRoughnessUV = (metallicRoughnessTextureTransformMatrix * vec3(vuv0, 1.0)).xy;
}`)):e.vertex.code.add(O.g`void forwardMetallicRoughnessUV(){}`)}function wo(e,t){t.snowCover&&(e.uniforms.add(new j.w("snowCover",e=>e.snowCover)).code.add(O.g`float getSnow(vec3 normal, vec3 groundNormal) {
return smoothstep(0.5, 0.55, dot(normal, groundNormal)) * snowCover;
}
float getRealisticTreeSnow(vec3 faceNormal, vec3 shadingNormal, vec3 groundNormal) {
float snow = min(1.0, smoothstep(0.5, 0.55, dot(faceNormal, groundNormal)) +
smoothstep(0.5, 0.55, dot(-faceNormal, groundNormal)) +
smoothstep(0.0, 0.1, dot(shadingNormal, groundNormal)));
return snow * snowCover;
}`),e.code.add(O.g`vec3 applySnowToMRR(vec3 mrr, float snow) {
return mix(mrr, vec3(0.0, 1.0, 0.04), snow);
}`))}B.N;const Mo=Object.freeze(Object.defineProperty({__proto__:null,build:function(e){const t=new Be.S,{attributes:o,vertex:r,fragment:a,varyings:i}=t,{output:n,normalType:s,offsetBackfaces:l,spherical:c,snowCover:u,pbrMode:d,textureAlphaPremultiplied:h,instancedDoublePrecision:m,hasVertexColors:p,hasVertexTangents:f,hasColorTexture:g,hasNormalTexture:v,hasNormalTextureTransform:x,hasColorTextureTransform:b}=e;if((0,j.f)(r,e),o.add("position","vec3"),r.inputs.add("position",()=>"position"),i.add("vpos","vec3",{invariant:!0}),t.include(j.V,e),t.include(lt,e),t.include(Pe,e),t.include(go,e),!(0,O.c)(n))return t.include(ht,e),t;t.include(vo,e),t.include(xo,e),t.include(bo,e),t.include(yo,e),(0,j.c)(r,e),t.include(ke,e),t.include(le);const y=0===s||1===s;return y&&l&&t.include(it),t.include(mt,e),t.include(Ue,e),t.include(nt,e),i.add("vPositionLocal","vec3"),t.include(O.h,e),t.include(ut,e),t.include(ce,e),r.uniforms.add(new j.F("externalColor",e=>e.externalColor,{supportsNaN:!0})),i.add("vcolorExt","vec4"),r.include(j.L),r.include(j.N),t.include(m?mo:po,e),r.main.add(O.g`
    forwardVertexColor();

    MaskedColor maskedColor =
      applySymbolColor(applyVVColor(applyInstanceColor(createMaskedFromNaNColor(externalColor))));

    vcolorExt = maskedColor.color;
    forwardColorMixMode(maskedColor.mask);

    vpos = getVertexInLocalOriginSpace();
    vPositionLocal = vpos - view[3].xyz;
    vpos = subtractOrigin(vpos);
    ${(0,O.I)(y,"vNormalWorld = dpNormal(vvLocalNormal(normalModel()));")}
    vpos = addVerticalOffset(vpos, localOrigin);
    ${(0,O.I)(f,"vTangent = dpTransformVertexTangent(tangent);")}
    gl_Position = transformPosition(proj, view, vpos);
    ${(0,O.I)(y&&l,"gl_Position = offsetBackfacingClipPosition(gl_Position, vpos, vNormalWorld, cameraPosition);")}

    forwardTextureCoordinates();
    forwardColorUV();
    forwardNormalUV();
    forwardEmissiveUV();
    forwardOcclusionUV();
    forwardMetallicRoughnessUV();

    if (opacityMixMode != ${O.g.int(j.Q.ignore)} && vcolorExt.a < ${O.g.float(Ae.a)}) {
      gl_Position = vec4(1e38, 1e38, 1e38, 1.0);
    }
    forwardLinearDepthToReadShadowMap();
  `),a.include(to,e),a.include(_t,e),t.include(dt,e),a.include(j.S,e),t.include(j.h,e),(0,j.c)(a,e),a.uniforms.add(r.uniforms.get("localOrigin"),new O.j("ambient",e=>e.ambient),new O.j("diffuse",e=>e.diffuse),new O.F("opacity",e=>e.opacity),new O.F("layerOpacity",e=>e.layerOpacity)),g&&a.uniforms.add(new O.T("tex",e=>e.texture)),t.include(ro,e),a.include(zt,e),a.include(z.b),t.include(oo,e),a.include(wo,e),Qt(a),eo(a),Dt(a),a.main.add(O.g`
    discardBySlice(vpos);
    ${g?O.g`
            vec4 texColor = texture(tex, ${b?"colorUV":"vuv0"});
            ${(0,O.I)(h,"texColor.rgb /= texColor.a;")}
            discardOrAdjustAlpha(texColor);`:O.g`vec4 texColor = vec4(1.0);`}
    shadingParams.viewDirection = normalize(vpos - cameraPosition);
    ${2===s?O.g`vec3 normal = screenDerivativeNormal(vPositionLocal);`:O.g`shadingParams.normalView = vNormalWorld;
                vec3 normal = shadingNormal(shadingParams);`}
    applyPBRFactors();
    float ssao = evaluateAmbientOcclusionInverse() * getBakedOcclusion();

    vec3 posWorld = vpos + localOrigin;

    float additionalAmbientScale = additionalDirectedAmbientLight(posWorld);
    float shadow = readShadow(additionalAmbientScale, vpos);

    vec3 matColor = max(ambient, diffuse);
    vec3 albedo = mixExternalColor(${(0,O.I)(p,"vColor.rgb *")} matColor, texColor.rgb, vcolorExt.rgb, colorMixMode);
    float opacity_ = layerOpacity * mixExternalOpacity(${(0,O.I)(p,"vColor.a * ")} opacity, texColor.a, vcolorExt.a, opacityMixMode);

    ${v?`mat3 tangentSpace = computeTangentSpace(${f?"normal":"normal, vpos, vuv0"});\n           vec3 shadingNormal = computeTextureNormal(tangentSpace, ${x?"normalUV":"vuv0"});`:"vec3 shadingNormal = normal;"}
    vec3 normalGround = ${c?"normalize(posWorld);":"vec3(0.0, 0.0, 1.0);"}

    ${(0,O.I)(u,O.g`
          float snow = getSnow(normal, normalGround);
          albedo = mix(albedo, vec3(1), snow);
          shadingNormal = mix(shadingNormal, normal, snow);
          ssao = mix(ssao, 1.0, snow);`)}

    vec3 additionalLight = ssao * mainLightIntensity * additionalAmbientScale * ambientBoostFactor * lightingGlobalFactor;

    ${1===d||2===d?O.g`
            float additionalAmbientIrradiance = additionalAmbientIrradianceFactor * mainLightIntensity[2];
            ${(0,O.I)(u,"mrr = applySnowToMRR(mrr, snow);")}
            vec3 shadedColor = evaluateSceneLightingPBR(shadingNormal, albedo, shadow, 1.0 - ssao, additionalLight, shadingParams.viewDirection, normalGround, mrr, additionalAmbientIrradiance);`:O.g`vec3 shadedColor = evaluateSceneLighting(shadingNormal, albedo, shadow, 1.0 - ssao, additionalLight);`}
    vec4 finalColor = vec4(shadedColor, opacity_);
    outputColorHighlightOLID(applySlice(finalColor, vpos), albedo ${(0,O.I)(u,", snow")});
  `),t}},Symbol.toStringTag,{value:"Module"}));class So extends $e{constructor(){super(...arguments),this.isSchematic=!1,this.usePBR=!1,this.mrrFactors=ot,this.hasVertexColors=!1,this.hasSymbolColors=!1,this.doubleSided=!1,this.doubleSidedType="normal",this.cullFace=2,this.instanced=!1,this.instancedFeatureAttribute=!1,this.instancedColor=!1,this.instanceColorEncodesAlphaIgnore=!1,this.emissiveStrengthFromSymbol=0,this.emissiveStrengthKHR=1,this.emissiveSource=1,this.emissiveBaseColor=d.Z,this.instancedDoublePrecision=!1,this.normalType=0,this.receiveShadows=!0,this.receiveAmbientOcclusion=!0,this.castShadows=!0,this.ambient=(0,d.g)(.2,.2,.2),this.diffuse=(0,d.g)(.8,.8,.8),this.externalColor=(0,me.f)(1,1,1,1),this.colorMixMode="multiply",this.opacity=1,this.layerOpacity=1,this.origin=(0,d.c)(),this.hasSlicePlane=!1,this.offsetTransparentBackfaces=!1,this.vvSize=null,this.vvColor=null,this.vvOpacity=null,this.modelTransformation=null,this.drivenOpacity=!1,this.writeDepth=!0,this.customDepthTest=0,this.textureAlphaMode=0,this.textureAlphaCutoff=Ae.a,this.textureAlphaPremultiplied=!1,this.renderOccluded=1,this.testsTransparentRenderOrder=0,this.isDecoration=!1}get hasVVSize(){return!!this.vvSize}get hasVVColor(){return!!this.vvColor}get hasVVOpacity(){return!!this.vvOpacity}}let To=class extends j.j{constructor(e,t){let o=(0,pe.g)(Io(t));t.instanced&&t.instancedDoublePrecision&&(o=o.concat((0,pe.g)(function(e){return Je(tt.clone(),e)}(t)))),super(e,t,o),this.shader=new j.R(Mo,()=>Promise.resolve().then(()=>Mo)),this.ignoreUnused=!0}_makePipeline(e,t){const{output:o,transparent:r,cullFace:a,customDepthTest:i,hasOccludees:n}=e;return(0,Ne.m)({blending:r?(0,j.r)(o,!1,e.emissionDimmingPass):null,culling:_o(e)?(0,Ne.c)(a):null,depthTest:(0,j.q)(o,Co(i)),depthWrite:(0,j.n)(e),colorWrite:Ne.d,stencilWrite:n?j.l:null,stencilTest:n?t?j.s:j.k:null,polygonOffset:(0,j.p)(e)})}initializePipeline(e){return this._occludeePipelineState=this._makePipeline(e,!0),this._makePipeline(e,!1)}getPipeline(e,t,o){return o?this._occludeePipelineState:super.getPipeline(e,t,o)}};function Co(e){switch(e){case 1:return 515;case 0:case 3:return 513;case 2:return 516}}function _o(e){return 0!==e.cullFace||!e.hasSlicePlane&&!e.transparent&&!e.doubleSidedMode}function Io(e){const t=(0,pe.n)().vec3f("position");return 1===e.normalType?t.vec2i16("normalCompressed",{glNormalized:!0}):t.vec3f("normal"),e.hasVertexTangents&&t.vec4f("tangent"),e.hasTextures&&t.vec2f16("uv0"),e.hasVertexColors&&t.vec4u8("color",{glNormalized:!0}),e.hasSymbolColors&&t.vec4u8("symbolColor"),!e.instanced&&(0,j.o)()&&t.vec4u8("olidColor"),t}To=(0,de._)([(0,he.$K)("esri.views.3d.webgl-engine.shaders.DefaultMaterialTechnique")],To);class Po extends j.T{constructor(e){super(),this.spherical=e,this.alphaDiscardMode=1,this.doubleSidedMode=0,this.pbrMode=0,this.cullFace=0,this.normalType=0,this.customDepthTest=0,this.emissionSource=0,this.hasVertexColors=!1,this.hasSymbolColors=!1,this.hasVerticalOffset=!1,this.hasColorTexture=!1,this.hasMetallicRoughnessTexture=!1,this.hasOcclusionTexture=!1,this.hasNormalTexture=!1,this.hasScreenSizePerspective=!1,this.hasVertexTangents=!1,this.hasOccludees=!1,this.instanced=!1,this.instancedDoublePrecision=!1,this.hasModelTransformation=!1,this.offsetBackfaces=!1,this.hasVVSize=!1,this.hasVVColor=!1,this.receiveShadows=!1,this.hasShadowHighlights=!1,this.receiveAmbientOcclusion=!1,this.receiveGlobalIllumination=!1,this.textureAlphaPremultiplied=!1,this.instancedFeatureAttribute=!1,this.instancedColor=!1,this.writeDepth=!0,this.snowCover=!1,this.hasColorTextureTransform=!1,this.hasEmissionTextureTransform=!1,this.hasNormalTextureTransform=!1,this.hasOcclusionTextureTransform=!1,this.hasMetallicRoughnessTextureTransform=!1,this.useCustomDTRExponentForWater=!1,this.useFillLights=!0,this.draped=!1}get textureCoordinateType(){return this.hasTextures?1:0}get hasTextures(){return this.hasColorTexture||this.hasNormalTexture||this.hasMetallicRoughnessTexture||3===this.emissionSource||this.hasOcclusionTexture}get hasVVInstancing(){return this.instanced}get discardInvisibleFragments(){return this.transparent}}(0,de._)([(0,O.p)({count:4})],Po.prototype,"alphaDiscardMode",void 0),(0,de._)([(0,O.p)({count:3})],Po.prototype,"doubleSidedMode",void 0),(0,de._)([(0,O.p)({count:7})],Po.prototype,"pbrMode",void 0),(0,de._)([(0,O.p)({count:3})],Po.prototype,"cullFace",void 0),(0,de._)([(0,O.p)({count:3})],Po.prototype,"normalType",void 0),(0,de._)([(0,O.p)({count:3})],Po.prototype,"customDepthTest",void 0),(0,de._)([(0,O.p)({count:8})],Po.prototype,"emissionSource",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasVertexColors",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasSymbolColors",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasVerticalOffset",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasColorTexture",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasMetallicRoughnessTexture",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasOcclusionTexture",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasNormalTexture",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasScreenSizePerspective",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasVertexTangents",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasOccludees",void 0),(0,de._)([(0,O.p)()],Po.prototype,"instanced",void 0),(0,de._)([(0,O.p)()],Po.prototype,"instancedDoublePrecision",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasModelTransformation",void 0),(0,de._)([(0,O.p)()],Po.prototype,"offsetBackfaces",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasVVSize",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasVVColor",void 0),(0,de._)([(0,O.p)()],Po.prototype,"receiveShadows",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasShadowHighlights",void 0),(0,de._)([(0,O.p)()],Po.prototype,"receiveAmbientOcclusion",void 0),(0,de._)([(0,O.p)()],Po.prototype,"receiveGlobalIllumination",void 0),(0,de._)([(0,O.p)()],Po.prototype,"textureAlphaPremultiplied",void 0),(0,de._)([(0,O.p)()],Po.prototype,"instancedFeatureAttribute",void 0),(0,de._)([(0,O.p)()],Po.prototype,"instancedColor",void 0),(0,de._)([(0,O.p)()],Po.prototype,"writeDepth",void 0),(0,de._)([(0,O.p)()],Po.prototype,"snowCover",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasColorTextureTransform",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasEmissionTextureTransform",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasNormalTextureTransform",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasOcclusionTextureTransform",void 0),(0,de._)([(0,O.p)()],Po.prototype,"hasMetallicRoughnessTextureTransform",void 0);const Fo=Object.freeze(Object.defineProperty({__proto__:null,build:function(e){const t=new Be.S,{attributes:o,vertex:r,fragment:a,varyings:i}=t,{output:n,offsetBackfaces:s,pbrMode:l,snowCover:c,spherical:u}=e,d=1===l||2===l;if((0,j.f)(r,e),o.add("position","vec3"),r.inputs.add("position",()=>"position"),i.add("vpos","vec3",{invariant:!0}),t.include(j.V,e),t.include(lt,e),t.include(Pe,e),t.include(go,e),!(0,O.c)(n))return t.include(ht,e),t;t.include(xo,e),(0,j.c)(t.vertex,e),t.include(ke,e),t.include(le),s&&t.include(it),i.add("vNormalWorld","vec3"),i.add("localvpos","vec3",{invariant:!0}),t.include(O.h,e),t.include(ut,e),t.include(nt,e),t.include(ce,e),r.include(j.L),r.include(j.N),r.uniforms.add(new j.F("externalColor",e=>e.externalColor,{supportsNaN:!0})),i.add("vcolorExt","vec4"),t.include(e.instancedDoublePrecision?mo:po,e),r.include(j.P),r.main.add(O.g`
    forwardVertexColor();

    MaskedColor maskedColorExt =
      applySymbolColor(applyVVColor(applyInstanceColor(createMaskedFromNaNColor(externalColor))));

    vcolorExt = maskedColorExt.color;
    forwardColorMixMode(maskedColorExt.mask);

    bool alphaCut = opacityMixMode != ${O.g.int(j.Q.ignore)} && vcolorExt.a < alphaCutoff;
    vpos = getVertexInLocalOriginSpace();

    localvpos = vpos - view[3].xyz;
    vpos = subtractOrigin(vpos);
    vNormalWorld = dpNormal(vvLocalNormal(normalModel()));
    vpos = addVerticalOffset(vpos, localOrigin);
    vec4 basePosition = transformPosition(proj, view, vpos);

    forwardTextureCoordinates();
    forwardColorUV();
    forwardEmissiveUV();
    forwardLinearDepthToReadShadowMap();
    gl_Position = alphaCut ? vec4(1e38, 1e38, 1e38, 1.0) :
    ${(0,O.I)(s,"offsetBackfacingClipPosition(basePosition, vpos, vNormalWorld, cameraPosition);","basePosition;")}
  `);const{hasColorTexture:h,hasColorTextureTransform:m}=e;return a.include(to,e),a.include(_t,e),t.include(dt,e),a.include(j.S,e),t.include(j.h,e),(0,j.c)(a,e),Ft(a),Qt(a),eo(a),a.uniforms.add(r.uniforms.get("localOrigin"),r.uniforms.get("view"),new O.j("ambient",e=>e.ambient),new O.j("diffuse",e=>e.diffuse),new O.F("opacity",e=>e.opacity),new O.F("layerOpacity",e=>e.layerOpacity)),h&&a.uniforms.add(new O.T("tex",e=>e.texture)),t.include(ro,e),a.include(zt,e),a.include(z.b),a.include(wo,e),Dt(a),a.main.add(O.g`
      discardBySlice(vpos);
      vec4 texColor = ${h?`texture(tex, ${m?"colorUV":"vuv0"})`:" vec4(1.0)"};
      ${(0,O.I)(h,`${(0,O.I)(e.textureAlphaPremultiplied,"texColor.rgb /= texColor.a;")}\n        discardOrAdjustAlpha(texColor);`)}
      vec3 viewDirection = normalize(vpos - cameraPosition);
      applyPBRFactors();
      float ssao = evaluateAmbientOcclusionInverse();
      ssao *= getBakedOcclusion();

      float additionalAmbientScale = additionalDirectedAmbientLight(vpos + localOrigin);
      vec3 additionalLight = ssao * mainLightIntensity * additionalAmbientScale * ambientBoostFactor * lightingGlobalFactor;
      float shadow = readShadow(additionalAmbientScale, vpos);
      vec3 matColor = max(ambient, diffuse);
      ${e.hasVertexColors?O.g`vec3 albedo = mixExternalColor(vColor.rgb * matColor, texColor.rgb, vcolorExt.rgb, colorMixMode);
             float opacity_ = layerOpacity * mixExternalOpacity(vColor.a * opacity, texColor.a, vcolorExt.a, opacityMixMode);`:O.g`vec3 albedo = mixExternalColor(matColor, texColor.rgb, vcolorExt.rgb, colorMixMode);
             float opacity_ = layerOpacity * mixExternalOpacity(opacity, texColor.a, vcolorExt.a, opacityMixMode);`}

      vec3 shadingNormal = normalize(vNormalWorld);
      vec3 groundNormal = ${u?"normalize(vpos + localOrigin)":"vec3(0.0, 0.0, 1.0)"};

      ${(0,O.I)(c,"vec3 faceNormal = screenDerivativeNormal(vpos);\n         float snow = getRealisticTreeSnow(faceNormal, shadingNormal, groundNormal);\n         albedo = mix(albedo, vec3(1), snow);")}

      ${O.g`albedo *= 1.2;
             vec3 viewForward = vec3(view[0][2], view[1][2], view[2][2]);
             float alignmentLightView = clamp(dot(viewForward, -mainLightDirection), 0.0, 1.0);
             float transmittance = 1.0 - clamp(dot(viewForward, shadingNormal), 0.0, 1.0);
             float treeRadialFalloff = vColor.r;
             float backLightFactor = 0.5 * treeRadialFalloff * alignmentLightView * transmittance * (1.0 - shadow);
             additionalLight += backLightFactor * mainLightIntensity;`}

      ${d?O.g`float additionalAmbientIrradiance = additionalAmbientIrradianceFactor * mainLightIntensity[2];
            ${(0,O.I)(c,"mrr = applySnowToMRR(mrr, snow);")}
            vec3 shadedColor = evaluateSceneLightingPBR(shadingNormal, albedo, shadow, 1.0 - ssao, additionalLight, viewDirection, groundNormal, mrr, additionalAmbientIrradiance);`:O.g`vec3 shadedColor = evaluateSceneLighting(shadingNormal, albedo, shadow, 1.0 - ssao, additionalLight);`}
      vec4 finalColor = vec4(shadedColor, opacity_);
      outputColorHighlightOLID(applySlice(finalColor, vpos), albedo ${(0,O.I)(c,", 1.0")});`),t}},Symbol.toStringTag,{value:"Module"}));let Do=class extends To{constructor(){super(...arguments),this.shader=new j.R(Fo,()=>Promise.resolve().then(()=>Fo))}};Do=(0,de._)([(0,he.$K)("esri.views.3d.webgl-engine.shaders.RealisticTreeTechnique")],Do),(0,de._)([(0,O.p)()],class extends O.S{constructor(){super(...arguments),this.receiveShadows=!0}}.prototype,"receiveShadows",void 0);class Ro extends j.M{constructor(e,t){super(e,zo),this.materialType="default",this.supportsEdges=!0,this.intersectDraped=void 0,this.produces=new Map([[2,e=>(0,O.k)(e)&&!this.transparent],[4,e=>(0,O.k)(e)&&this.transparent&&this.parameters.writeDepth],[8,e=>(0,O.k)(e)&&this.transparent&&!this.parameters.writeDepth]]),this._layout=Io(this.parameters),this._configuration=new Po(t.spherical)}isVisibleForOutput(e){return 5!==e&&7!==e&&6!==e||this.parameters.castShadows}get visible(){const{layerOpacity:e,colorMixMode:t,opacity:o,externalColor:r}=this.parameters;return e*("replace"===t?1:o)*("ignore"===t||isNaN(r[3])?1:r[3])>=Ae.a}get _hasEmissiveBase(){return!!this.parameters.emissiveTextureId||!(0,u.m)(this.parameters.emissiveBaseColor,d.Z)}get emissions(){return this.parameters.emissiveStrength>0&&(0===this.parameters.emissiveSource&&this._hasEmissiveBase||1===this.parameters.emissiveSource)?this.transparent?2:1:0}updateConfiguration(e){super.updateConfiguration(e);const{parameters:t,_configuration:o}=this;o.hasNormalTexture=t.hasNormalTexture,o.hasColorTexture=t.hasColorTexture,o.hasMetallicRoughnessTexture=t.hasMetallicRoughnessTexture,o.hasOcclusionTexture=t.hasOcclusionTexture;const{treeRendering:r,doubleSided:a,doubleSidedType:i}=t;o.hasVertexTangents=!r&&t.hasVertexTangents,o.instanced=t.instanced,o.instancedDoublePrecision=t.instancedDoublePrecision,o.hasVVColor=!!t.vvColor,o.hasVVSize=!!t.vvSize,o.hasVerticalOffset=null!=t.verticalOffset,o.hasScreenSizePerspective=null!=t.screenSizePerspective,o.hasSlicePlane=t.hasSlicePlane,o.alphaDiscardMode=t.textureAlphaMode,o.normalType=r?0:t.normalType,o.transparent=this.transparent,o.enableOITOffset=e.enableOITOffset,o.writeDepth=t.writeDepth,o.customDepthTest=t.customDepthTest??0,o.hasOccludees=e.hasOccludees,o.cullFace=t.hasSlicePlane?0:t.cullFace,o.hasModelTransformation=!r&&null!=t.modelTransformation,o.hasVertexColors=t.hasVertexColors,o.hasSymbolColors=t.hasSymbolColors,o.doubleSidedMode=r?2:a&&"normal"===i?1:a&&"winding-order"===i?2:0,o.instancedFeatureAttribute=t.instancedFeatureAttribute,o.instancedColor=t.instancedColor,(0,O.c)(e.output)?(o.receiveShadows=t.receiveShadows,o.hasShadowHighlights=function(e,t){return e.receiveShadows&&null!=t.shadowHighlight?.getTexture()}(o,e),o.receiveAmbientOcclusion=t.receiveAmbientOcclusion&&null!=e.ssao,o.receiveGlobalIllumination=t.receiveAmbientOcclusion&&e.globalIlluminationEnabled):o.receiveShadows=o.hasShadowHighlights=o.receiveAmbientOcclusion=!1,o.textureAlphaPremultiplied=!!t.textureAlphaPremultiplied,o.pbrMode=t.usePBR?t.isSchematic?2:1:0,o.emissionSource=t.emissionSource,o.offsetBackfaces=!(!this.transparent||!t.offsetTransparentBackfaces),o.snowCover=e.snowCover>0,o.hasColorTextureTransform=!!t.colorTextureTransformMatrix,o.hasNormalTextureTransform=!!t.normalTextureTransformMatrix,o.hasEmissionTextureTransform=!!t.emissiveTextureTransformMatrix,o.hasOcclusionTextureTransform=!!t.occlusionTextureTransformMatrix,o.hasMetallicRoughnessTextureTransform=!!t.metallicRoughnessTextureTransformMatrix}intersect(e,t,o,r,a,i){if(null!=this.parameters.verticalOffset){const e=o.camera;(0,u.h)(Go,t[12],t[13],t[14]);let i=null;switch(o.viewingMode){case 1:i=(0,u.n)(No,Go);break;case 2:i=(0,u.f)(No,Bo)}const n=(0,u.o)(Lo,Go,e.eye),s=(0,u.b)(n),l=(0,u.q)(n,n,1/s);let c=null;this.parameters.screenSizePerspective&&(c=(0,u.d)(i,l));const d=(0,j.U)(e,s,this.parameters.verticalOffset,c??0,this.parameters.screenSizePerspective,null);(0,u.q)(i,i,d),(0,u.t)(Wo,i,o.transform.inverseRotation),r=(0,u.o)(Oo,r,Wo),a=(0,u.o)(Eo,a,Wo)}i=function(e,t,o,r){ae.output=t.transparent?1:0,ae.polygonOffset=t.polygonOffset,ae.enableOITOffset=t.enableOITOffset;const a=(0,j.p)(ae);if(!a)return e;const i=2e-6*a.units,n=(0,u.n)(ie,(0,u.a)(ie,r,o));return(t,o,r,s)=>{const l=(r?1-Math.abs((0,u.d)(n,r)):0)*a.factor*2e-5+i;return e(t,o+l,r,s)}}(i,this._configuration,r,a),k(e,o,r,a,(0,ue.g)(o.verticalOffset),i)}createGLMaterial(e){return new jo(e)}createBufferWriter(){return new L(this._layout)}get transparent(){return function(e){const{drivenOpacity:t,opacity:o,externalColor:r,layerOpacity:a,texture:i,textureId:n,textureAlphaMode:s,colorMixMode:l}=e,c=r[3];return t||o<1&&"replace"!==l||c<1&&"ignore"!==l||a<1||(null!=i||null!=n)&&1!==s&&2!==s&&"replace"!==l}(this.parameters)}}class jo extends N{constructor(e){super({...e,...e.material.parameters})}beginSlot(e){this._material.setParameters({receiveShadows:e.shadowMap.enabled});const t=this._material.parameters;this.updateTexture(t.textureId);const o=e.camera.viewInverseTransposeMatrix;return(0,u.h)(t.origin,o[3],o[7],o[11]),this._material.setParameters(this.textureBindParameters),this.getTechnique(t.treeRendering?Do:To,e)}}class zo extends So{constructor(){super(...arguments),this.treeRendering=!1,this.useIndexing=!1,this.hasVertexTangents=!1}get hasNormalTexture(){return!this.treeRendering&&!!this.normalTextureId}get hasColorTexture(){return!!this.textureId}get hasMetallicRoughnessTexture(){return!this.treeRendering&&!!this.metallicRoughnessTextureId}get hasOcclusionTexture(){return!this.treeRendering&&!!this.occlusionTextureId}get emissiveStrength(){return this.emissiveStrengthFromSymbol*this.emissiveStrengthKHR}get emissionSource(){return null!=this.emissiveTextureId&&0===this.emissiveSource?3:0===this.emissiveSource?2:1}get hasTextures(){return this.hasColorTexture||this.hasNormalTexture||this.hasMetallicRoughnessTexture||3===this.emissionSource||this.hasOcclusionTexture}}const Oo=(0,d.c)(),Eo=(0,d.c)(),Bo=(0,d.f)(0,0,1),No=(0,d.c)(),Wo=(0,d.c)(),Go=(0,d.c)(),Lo=(0,d.c)();class Ao{constructor(){this._outer=new Map}clear(){this._outer.clear()}get empty(){return 0===this._outer.size}get outerSize(){return this._outer.size}get size(){let e=0;for(const t of this._outer.values())e+=t.size;return e}get(e,t){return this._outer.get(e)?.get(t)}getInner(e){return this._outer.get(e)}set(e,t,o){const r=this._outer.get(e);r?r.set(t,o):this._outer.set(e,new Map([[t,o]]))}delete(e,t){const o=this._outer.get(e);o&&(o.delete(t),0===o.size&&this._outer.delete(e))}pop(e,t){const o=this.get(e,t);return this.delete(e,t),o}*outerMap(){for(const e of this._outer)yield e}*values(){for(const e of this._outer.values())yield*e.values()}*[Symbol.iterator](){for(const[e,t]of this._outer)for(const[o,r]of t)yield[e,o,r]}forEach(e){this._outer.forEach((t,o)=>e(t,o))}forAll(e){this._outer.forEach((t,o)=>t.forEach((t,r)=>e(t,o,r)))}copy(){const e=new Ao;return this.forAll((t,o,r)=>e.set(o,r,t)),e}}const Vo=()=>C.L.getLogger("esri.views.3d.layers.graphics.objectResourceUtils");class ko{constructor(e,t,o){this.resource=e,this.textures=t,this.usedMemory=o}}function Uo(e){const t=e.params,o=t.topology;let r=!0;switch(t.vertexAttributes||(Vo().warn("Geometry must specify vertex attributes"),r=!1),t.topology){case"PerAttributeArray":break;case"Indexed":case null:case void 0:{const e=t.faces;if(e){if(t.vertexAttributes)for(const o in t.vertexAttributes){const t=e[o];t?.values?(null!=t.valueType&&"UInt32"!==t.valueType&&(Vo().warn(`Unsupported indexed geometry indices type '${t.valueType}', only UInt32 is currently supported`),r=!1),null!=t.valuesPerElement&&1!==t.valuesPerElement&&(Vo().warn(`Unsupported indexed geometry values per element '${t.valuesPerElement}', only 1 is currently supported`),r=!1)):(Vo().warn(`Indexed geometry does not specify face indices for '${o}' attribute`),r=!1)}}else Vo().warn("Indexed geometries must specify faces"),r=!1;break}default:Vo().warn(`Unsupported topology '${o}'`),r=!1}e.params.material||(Vo().warn("Geometry requires material"),r=!1);const a=e.params.vertexAttributes;for(const e in a)a[e].values||(Vo().warn("Geometries with externally defined attributes are not yet supported"),r=!1);return r}function $o(e){const t=(0,h.b)();return e.forEach(e=>{const o=e.boundingInfo;null!=o&&((0,h.e)(t,o.bbMin),(0,h.e)(t,o.bbMax))}),t}function Ho(e){switch(e){case"mask":return 2;case"maskAndTransparency":return 3;case"none":return 1;default:return 0}}function qo(e){const t=e.params;return{id:1,material:t.material,texture:t.texture,region:t.texture}}const Zo=new P.A(1,2,"wosr");function Jo(e){if(null==e)return null;const t=null!=e.offset?e.offset:w.Z,o=null!=e.rotation?e.rotation:0,r=null!=e.scale?e.scale:w.O,a=(0,n.f)(1,0,0,0,1,0,t[0],t[1],1),i=(0,n.f)(Math.cos(o),-Math.sin(o),0,Math.sin(o),Math.cos(o),0,0,0,1),s=(0,n.f)(r[0],0,0,0,r[1],0,0,0,1),l=(0,n.c)();return(0,n.a)(l,i,s),(0,n.a)(l,a,l),l}class Yo{constructor(){this.geometries=new Array,this.materials=new Array,this.textures=new Array}}class Xo{constructor(e,t,o){this.name=e,this.lodThreshold=t,this.pivotOffset=o,this.stageResources=new Yo,this.numberOfVertices=0}}function Ko(e){const t=e.match(/(.*\.(gltf|glb))(\?lod=([0-9]+))?$/);return t?{fileType:"gltf",url:t[1],specifiedLodIndex:null!=t[4]?Number(t[4]):null}:{fileType:e.match(/(.*\.(json|json\.gz))$/)?"wosr":"unknown",url:e,specifiedLodIndex:null}}const Qo=(0,n.c)(),er=Object.freeze(Object.defineProperty({__proto__:null,fetch:async function(e,t){const m=Ko((0,a.a)(e));if("wosr"===m.fileType){const e=await(t.cache?t.cache.loadWOSR(m.url,t):async function(e,t){const o=await async function(e,t){const o=await(0,S.r)((0,M.A)(e,t));return o.ok?o.value.data:((0,I.QP)(o.error),void function(e){throw new T.A("",`Request for object resource failed: ${e}`)}(o.error))}(e,t),r=await async function(e,t){const o=new Array;for(const r in e){const a=e[r],i=a.images[0].data;if(!i){Vo().warn("Externally referenced texture data is not yet supported");continue}const n=a.encoding+";base64,"+i,s="/textureDefinitions/"+r,l="rgba"===a.channels?a.alphaChannelUsage||"transparency":"none",c={noUnpackFlip:!0,wrap:{s:10497,t:10497},preMultiplyAlpha:1!==Ho(l)},u=t?.disableTextures?Promise.resolve(null):(0,D.r)(n,t);o.push(u.then(e=>({refId:s,image:e,parameters:c,alphaChannelUsage:l})))}const r=await Promise.all(o),a={};for(const e of r)a[e.refId]=e;return a}(o.textureDefinitions??{},t);let a=0;for(const e in r)if(r.hasOwnProperty(e)){const t=r[e];a+=t?.image?t.image.width*t.image.height*4:0}return new ko(o,r,a+(0,_.c)(o))}(m.url,t)),{engineResources:o,referenceBoundingBox:r}=function(e,t){const o=new Array,r=new Array,a=new Array,i=new Ao,n=e.resource,s=P.A.parse(n.version||"1.0","wosr");Zo.validate(s);const l=n.model.name,c=n.model.geometries,u=n.materialDefinitions??{},h=e.textures;let m=0;const p=new Map;for(let e=0;e<c.length;e++){const n=c[e];if(!Uo(n))continue;const s=qo(n),l=n.params.vertexAttributes,f=[],g=e=>{if("PerAttributeArray"===n.params.topology)return null;const t=n.params.faces;for(const o in t)if(o===e)return t[o].values;return null},v=l.position,x=v.values.length/v.valuesPerElement;for(const e in l){const t=l[e],o=t.values,r=g(e)??(0,F.b)(x);f.push([e,new R.A(o,r,t.valuesPerElement,!0)])}const b=s.texture,y=h&&h[b];if(y&&!p.has(b)){const{image:e,parameters:t}=y,o=new z.M(e,t);r.push(o),p.set(b,o)}const w=p.get(b),M=w?w.id:void 0,S=s.material;let T=i.get(S,b);if(null==T){const e=u[S.slice(S.lastIndexOf("/")+1)].params;1===e.transparency&&(e.transparency=0);const o=y?Ho(y.alphaChannelUsage):void 0,r={ambient:(0,d.a)(e.diffuse),diffuse:(0,d.a)(e.diffuse),opacity:1-(e.transparency||0),textureAlphaMode:o,textureAlphaCutoff:.33,textureId:M,doubleSided:!0,cullFace:0,colorMixMode:e.externalColorMixMode||"tint",textureAlphaPremultiplied:y?.parameters.preMultiplyAlpha??!1};t?.materialParameters&&Object.assign(r,t.materialParameters),T=new Ro(r,t),i.set(S,b,T)}a.push(T);const C=new j.b(T,f);m+=f.find(e=>"position"===e[0])?.[1]?.indices.length??0,o.push(C)}return{engineResources:[{name:l,stageResources:{textures:r,materials:a,geometries:o},pivotOffset:n.model.pivotOffset,numberOfVertices:m,lodThreshold:null}],referenceBoundingBox:$o(o)}}(e,t);return{lods:o,referenceBoundingBox:r,isEsriSymbolResource:!1,isWosr:!0}}let w;if(t.cache)w=await t.cache.loadGLTF(m.url,t,!!t.usePBR,!!t.useEmissive);else{const{loadGLTF:e}=await o.e(9324).then(o.bind(o,89324));w=await e(new b.D,m.url,t,t.usePBR,t.useEmissive)}const{engineResources:C,referenceBoundingBox:O}=function(e,t,o){const a=e.model,m=e.meta,b=a.meta?.ESRI_proxyEllipsoid,w=m.isEsriSymbolResource&&null!=b&&"EsriRealisticTreesStyle"===m.ESRI_webstyle;w&&!e.customMeta.esriTreeRendering&&(e.customMeta.esriTreeRendering=!0,function(e,t){for(let o=0;o<e.model.lods.length;++o){const a=e.model.lods[o];for(const i of a.parts){const a=i.attributes.normal;if(null==a)return;const n=i.attributes.position,c=n.count,h=(0,d.c)(),m=(0,d.c)(),p=(0,d.c)(),g=new Float32Array(4*c),v=new Float32Array(3*c),x=(0,s.i)((0,l.c)(),i.transform);let b=0,y=0;for(let s=0;s<c;s++){n.getVec(s,m),a.getVec(s,h),(0,u.r)(m,m,i.transform),(0,u.o)(p,m,t.center),(0,u.I)(p,p,t.radius);const l=p[2],c=(0,u.b)(p),d=Math.min(.45+.55*c*c,1)**r.d;(0,u.I)(p,p,t.radius),null!==x&&(0,u.r)(p,p,x),(0,u.n)(p,p),o+1!==e.model.lods.length&&e.model.lods.length>1&&(0,u.j)(p,p,h,l>-1?.2:Math.min(-4*l-3.8,1)),v[b]=p[0],v[b+1]=p[1],v[b+2]=p[2],b+=3,g[y]=d,g[y+1]=d,g[y+2]=d,g[y+3]=1,y+=4}i.attributes.normal=new f.B(v.buffer),i.attributes.color=new f.i(g.buffer)}}}(e,b));const M=!!t.usePBR,S=m.isEsriSymbolResource?{usePBR:M,isSchematic:!1,treeRendering:w,mrrFactors:at}:{usePBR:M,isSchematic:!1,treeRendering:!1,mrrFactors:ot},T={...t.materialParameters,treeRendering:w},C=new Array,_=new Map,I=new Map,P=a.lods.length,F=(0,h.b)();return a.lods.forEach((e,s)=>{const l=!0===t.skipHighLods&&(P>1&&0===s||P>3&&1===s)||!1===t.skipHighLods&&null!=o&&s!==o;if(l&&0!==s)return;const m=new Xo(e.name,e.lodThreshold,[0,0,0]);e.parts.forEach(e=>{const o=l?new Ro({},t):function(e,t,o,a,i,n,s,l,h){const m=e.materials.get(t.material);if(null==m)return null;const{normal:p,color:f,texCoord0:g,tangent:v}=t.attributes,x=t.material+(p?"_normal":"")+(f?"_color":"")+(g?"_texCoord0":"")+(v?"_tangent":""),b=null!=t.attributes.texCoord0,w=null!=t.attributes.normal,M=function(e){switch(e){case"BLEND":return 0;case"MASK":return 2;case"OPAQUE":case null:case void 0:return 1}}(m.alphaMode);if(!n.has(x)){if(b){const t=(t,o=!1,r=!1)=>{if(null!=t&&!s.has(t)){const a=e.textures.get(t);if(a){const e=a.data,i=o&&!(0,y.i)(e)?l.compressionOptions:void 0;s.set(t,new z.M((0,y.i)(e)?e.data:e,{...a.parameters,preMultiplyAlpha:!(0,y.i)(e)&&r,encoding:(0,y.i)(e)?e.encoding:void 0,compressionOptions:i}))}}},o=1!==M&&!h;t(m.colorTexture,o,1!==M),t(m.normalTexture),t(m.occlusionTexture,!0),t(m.emissiveTexture),t(m.metallicRoughnessTexture,!0)}const o=(0,r.f)(m.color[0]),p=(0,r.f)(m.color[1]),f=(0,r.f)(m.color[2]),g=null!=m.colorTexture&&b?s.get(m.colorTexture):null,v=function({normalTexture:e,metallicRoughnessTexture:t,metallicFactor:o,roughnessFactor:r,emissiveTexture:a,emissiveFactor:i,occlusionTexture:n}){return null==e&&null==t&&null==a&&(null==i||(0,u.m)(i,d.Z))&&null==n&&(null==r||1===r)&&(null==o||1===o)}(m),S=null!=m.normalTextureTransform?.scale?m.normalTextureTransform?.scale:c.O;n.set(x,new Ro({...a,customDepthTest:1,textureAlphaMode:M,textureAlphaCutoff:m.alphaCutoff,diffuse:[o,p,f],ambient:[o,p,f],opacity:"OPAQUE"===m.alphaMode?1:m.opacity,doubleSided:m.doubleSided,doubleSidedType:"winding-order",cullFace:m.doubleSided?0:2,hasVertexColors:!!t.attributes.color,hasVertexTangents:!!t.attributes.tangent,normalType:w?0:2,castShadows:!0,receiveShadows:m.receiveShadows,receiveAmbientOcclusion:m.receiveAmbientOcclusion,textureId:null!=g?g.id:void 0,colorMixMode:m.colorMixMode,normalTextureId:null!=m.normalTexture&&b?s.get(m.normalTexture).id:void 0,textureAlphaPremultiplied:null!=g&&!!g.parameters.preMultiplyAlpha,occlusionTextureId:null!=m.occlusionTexture&&b?s.get(m.occlusionTexture).id:void 0,emissiveTextureId:null!=m.emissiveTexture&&b?s.get(m.emissiveTexture).id:void 0,metallicRoughnessTextureId:null!=m.metallicRoughnessTexture&&b?s.get(m.metallicRoughnessTexture).id:void 0,emissiveBaseColor:[m.emissiveFactor[0],m.emissiveFactor[1],m.emissiveFactor[2]],emissiveStrengthKHR:null!=m.emissiveStrengthKHR?m.emissiveStrengthKHR:1,emissiveStrengthFromSymbol:null!=i.emissiveStrengthFromSymbol?i.emissiveStrengthFromSymbol:void 0,mrrFactors:v?rt:[m.metallicFactor,m.roughnessFactor,a.mrrFactors[2]],isSchematic:v,colorTextureTransformMatrix:Jo(m.colorTextureTransform),normalTextureTransformMatrix:Jo(m.normalTextureTransform),scale:[S[0],S[1]],occlusionTextureTransformMatrix:Jo(m.occlusionTextureTransform),emissiveTextureTransformMatrix:Jo(m.emissiveTextureTransform),metallicRoughnessTextureTransformMatrix:Jo(m.metallicRoughnessTextureTransform),...i},l))}const S=n.get(x);if(o.stageResources.materials.push(S),b){const e=e=>{null!=e&&o.stageResources.textures.push(s.get(e))};e(m.colorTexture),e(m.normalTexture),e(m.occlusionTexture),e(m.emissiveTexture),e(m.metallicRoughnessTexture)}return S}(a,e,m,S,T,_,I,t,w),{geometry:b,vertexCount:M}=function(e,t){const o=e.attributes.position.count,r=(0,x.c)(e.indices||o,e.primitiveType),a=p(3*o),{typedBuffer:s,typedBufferStride:l}=e.attributes.position;(0,g.b)(a,s,e.transform,3,l);const c=[["position",new R.A(a,r,3,!0)]];if(null!=e.attributes.normal){const t=p(3*o),{typedBuffer:a,typedBufferStride:s}=e.attributes.normal;(0,n.n)(Qo,e.transform),(0,g.t)(t,a,Qo,3,s),(0,i.q)(Qo)&&(0,g.n)(t,t),c.push(["normal",new R.A(t,r,3,!0)])}if(null!=e.attributes.tangent){const t=p(4*o),{typedBuffer:a,typedBufferStride:s}=e.attributes.tangent;(0,n.d)(Qo,e.transform),(0,v.t)(t,a,Qo,4,s),(0,i.q)(Qo)&&(0,g.n)(t,t,4),c.push(["tangent",new R.A(t,r,4,!0)])}if(null!=e.attributes.texCoord0){const t=p(2*o),{typedBuffer:a,typedBufferStride:i}=e.attributes.texCoord0;(0,x.n)(t,a,2,i),c.push(["uv0",new R.A(t,r,2,!0)])}const u=e.attributes.color;if(null!=u){const t=new Uint8Array(4*o);4===u.elementCount?u instanceof f.i?(0,v.l)(t,u,1,255):(u instanceof f.c||u instanceof f.j)&&(0,v.l)(t,u,1/255,255):(t.fill(255),u instanceof f.B?(0,g.l)(t,u.typedBuffer,1,255,4,u.typedBufferStride):(e.attributes.color instanceof f.g||e.attributes.color instanceof f.h)&&(0,g.l)(t,u.typedBuffer,1/255,255,4,e.attributes.color.typedBufferStride)),c.push(["color",new R.A(t,r,4,!0)])}return{geometry:new j.b(t,c),vertexCount:o}}(e,o??new Ro({},t)),C=b.boundingInfo;null!=C&&0===s&&((0,h.e)(F,C.bbMin),(0,h.e)(F,C.bbMax)),null!=o&&(m.stageResources.geometries.push(b),m.numberOfVertices+=M)}),l||C.push(m)}),{engineResources:C,referenceBoundingBox:F}}(w,t,m.specifiedLodIndex);return{lods:C,referenceBoundingBox:O,isEsriSymbolResource:w.meta.isEsriSymbolResource,isWosr:!1}},parseUrl:Ko},Symbol.toStringTag,{value:"Module"}))},92273(e,t,o){o.d(t,{c:()=>n,d:()=>b,e:()=>x,g:()=>l,h:()=>s,k:()=>c,n:()=>u,o:()=>y,r:()=>d,s:()=>w,v:()=>M});var r=o(92),a=o(34484),i=o(47498);function n(e=S){return[e[0],e[1],e[2],e[3]]}function s(e,t){return function(e,t,o,r,a=n()){return a[0]=e,a[1]=t,a[2]=o,a[3]=r,a}(t[0],t[1],t[2],t[3],e)}function l(e){return e}function c(e,t,o){const r=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],a=Math.abs(r-1)>1e-5&&r>1e-12?1/Math.sqrt(r):1;return o[0]=t[0]*a,o[1]=t[1]*a,o[2]=t[2]*a,o[3]=-(o[0]*e[0]+o[1]*e[1]+o[2]*e[2]),o}function u(e,t,o,r=n()){const a=o[0]-t[0],i=o[1]-t[1],s=o[2]-t[2],l=e[0]-t[0],c=e[1]-t[1],u=e[2]-t[2],d=i*u-s*c,h=s*l-a*u,m=a*c-i*l,p=d*d+h*h+m*m,f=Math.abs(p-1)>1e-5&&p>1e-12?1/Math.sqrt(p):1;return r[0]=d*f,r[1]=h*f,r[2]=m*f,r[3]=-(r[0]*e[0]+r[1]*e[1]+r[2]*e[2]),r}function d(e,t,o,r=0,i=Math.floor(o*(1/3)),n=Math.floor(o*(2/3))){if(o<3)return!1;t(m,r);let s=i,l=!1;for(;s<o-1&&!l;)t(p,s),s++,l=!(0,a.m)(m,p);if(!l)return!1;for(s=Math.max(s,n),l=!1;s<o&&!l;)t(f,s),s++,(0,a.o)(g,m,p),(0,a.n)(g,g),(0,a.o)(v,p,f),(0,a.n)(v,v),l=!(0,a.m)(m,f)&&!(0,a.m)(p,f)&&Math.abs((0,a.d)(g,v))<h;return l?(u(m,p,f,e),!0):(0!==r||1!==i||2!==n)&&d(e,t,o,0,1,2)}o(64877);const h=.99619469809,m=(0,i.c)(),p=(0,i.c)(),f=(0,i.c)(),g=(0,i.c)(),v=(0,i.c)();function x(e,t,o){return function(e){return 0===e||1===e}(M(e,t.origin,t.vector,0,o))}function b(e,t){return w(e,t)>=0}function y(e,t){const o=(0,a.d)(e,t.ray.direction),r=-w(e,t.ray.origin);if(r<0&&o>=0)return!1;if(o>-1e-6&&o<1e-6)return r>0;if((r<0||o<0)&&!(r<0&&o<0))return!0;const i=r/o;return o>0?i<t.c1&&(t.c1=i):i>t.c0&&(t.c0=i),t.c0<=t.c1}function w(e,t){return(0,a.d)(e,t)+e[3]}function M(e,t,o,i,n){const s=(0,a.d)(e,o),l=w(e,t);if(0===s)return l>=0?2:3;let c=-l/s;return 1&i&&(c=(0,r.c)(c,0,1)),!(4&i)&&c<0||!(8&i)&&c>1?l>=0?2:3:((0,a.p)(n,t,(0,a.q)(n,o,c)),l>=0?0:1)}const S=[0,0,1,0]},55801(e,t,o){function r(){return[0,0,0,1]}function a(e){return[e[0],e[1],e[2],e[3]]}o.d(t,{I:()=>i,a:()=>a,c:()=>r});const i=[0,0,0,1]},58141(e,t,o){o.d(t,{E:()=>a,a:()=>s,i:()=>i,j:()=>n});var r=o(11635);class a{constructor(e){this.data=e,this.type="encoded-mesh-texture",this.encoding="image/ktx2"}}function i(e){return"encoded-mesh-texture"===e?.type}async function n(e){const t=new Blob([e]),o=await t.text();return JSON.parse(o)}async function s(e,t){if("image/ktx2"===t)return new a(e);const o=new Blob([e],{type:t});let i=URL.createObjectURL(o);switch(t){case"image/jpeg":i+="#.jpg";break;case"image/png":i+="#.png"}const n=new Image;if((0,r.h)("esri-iPhone"))return new Promise((e,t)=>{const o=()=>{a(),e(n)},r=e=>{a(),t(e)},a=()=>{URL.revokeObjectURL(i),n.removeEventListener("load",o),n.removeEventListener("error",r)};n.addEventListener("load",o),n.addEventListener("error",r),n.src=i});try{n.src=i,await n.decode()}catch{}return URL.revokeObjectURL(i),n}},62908(e,t,o){o.d(t,{c:()=>u,s:()=>d});var r=o(19485),a=o(97912),i=o(92498),n=o(78413),s=o(80300),l=o(39058),c=o(85523);async function u(e,t,o,l){const c=(0,s.p)(e),u=t[0].spatialReference,d={...l,responseType:"json",query:{...c.query,f:"json",sr:(0,n.s)(u),target:JSON.stringify({geometryType:(0,a.g)(t[0]),geometries:t}),cutter:JSON.stringify(o)}},h=await(0,r.A)(c.path+"/cut",d),{cutIndexes:m,geometries:p=[]}=h.data;return{cutIndexes:m,geometries:p.map(e=>{const t=(0,i.rS)(e);return t.spatialReference=u,t})}}async function d(e,t,o){const i="string"==typeof e?(0,l.An)(e):e,s=t[0].spatialReference,u=(0,a.g)(t[0]),d={...o,query:{...i.query,f:"json",sr:(0,n.s)(s),geometries:JSON.stringify((0,c.e)(t))}},{data:h}=await(0,r.A)(i.path+"/simplify",d);return(0,c.d)(h.geometries,u,s)}},85523(e,t,o){o.d(t,{d:()=>n,e:()=>i});var r=o(97912),a=o(92498);function i(e){return{geometryType:(0,r.g)(e[0]),geometries:e.map(e=>e.toJSON())}}function n(e,t,o){const r=(0,a.xD)(t);return e.map(e=>{const t=r.fromJSON(e);return t.spatialReference=o,t})}},83988(e,t,o){function r(){return new Float32Array(2)}function a(e,t){const o=new Float32Array(2);return o[0]=e,o[1]=t,o}o.d(t,{O:()=>n,Z:()=>i,c:()=>r,f:()=>a});const i=r(),n=a(1,1);a(1,0),a(0,1)},60163(e,t,o){function r(){return[0,0]}function a(e){return[e[0],e[1]]}function i(e,t){return[e,t]}o.d(t,{N:()=>s,O:()=>n,b:()=>a,c:()=>r,f:()=>i});const n=i(1,1),s=i(-1,-1);i(1,0),i(0,1)},97812(e,t,o){o.d(t,{a:()=>d,b:()=>n,c:()=>i,d:()=>s,e:()=>h,f:()=>c,g:()=>a,l:()=>u,n:()=>m,t:()=>l});var r=o(49595);function a(e,t,o){if(t<=0)return 0;const r=e-o;return r<0?0:Math.floor(r/t)+1}function i(e,t,o){n(e.typedBuffer,t.typedBuffer,o,e.typedBufferStride,t.typedBufferStride)}function n(e,t,o,r=3,i=r){const n=a(e.length,r,3),s=a(t.length,i,3),l=Math.min(n,s),c=o[0],u=o[1],d=o[2],h=o[4],m=o[5],p=o[6],f=o[8],g=o[9],v=o[10],x=o[12],b=o[13],y=o[14];let w=0,M=0;for(let o=0;o<l;o++){const o=t[w],a=t[w+1],n=t[w+2];e[M]=c*o+h*a+f*n+x,e[M+1]=u*o+m*a+g*n+b,e[M+2]=d*o+p*a+v*n+y,w+=i,M+=r}return e}function s(e,t,o){l(e.typedBuffer,t.typedBuffer,o,e.typedBufferStride,t.typedBufferStride)}function l(e,t,o,r=3,i=r){const n=a(e.length,r,3),s=a(t.length,i,3),l=Math.min(n,s),c=o[0],u=o[1],d=o[2],h=o[3],m=o[4],p=o[5],f=o[6],g=o[7],v=o[8];let x=0,b=0;for(let o=0;o<l;o++){const o=t[x],a=t[x+1],n=t[x+2];e[b]=c*o+h*a+f*n,e[b+1]=u*o+m*a+g*n,e[b+2]=d*o+p*a+v*n,x+=i,b+=r}}function c(e,t,o,r){u(e.typedBuffer,t.typedBuffer,o,r,e.typedBufferStride,t.typedBufferStride)}function u(e,t,o,a,i=3,n=i){const s=Math.min(e.length/i,t.length/n);let l=0,c=0;const u=1/r.d;for(let r=0;r<s;r++)e[c]=a*(o*t[l])**u,e[c+1]=a*(o*t[l+1])**u,e[c+2]=a*(o*t[l+2])**u,l+=n,c+=i}function d(e,t,o,r=3,i=r){const n=a(e.length,r,3),s=a(t.length,i,3),l=Math.min(n,s);let c=0,u=0;for(let a=0;a<l;a++)e[u]=t[c]+o[0],e[u+1]=t[c+1]+o[1],e[u+2]=t[c+2]+o[2],c+=i,u+=r;return e}function h(e,t){m(e.typedBuffer,t.typedBuffer,e.typedBufferStride,t.typedBufferStride)}function m(e,t,o=3,r=o){const a=Math.min(e.length/o,t.length/r);let i=0,n=0;for(let s=0;s<a;s++){const a=t[i],s=t[i+1],l=t[i+2],c=a*a+s*s+l*l;if(c>0){const t=1/Math.sqrt(c);e[n]=t*a,e[n+1]=t*s,e[n+2]=t*l}i+=r,n+=o}}o(11635),o(167)},19553(e,t,o){o.d(t,{a:()=>m,b:()=>c,c:()=>a,e:()=>p,f:()=>u,g:()=>s,h:()=>d,m:()=>n,r:()=>l,s:()=>i,t:()=>h});var r=o(34750);function a(e,t){return e[0]=t[0],e[1]=t[1],e[2]=t[2],e[3]=t[3],e}function i(e,t,o,r,a){return e[0]=t,e[1]=o,e[2]=r,e[3]=a,e}function n(e,t,o){return e[0]=Math.min(t[0],o[0]),e[1]=Math.min(t[1],o[1]),e[2]=Math.min(t[2],o[2]),e[3]=Math.min(t[3],o[3]),e}function s(e,t,o){return e[0]=Math.max(t[0],o[0]),e[1]=Math.max(t[1],o[1]),e[2]=Math.max(t[2],o[2]),e[3]=Math.max(t[3],o[3]),e}function l(e,t){return e[0]=Math.round(t[0]),e[1]=Math.round(t[1]),e[2]=Math.round(t[2]),e[3]=Math.round(t[3]),e}function c(e,t,o){return e[0]=t[0]*o,e[1]=t[1]*o,e[2]=t[2]*o,e[3]=t[3]*o,e}function u(e,t){const o=t[0]-e[0],r=t[1]-e[1],a=t[2]-e[2],i=t[3]-e[3];return o*o+r*r+a*a+i*i}function d(e){const t=e[0],o=e[1],r=e[2],a=e[3];return t*t+o*o+r*r+a*a}function h(e,t,o){const r=t[0],a=t[1],i=t[2],n=t[3];return e[0]=o[0]*r+o[4]*a+o[8]*i+o[12]*n,e[1]=o[1]*r+o[5]*a+o[9]*i+o[13]*n,e[2]=o[2]*r+o[6]*a+o[10]*i+o[14]*n,e[3]=o[3]*r+o[7]*a+o[11]*i+o[15]*n,e}function m(e,t){return e[0]===t[0]&&e[1]===t[1]&&e[2]===t[2]&&e[3]===t[3]}function p(e,t){const o=e[0],a=e[1],i=e[2],n=e[3],s=t[0],l=t[1],c=t[2],u=t[3],d=(0,r.g)();return Math.abs(o-s)<=d*Math.max(1,Math.abs(o),Math.abs(s))&&Math.abs(a-l)<=d*Math.max(1,Math.abs(a),Math.abs(l))&&Math.abs(i-c)<=d*Math.max(1,Math.abs(i),Math.abs(c))&&Math.abs(n-u)<=d*Math.max(1,Math.abs(n),Math.abs(u))}},87477(e,t,o){function r(){return[0,0,0,0]}function a(e,t,o,r){return[e,t,o,r]}function i(e,t,o,r){return[e,t,o,r]}function n(){return a(0,0,0,1)}o.d(t,{O:()=>l,Z:()=>s,c:()=>r,d:()=>i,f:()=>a,u:()=>n});const s=[0,0,0,0],l=a(1,1,1,1);a(1,0,0,0)},64877(e,t,o){o.d(t,{a:()=>h,c:()=>m,d:()=>p,s:()=>d}),o(11635);var r=o(20067),a=o(24890),i=o(4741),n=o(55801),s=o(60163),l=o(47498),c=o(87477);class u{constructor(e){this._create=e,this._items=new Array,this._itemsPtr=0}get(){return 0===this._itemsPtr&&(0,r.n)(()=>this._reset()),this._itemsPtr>=this._items.length&&this._items.push(this._create()),this._items[this._itemsPtr++]}_reset(){const e=2*this._itemsPtr;this._items.length>e&&(this._items.length=e),this._itemsPtr=0}static createVec2f64(){return new u(s.c)}static createVec3f64(){return new u(l.c)}static createVec4f64(){return new u(c.c)}static createMat3f64(){return new u(a.c)}static createMat4f64(){return new u(i.c)}static createQuatf64(){return new u(n.c)}get test(){}}u.createVec2f64();const d=u.createVec3f64(),h=u.createVec4f64();u.createMat3f64();const m=u.createMat4f64(),p=u.createQuatf64()},30159(e,t,o){o.d(t,{w:()=>a});var r=o(30790);function a(e,t){return new Promise((o,a)=>{e.readyState>=HTMLMediaElement.HAVE_CURRENT_DATA?o():(t((0,r.a)(e,"canplay",o)),t((0,r.a)(e,"error",a)))})}},78726(e,t,o){o.d(t,{A:()=>a});var r=o(90840);o(61064),o(167),o(74181),o(11635),o(47616),o(3630);class a{constructor(e,t,o=""){this.major=e,this.minor=t,this._context=o}lessThan(e,t){return this.major<e||e===this.major&&this.minor<t}greaterEqual(e,t){return!this.lessThan(e,t)}toString(){return`${this.major}.${this.minor}`}validate(e){if(this.major!==e.major){const t=this._context&&this._context+":",o=this._context&&this._context+" ";throw new r.A(t+"unsupported-version",`Required major ${o}version is '${this.major}', but got '\${version.major}.\${version.minor}'`,{version:e})}}clone(){return new a(this.major,this.minor,this._context)}static parse(e,t=""){const[o,i]=e.split("."),n=/^\s*\d+\s*$/;if(!o?.match||!n.test(o))throw new r.A((t&&t+":")+"invalid-version","Expected major version to be a number, but got '${version}'",{version:e});if(!i?.match||!n.test(i))throw new r.A((t&&t+":")+"invalid-version","Expected minor version to be a number, but got '${version}'",{version:e});const s=parseInt(o,10),l=parseInt(i,10);return new a(s,l,t)}}},46997(e,t,o){o.d(t,{O7:()=>M,Y_:()=>T,el:()=>w});var r=o(74181),a=o(81589),i=o(90840),n=o(167),s=o(87203),l=o(66625),c=o(32276),u=o(88562),d=o(78413),h=o(46053),m=o(99095),p=o(40864),f=o(62908);o(11635),o(47616),o(61064),o(92),o(3630),o(69099),o(99413),o(43169),o(69053),o(42015),o(20118),o(91796),o(16456),o(38927),o(68176),o(25449),o(81145),o(56502),o(98127),o(45021),o(52415),o(32908),o(21262),o(90415),o(32846),o(30790),o(58777),o(38224),o(2426),o(34232),o(63742),o(19485),o(39058),o(98311),o(98113),o(79251),o(94884),o(85441),o(20409),o(78363),o(33031),o(82427),o(34750),o(92498),o(36880),o(80300),o(26723),o(85523);const g=()=>n.L.getLogger("esri.geometry.support.normalizeUtils");function v(e){return"polygon"===e[0].type}function x(e){return"polyline"===e[0].type}function b(e,t,o){const r=1e6;if(t){const t=(0,m.i)(e)?(0,p.d)(e,{maxSegmentLength:r}):function(e,t){if(!(e instanceof l.A||e instanceof s.A)){const e="straightLineDensify: the input geometry is neither polyline nor polygon";throw g().error(e),new i.A("internal:geometry",e)}const o=(0,u.g)(e),r=[];for(const e of o){const o=[];r.push(o),o.push([e[0][0],e[0][1]]);for(let r=0;r<e.length-1;r++){const a=e[r][0],i=e[r][1],n=e[r+1][0],s=e[r+1][1],l=Math.sqrt((n-a)*(n-a)+(s-i)*(s-i)),c=(s-i)/l,u=(n-a)/l,d=l/t;if(d>1){for(let e=1;e<=d-1;e++){const r=e*t,n=u*r+a,s=c*r+i;o.push([n,s])}const e=(l+Math.floor(d-1)*t)/2,r=u*e+a,n=c*e+i;o.push([r,n])}o.push([n,s])}}return function(e){return"polygon"===e.type}(e)?new s.A({rings:r,spatialReference:e.spatialReference}):new l.A({paths:r,spatialReference:e.spatialReference})}(e,r);e=(0,h.ci)(t,!0)}return o&&(e=(0,u.u)(e,o)),e}function y(e,t,o){if(Array.isArray(e)){const r=e[0];if(r>t){const o=(0,u.o)(r,t);e[0]=r+o*(-2*t)}else if(r<o){const t=(0,u.o)(r,o);e[0]=r+t*(-2*o)}}else{const r=e.x;if(r>t){const o=(0,u.o)(r,t);e=e.clone().offset(o*(-2*t),0)}else if(r<o){const t=(0,u.o)(r,o);e=e.clone().offset(t*(-2*o),0)}}return e}async function w(e,t,o){if(!Array.isArray(e))return w([e],t);t&&"string"!=typeof t&&g().warn("normalizeCentralMeridian()","The url object is deprecated, use the url string instead");const a="string"==typeof t?t:t?.url??r.A.geometryServiceUrl;let i,n,c,m,p,M,S,T,C=0;const _=[],I=[];for(const t of e)if(null!=t)if(i||(i=t.spatialReference,n=(0,d.h)(i),c=i.isWebMercator,M=c?102100:4326,m=u.c[M].maxX,p=u.c[M].minX,S=u.c[M].plus180Line,T=u.c[M].minus180Line),n)if("mesh"===t.type)I.push(t);else if("point"===t.type)I.push(y(t.clone(),m,p));else if("multipoint"===t.type){const e=t.clone();e.points=e.points.map(e=>y(e,m,p)),I.push(e)}else if("extent"===t.type){const e=t.clone()._normalize(!1,!1,n);I.push(e.rings?new s.A(e):e)}else if(t.extent){const e=t.extent,o=(0,u.o)(e.xmin,p)*(2*m);let r=0===o?t.clone():(0,u.u)(t.clone(),o);e.offset(o,0);let{xmin:a,xmax:i}=e;a=Number(a.toFixed(9)),i=Number(i.toFixed(9)),e.intersects(S)&&i!==m?(C=i>C?i:C,r=b(r,c),_.push(r),I.push("cut")):e.intersects(T)&&a!==p?(C=i*(2*m)>C?i*(2*m):C,r=b(r,c,360),_.push(r),I.push("cut")):I.push(r)}else I.push(t.clone());else I.push(t);else I.push(t);let P=(0,u.o)(C,m),F=-90;const D=P,R=new l.A;for(;P>0;){const e=360*P-180;R.addPath([[e,F],[e,-1*F]]),F*=-1,P--}if(_.length>0&&D>0){const t=function(e,t){let o=-1;for(let r=0;r<t.cutIndexes.length;r++){const a=t.cutIndexes[r],i=t.geometries[r],n=(0,u.g)(i);for(let e=0;e<n.length;e++){const t=n[e];t.some(o=>{if(o[0]<180)return!0;{let o=0;for(let e=0;e<t.length;e++){const r=t[e][0];o=r>o?r:o}o=Number(o.toFixed(9));const r=-360*(0,u.o)(o,180);for(let o=0;o<t.length;o++){const t=i.getPoint(e,o);i.setPoint(e,o,t.clone().offset(r,0))}return!0}})}if(a===o){if(v(e))for(const t of(0,u.g)(i))e[a]=e[a].addRing(t);else if(x(e))for(const t of(0,u.g)(i))e[a]=e[a].addPath(t)}else o=a,e[a]=i}return e}(_,await(0,f.c)(a,_,R,o)),r=[],i=[];for(let o=0;o<I.length;o++){const a=I[o];if("cut"!==a)i.push(a);else{const a=t.shift(),n=e[o];null!=n&&"polygon"===n.type&&n.rings&&n.rings.length>1&&a.rings.length>=n.rings.length?(r.push(a),i.push("simplify")):i.push(c?(0,h.Gh)(a):a)}}if(!r.length)return i;const n=await(0,f.s)(a,r,o),s=[];for(let e=0;e<i.length;e++){const t=i[e];"simplify"!==t?s.push(t):s.push(c?(0,h.Gh)(n.shift()):n.shift())}return s}const j=[];for(let e=0;e<I.length;e++){const t=I[e];if("cut"!==t)j.push(t);else{const e=_.shift();j.push(!0===c?(0,h.Gh)(e):e)}}return j}function M(e,t,o){const r=(0,d.h)(o);if(null==r)return e;const[a,i]=r.valid,n=2*i;let s=0,l=0;t>i?s=Math.ceil(Math.abs(t-i)/n):t<a&&(s=-Math.ceil(Math.abs(t-a)/n)),e>i?l=Math.ceil(Math.abs(e-i)/n):e<a&&(l=-Math.ceil(Math.abs(e-a)/n));let c=e+(s-l)*n;const u=c-t;return u>i?c-=n:u<a&&(c+=n),c}function S(e){const t=(0,d.h)(e);if(null==t)return null;const[o,r]=t.valid;return new a.C(o,r)}const T=S(c.A.WGS84);S(c.A.WebMercator)}}]);