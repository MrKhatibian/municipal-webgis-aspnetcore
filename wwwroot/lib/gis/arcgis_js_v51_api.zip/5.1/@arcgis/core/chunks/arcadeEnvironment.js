/* COPYRIGHT Esri - https://js.arcgis.com/5.1.14/LICENSE.txt */
import{A as e}from"./executionError.js";function r(r){if("string"==typeof r)return r.toLowerCase();if("name"in r)return r.name.toLowerCase();if("string"!=typeof r.value)throw new e("InvalidIdentifier",null);return r.value.toLowerCase()}const t=Object.freeze({aborted:!1});export{t as n,r as t};
