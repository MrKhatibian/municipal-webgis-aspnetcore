/* COPYRIGHT Esri - https://js.arcgis.com/5.1.14/LICENSE.txt */
import{m as e}from"./handleUtils.js";import{g as t}from"./MapUtils.js";function o(){const o=new WeakMap;return{register:(r,s)=>(t(o,r,()=>new Set).add(s),e(()=>((e,t)=>{const r=o.get(e);r&&(r.delete(t),0===r.size&&o.delete(e))})(r,s))),forEveryOther(e,t,r){const s=o.get(e);if(s)for(const e of s)e!==t&&r(e)}}}export{o as c};
