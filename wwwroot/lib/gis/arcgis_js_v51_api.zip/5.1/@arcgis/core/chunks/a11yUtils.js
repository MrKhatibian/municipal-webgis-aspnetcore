/* COPYRIGHT Esri - https://js.arcgis.com/5.1.14/LICENSE.txt */
import e from"../config.js";const o=()=>e.respectPrefersReducedMotion&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;export{o as p};
