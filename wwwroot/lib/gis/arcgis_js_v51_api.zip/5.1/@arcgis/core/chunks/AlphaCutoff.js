/* COPYRIGHT Esri - https://js.arcgis.com/5.1.14/LICENSE.txt */
const a=1/255.5,o=1-a;export{a,o};
